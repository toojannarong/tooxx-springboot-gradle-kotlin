const axios = require('axios');
const express = require('express');
const path = require('path');
const randomId = require('random-id');
const app = express(),
      bodyParser = require("body-parser");
      port = 3080;

// place holder for the data
const users = [];

app.use(bodyParser.json());
// app.use(express.static(path.join(__dirname, '../my-app/dist')));
// app.use(express.static(path.join(__dirname, '../alibaba-poc/dist')));
app.use(express.static(path.join(__dirname+'/dist')));

app.get('/api/users', (req, res) => {
  console.log('api/users called!!!!!!!')
  res.json(users);
});

app.post('/api/user', (req, res) => {
  const user = req.body.user;
  user.id = randomId(10);
  console.log('Adding user:::::', user);
  users.push(user);
  res.json("user addedd");

});
app.post('/api/pdf', async (req, res) => {
  console.log('body:', req.body);
  // res.json("token addedd");
  let response = "";
  try {
    response = await downloadFile(req.body);
      res.setHeader('Content-Disposition', 'attachment; filename=ecom.pdf');
      res.contentType("application/pdf");
      response.data.pipe(res);
  } catch (e) {
      res.status(500).json({
        text: "downloadFile failef",
          reason: e
      })
  }
    // res.contentType("application/pdf");
    // res.send(response.data)

  // res.status(200).json({
  //   text: "token addedd",
  //   pdf: encodedStringBtoA
  // })

});


app.get('/', (req,res) => {
  // res.sendFile(path.join(__dirname, '../my-app/build/index.html'));
  res.sendFile('/dist/index.html');
});

app.listen(port, () => {
    console.log(`Server listening on the port::${port}`);
    console.log(`__dirname: ${__dirname}`);
});


async function downloadFile({docNumber, type, language}) {
    const { data: { access_token: token} } = await getToken();
  const config = {
      method: 'get',
      url: `https://dsna-chem-acc-apim.dsna.xom.cloud/pdf/eCOMM?DOC_NUMBER=${docNumber}&TYPE=${type}&LANGUAGE=${language}`,
      headers: {
          'Ocp-Apim-Subscription-Key': '4d6e0be7b2814f6b875423c5f7e670dd',
          'Authorization': `Bearer ${token}`
      },
      responseType: 'stream'
  };
  return axios(config);

}

async function getToken() {
    const params = new URLSearchParams()
    params.append('grant_type', 'client_credentials')
    params.append('client_id', '18a32706-1cb9-4a71-bb17-4f5d4255c025')
    params.append('scope', '5eed4027-9895-4a93-99e5-09c0e6db4fb6/.default')
    params.append('client_secret', 'BLA-=xMLR-33=iHCh8T8b.XlZnL563/S')

    const config = {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    }

    const url = 'https://login.microsoftonline.com/d1ee1acd-bc7a-4bc4-a787-938c49a83906/oauth2/v2.0/token';
    return axios.post(url, params, config)

}

