# Core Mq Service

The Core Mq Service is a starter kit for how to build a SpringBoot API service on ExxonMobil OpenShift environment.

System Requirements
- JDK 1.8
- Gradle 4.7

### Usage
- [Prerequisites](#prerequisites)
- [How to start dependencies](#how-to-start-dependencies)
- [How to start](#how-to-start)
- [How to build image](#how-to-build-image)
- [How to deploy to UAT](#how-to-deploy-to-uat)
- [How to deploy to Production](#how-to-deploy-to-production)
- [How to publish api to mulesoft automatically](#how-to-publish-api-to-mulesoft-automatically)

### Integration
- [Integrate with OpenShift](#integrate-with-openshift)
- [Integrate with Istio](#integrate-with-istio)
- [Integrate with SAP Stripe](#integrate-with-sap-stripe)

### Features
- [Load resource from OpenShift](#load-resource-from-openshift)
- [Prometheus](#prometheus)
- [Tracing](#tracing)

---

### Prerequisites

#### Authentication & Authorization

`core-mq-service` uses [Azure AD][9] as the [IDP][10] and [OIDC][11] as the authentication protocol.
All data exposing endpoints (e.g. country endpoints, city endpoints, product endpoints, secret
endpoints, etc.) require authentication and proper authorization granted to the end user.

Please follow [this document][12] to setup the Azure AD and the following are the key requirements:
- An application [registered][17] in [Azure AD][9] as [resource server][13].
- An [App Role][14] `Read` (case sensitive) been [created][16] for this [resource server][13].
    > *Note:* The name of this app role can be changed to whatever makes sense for your application,
    but please ensure the `@PreAuthorize("hasApplicationRole('READ')")` annotation in each controller
    and the `ApplicationRole.java` is changed accordingly.
- The [App Role][14] `Read` is [assigned to the users][15].

`core-mq-service` uses **Service Account** credential to perform health check on SAP server, and uses
**OAuth Client** credential to exchange *SAML-Assertion* to *SAP Bearer Token*. Please contact SAP team
to get these two kinds of credentials.

Please create OpenShift secrets of SAP credentials for all the environments.
The secrets should be defined as below:

Use the following secret if the SAP E2E identity propagation is ready.

```yaml
apiVersion: v1
stringData:
  sap.service.username: <SAP service account username>
  sap.service.password: <SAP service account password>
  sap.service.saml-bearer.clientId: <SAP oauth client id>
  sap.service.saml-bearer.clientScope: <SAP oauth client scope>
  sap.service.saml-bearer.clientUsername: <SAP oauth client username, typically it's same as client id>
  sap.service.saml-bearer.clientPassword: <SAP oauth client password>
kind: Secret
metadata:
  labels:
    app: core-mq-service
  name: core-mq-service-sap-credential
type: Opaque
```

Use the following secret if the SAP E2E identity propagation is not ready.

```yaml
apiVersion: v1
stringData:
  sap.service.username: <SAP service account username>
  sap.service.password: <SAP service account password>
kind: Secret
metadata:
  labels:
    app: core-mq-service
  name: core-mq-service-sap-credential
type: Opaque
```

### How to start dependencies

#### Database

Locally you will need a Postgres database running on port 5432.

To start a local database we provide a `docker-compose.yml` file that can kickstart the appropiated containers, you only need to run the following command:

```bash
docker-compose up -d
```

This will provision the docker containers and map the necessary ports to your local machine. In order to stop the containers
you must run this command in the same directory as the `docker-compose.yml` file:

```bash
docker-compose down
```

#### [Liquibase][1]

Currently, the project contains [Liquibase][1] that allows database migrations using embedded scripts. This means that
whenever you start the application, Liquibase will check the latest version of the database schema and update accordingly.

The Liquibase migration scripts live in the [api-service/src/main/resources/db/changelog/migrations](api-service/src/main/resources/db/migration)
directory. They will get executed according to the order of the file names.

Note: Please **do not modify the migration scripts** once they are committed. The reason is that Liquibase will run checksums
for each migration script. The DB migration will fail if any one of them get changed.

### How to start
To start the application in local, use the gradle command

`./gradlew bootRun`

when it startup, you can visit the application use `http://localhost:8080`.

### How to build image
We use [Dockerfile](Dockerfile) to build image, you can use the `docker` command

`docker build . -t core-mq-service`

it will build an image named core-mq-service.

### How to deploy to UAT

#### Requirements

In order for Jenkins to be able to deploy images to UAT the following must be set beforehand:

1. The user Jenkins must be able to login to different projects/namespaces. The following command
can grant a project to Jenkins user.

    ```shell
    oc policy add-role-to-user edit system:serviceaccount:<project name, e.g. flcit-cst>:jenkins -n <uat project name, e.g. flcit-cst-uat>
    ```

1. Allow Jenkins to pull Docker Images from one project to another.

    ```shell
    oc policy add-role-to-user system:image-puller system:serviceaccount:<project name, e.g. flcit-cst>:jenkins -n <uat project name, e.g. flcit-cst-uat>
    ```

### How to deploy to Production

Go to [Getting an Application to Production][2] to see more details about how to move application to
OpenShift production, and the [Promotion Reference][3] is a complete demo of how to deploy an image
from Non production OpenShift to production OpenShift.

#### Requirements
- **Service Account For Non-Prod-OpenShift** which allow you to operate the Non-Prod-OpenShift.
- **Service Account For Prod-OpenShift** which allow you to operate the Prod-OpenShift.
- **Prod pipeline trigger secret** which allow you to trigger production environment pipeline build.

**NOTE** we need to define a `service account` and a `rolebinding` which will allow the production
promotion pipeline to pull images from non prod. If you have already defined it in the production
OpenShift, you can skip these steps.

1. Use the `non-prod` account to create a `service account` and add a `rolebinding` in the `Non-Prod-OpenShift`.

[promotion-policies.yaml](openshift/promotion-policies.yaml)

```shell
oc process -f openshift/promotion-policies.yaml | oc apply -f -
```

2. Use the `non-prod` account to save the secret for this service account in the `Non-Prod-OpenShift`.

Get token for promotion-client in your non-prod environment by following command

```shell
oc serviceaccounts get-token promotion-client
```

Create the secret resource file

```shell
oc create secret generic non-prod-promotion --dry-run=true -o yaml \
    --from-literal=token=<token string from previous command> \
    > non-prod-promotion-secret.yaml
```

3. Use the `prod` account to load the saved secret from step 2 to the `Prod-OpenShift`.
```shell
oc apply -f non-prod-promotion-secret.yaml
```

4. Jenkins will be deployed in `Prod-OpenShift` to facilitate the image copy and deployment. As part
of the Jenkins integration, a custom Jenkins Agent/Slave leveraging the skopeo tool will be utilized.
The slave will mount the secret we just defined so it can pull images from the 'Non-Prod-OpenShift'.
The slave can be automatically defined by creating a ConfigMap within the project:

[skopeo-runtime-slave.yaml](openshift/skopeo-runtime-slave.yaml)

```shell
oc process -f openshift/skopeo-runtime-slave.yaml | oc apply -f -
```

5. Create pipeline trigger secret in Non-Production
If the secret `prod-pipeline-trigger` already exists, you can skip this step.
> Replace `${secret}` by the secret text you've generated.

```bash
oc create secret generic prod-pipeline-trigger --from-literal=secrettext=${secret}
oc annotate secret prod-pipeline-trigger --overwrite jenkins.openshift.io/secret.name=prod-pipeline-trigger
oc label secret prod-pipeline-trigger --overwrite credential.sync.jenkins.openshift.io="true"
```

6. Use the `prod` account to create pipeline trigger secret in Production
If the secret `prod-pipeline-trigger` already exists, you can skip this step.
> Replace `${secret}` by the **same secret text** you've used in previous step.

```bash
oc create secret generic prod-pipeline-trigger --from-literal=WebHookSecretKey=${secret}
```

#### Deploy

1. Instantiate the resources that will be associated with the deployment of the application in the
`Prod-OpenShift`, contains `DeploymentConfig`, `Service` and `Route`:

[deploy-to-production.yaml](openshift/deploy-to-production.yaml)

```shell
oc process -f openshift/deploy-to-production.yaml | oc apply -f -
```

2. Instantiate the resources that required by the application in the `Prod-OpenShift`, contains
`Sercets` and `ConfigMaps`.

`core-mq-service-secrets-{env}.yaml` is for demonstration, replace `{env}` with `dev`, `qa`, `uat`, `prod` etc.

[core-mq-service-config-map-prod.yaml](openshift/core-mq-service-config-map-prod.yaml)
```shell
# Apply core-mq-service-secrets in your environment
oc apply -f openshift/core-mq-service-secrets-{env}.yaml

# Apply configmap in your production environment
oc apply -f openshift/core-mq-service-config-map-prod.yaml
```

3. A Jenkins Pipeline OpenShift BuildConfig is available to facilitate the promotion process. Create
this resource in the `Prod-OpenShift`.

[core-mq-service-openshift-production-pipeline.yaml](openshift/core-mq-service-openshift-production-pipeline.yaml)

```shell
oc process --param-file=openshift/pipeline -f openshift/core-mq-service-openshift-production-pipeline.yaml | oc apply -f-
```

4. Go into the Builds/Pipelines view in the OpenShift Web Console and notice the pipeline called
**core-mq-service-build-pipeline**. Start this pipeline. After completion (it may take awhile, especially
the first run), you should see a deployment of the app in the `Prod-OpenShift`. You can also use
command to start it:

```shell
oc start-build core-mq-service-build-pipeline
```

### How to publish api to mulesoft automatically
**1. Integrate with Swagger**

Our pipeline will use the endpoint `/v2/api-docs` provided by swagger as our API documentation and publish it to Mulesoft, so we need to integrate with Swagger.

**2. Request access for Mulesoft Catalog Process API**

We use the Catalog Process API to publish API to Mulessoft. The API uses a client id and client secret for authentication.
Click [here](https://anypoint.mulesoft.com/exchange/a31966b0-fc4e-4ac8-af23-c40fc73ce072.apps-tech-ais/catalog-process-api/) to request access and wait for approval.

**3. Set Catalog Process API credential in OpenShift Secret.**

After the request has been approved, you can get the client id and client secret, add them in OpenShift secret.
```yaml
apiVersion: v1
stringData:
  username: <client id>
  password: <client secret>
kind: Secret
metadata:
  name: mulesoft-client-secret
type: Opaque
```

**4. Update configurations for your application**

There is a file named mulesoftConfig.json which is the configuration file for publishing api to mulesoft automatically.
The pipeline will read configuration form this file. You can't change the
file name and the location of the file, otherwise the pipeline will fail because it can't find the file.
It's ok if to change the value of the properties inside the file. Here are some explanations of some special property that may make you confused.

#### groupName
It's the organization name of the mulesoft, you can find it inside the mulesoft system.

#### homePageContent
It's the description of the api in mulesoft.

#### creatorEmail
**It indicate who create/update the api into mulesoft, the creator must be the member of your business organization that you plan to publish.**

For example, if you want publish to `APPS-SMKT`, the creator should be a member of `EMIT.APPS.SMKT.MULESOFT.ADMIN.UG`.

For the complete field description, you can find it in the [Catalog Process API document](https://anypoint.mulesoft.com/exchange/a31966b0-fc4e-4ac8-af23-c40fc73ce072.apps-tech-ais/catalog-process-api/1.1.0/console/method/%23507/).

---
### Integrate with OpenShift

#### Pipeline

When you are ready to deploy this API, the only thing you need to do is login to your OpenShift
instance, chose the appropriate project and run the following command:

```shell
oc apply -f openshift/core-mq-service-openshift-build-pipeline.yaml
oc apply -f openshift/core-mq-service-openshift-nonprod-deploy-pipeline.yaml
```

This command will create a pipeline, which is configured to pull down the project
from the appropriate repository and use the Jenkinsfile.build and Jenkinsfile.nonprod as the pipeline definition.

#### Building artifacts and storing them

The Jenkins file has a stage to download the code, once that is done it runs the tests and tries to
build a docker image. The building and storing of the docker image is done in OpenShift
and those steps are defined in the [core-mq-service-build-and-imagestream.yaml](openshift/core-mq-service-build-and-imagestream.yaml).

Before the artifact is built, the latest configuration needs to be applied to OpenShift by running the following command:
`oc apply -f openshift/core-mq-service-build-and-imagestream.yaml`

The first part of the file defines an [imagestream][4]
and a tag for the images that are being created:
```yaml
apiVersion: v1
kind: ImageStream
metadata:
  name: core-mq-service
  labels:
    application: core-mq-service
spec:
  tags:
  - name: latest
```

The project uses imagestream in order to store all of the metadata information about the images that
are built.

The second part of the file defines how the project builds the image:
```yaml
apiVersion: v1
kind: BuildConfig
metadata:
  name: core-mq-service
spec:
  output:
    to:
      kind: ImageStreamTag
      name: core-mq-service:latest
  source:
    binary: {}
    type: Binary
  strategy:
    dockerStrategy: {}
    type: Docker
  successfulBuildsHistoryLimit: 5
  triggers:
  - gitlab:
      secret: 4004467cd5785fb4
    type: GitLab
```

The code above defines build configuration which depends on a binary source, which means that the content needs to be '
provided to the build from the local file system. The configuration also points out that the tag of this image will be
stored in the previously created image stream. In order to provide the content for the build step to OpenShift the
Jenkinsfile runs the following command:

`oc start-build core-mq-service --from-archive=core-mq-service.tar --follow`

The core-mq-service.tar file contains the jar file for this service and also a Dockerfile. The Dockerfile is
used by the Docker strategy defined in code above. When OpenShift starts building the image it will refer to
the Dockerfile in order to understand how to build it.

Once the image build is done, it gets tagged as latest and its metadata gets stored in the imagestream that was defined
earlier.


#### Deployment
Once the image is built and pushed to a repository, the image needs to be deployed. Before the deployment of the
image OpenShift needs to be updated with the latest configuration of the deployment template by running this command:

```
oc process -f openshift/core-mq-service-deployment-config.yaml \
    -p DOCKER_REGISTRY='${imageStream}:${gitCommitId}' | oc replace -f -
```

The first part of the command is used to replace placeholders in the core-mq-service-template.yaml(DOCKER_REGISTRY)
with an actual value, which in this case is the location of the last built image. The output of the first command is used
to update the configuration in OpenShift.

The [openshift/core-mq-service-deployment-config.yaml](openshift/core-mq-service-deployment-config.yaml)
defines the deployment config that we use to deploy our application.

The Deployment Config defines the deployment of three containers.
The first container is our application as defined below:
```yaml
 - env:
    - name: SPRING_PROFILES_ACTIVE
     value: qa
    - name: NODE_NAME
     valueFrom:
       fieldRef:
         fieldPath: spec.nodeName
    - name: POD_NAME
     valueFrom:
       fieldRef:
         fieldPath: metadata.name
    - name: POD_NAMESPACE
     valueFrom:
       fieldRef:
         fieldPath: metadata.namespace
    - name: POD_ID
     valueFrom:
       fieldRef:
         fieldPath: status.podIP
    - name: SECRET_USERNAME
     valueFrom:
       secretKeyRef:
         key: username
         name: application-secret
    - name: SECRET_PASSWORD
     valueFrom:
       secretKeyRef:
         key: password
         name: application-secret
    image: ${DOCKER_REGISTRY}
    name: core-mq-service
    ports:
    - containerPort: 8080
    readinessProbe:
     failureThreshold: 10
     httpGet:
       path: /actuator/health
       port: 8080
     initialDelaySeconds: 30
     periodSeconds: 10
     timeoutSeconds: 5
    resources:
     limits:
       cpu: 400m
       memory: 1Gi
```
The code above defines the name of the service(*name*), where is the image located for the new deployment(*image*)
and on which port is the service running(*ports[0].containerPort*). In the deployment configuration, the limits
for resources the pod needs are defined(in this case 500m for CPU and 1Gi for memory), and a readiness check is created
which calls the service after its deployed in order to check if the service is ready to serve traffic.

As part of the deployment the nodeName, podName, podId and podNamespace are injected as environment
variables to the pod(*env*).

The second and third containers that are deployed are defined here:
```yaml
- args:
  - proxy
  - sidecar
  - --configPath
  - /etc/istio/proxy
  - --binaryPath
  - /usr/local/bin/envoy
  - --serviceCluster
  - core-mq-service
  - --drainDuration
  - 45s
  - --parentShutdownDuration
  - 1m0s
  - --discoveryAddress
  - istio-pilot.istio-system:15007
  - --discoveryRefreshDelay
  - 10s
  - --zipkinAddress
  - zipkin.istio-system:9411
  - --connectTimeout
  - 10s
  - --statsdUdpAddress
  - istio-statsd-prom-bridge.istio-system:9125
  - --proxyAdminPort
  - "15000"
  - --controlPlaneAuthPolicy
  - NONE
  env:
  - name: POD_NAME
    valueFrom:
      fieldRef:
        fieldPath: metadata.name
  - name: POD_NAMESPACE
    valueFrom:
      fieldRef:
        fieldPath: metadata.namespace
  - name: INSTANCE_IP
    valueFrom:
      fieldRef:
        fieldPath: status.podIP
  - name: ISTIO_META_POD_NAME
    valueFrom:
      fieldRef:
        fieldPath: metadata.name
  - name: ISTIO_META_INTERCEPTION_MODE
    value: REDIRECT
  image: docker.apphn.ocp.na.xom.com/istio/proxyv2:0.8.0
  imagePullPolicy: IfNotPresent
  name: istio-proxy
  resources:
    requests:
      cpu: 100m
      memory: 128Mi
  securityContext:
    privileged: false
    readOnlyRootFilesystem: true
    runAsUser: 1337
  volumeMounts:
  - mountPath: /etc/istio/proxy
    name: istio-envoy
  - mountPath: /etc/certs/
    name: istio-certs
    readOnly: true
initContainers:
- args:
  - -p
  - "15001"
  - -u
  - "1337"
  - -m
  - REDIRECT
  - -i
  - '*'
  - -x
  - ""
  - -b
  - 8080,
  - -d
  - ""
  image: docker.apphn.ocp.na.xom.com/istio/proxy_init:0.8.0
  imagePullPolicy: IfNotPresent
  name: istio-init
  resources: {}
  securityContext:
    capabilities:
      add:
      - NET_ADMIN
    privileged: true
volumes:
- emptyDir:
    medium: Memory
  name: istio-envoy
- name: istio-certs
  secret:
    optional: true
    secretName: istio.default
```
All of this configuration is automatically generated by istio. This configuration deploys the sidecar proxy
and the proxy-init.

####Service

In the [openshift/core-mq-service-service.yaml](openshift/core-mq-service-service.yaml) we define
a [service][5]:
```yaml
- apiVersion: v1
  kind: Service
  metadata:
    name: core-mq-service
  spec:
    selector:
      app: core-mq-service
    ports:
    - port: 8080
      name: http
      protocol: TCP
      targetPort: 8080
```
Creation of a core-mq-service service is accomplished by the code above. The service is pointing
to the version v1 and exposes port 8080 for this service.

In order to apply this configuration on OpenShift the Jenkinsfile runs the following command:
```
oc apply -f openshift/core-mq-service-service.yaml
```

### Integrate with Istio

#### Create routing rules
Routing rules enable you to send traffic to different versions of a service by different criteria. To do this with any
service, you will need to create a routing rules file with a virtual service and destination rules.

What is in the routing rules file

 1. VirtualService - Defines the traffic rules to apply when a host is addressed. If the traffic rule is matched, its
 sent to the destination or a subset/version of it.
 2. DestinationRule - A subset/version of a route destination is identified with a reference to a named service subset
 declared in DestinationRule

To apply the rules and test, follow these steps

Create new istio rule - following command will create new istio routing rule in openshift
  `istioctl create -f <location of the rule config> -n <project name in openshift>`

E.g.:
   `istioctl create -f istio/core-mq-service-routing-with-percentage.yaml -n flcit-cst`

Once the rule is created, you can navigate to the rule in openshift as follows

1. Select the project where your service resides
1. Navigate to Resources=>Other Resources
1. In the dropdown "Choose a resource list" choose "Virtual Service".
1. Go to "Actions" dropdown on your rule and select "Edit YAML"
1. Change the weights for different versions as you want to route the traffic among different versions
1. Test that your rules are working

### Integrate with SAP Stripe

`core-mq-service` uses `odataclient` lib to integrate with SAP. It will send requests to the OData
API on NetWeaver Gateway and the OData API will request to the Stripe and respond the data back.
[This document][8] explains how to use `odataclient` and all the required configurations.

`CountryController` is a demonstration of SAP integration, which exposes the following 2 endpoints:
- `GET /countries`: get all the countries.
- `GET /countries/{countryCode}`: get one country by the country code.

#### How to use and configure the country endpoints

- Please follow the [Prerequisites](#authentication--authorization) to finish the Azure AD setup.
- Properties
    ```properties
    sap.service.url=<URL of the OData API in NetWeaver Gateway, e.g. https://dalngdw1.na.xom.com/sap/opu/odata/sap/>
    sap.service.username=<Service ID username to access the NetWeaver health check endpoint: /sap/bc/ping>
    sap.service.password=<Service ID password to access the NetWeaver health check endpoint: /sap/bc/ping>
    sap.service.timeout = <Optional. Connection timeout, default 10000 (10s)>
    sap.service.saml-bearer.clientId = <SAP oauth client id>
    sap.service.saml-bearer.clientScope = <SAP oauth client scope>
    sap.service.saml-bearer.clientUsername = <SAP oauth client username, typically it's same as client id>
    sap.service.saml-bearer.clientPassword = <SAP oauth client password>
    sap.service.saml-bearer.tokenEndpoint = <Optional. SAP oauth endpoint. Default: "/sap/bc/sec/oauth2/token">
    ```
- Authentication
    `core-mq-service` will use the the OIDC JWT token to do the authentication check, please ensure
    the token is set in the `Authorization` header when accessing the endpoints. `core-mq-service`
    will do the following check to accomplish the authentication check:
    - *Signature Check*: to ensure the token is issued from Azure AD. Please ensure the following
      property is set properly:
        ```properties
        security.oauth2.resource.jwk.keySetUri=https://login.microsoftonline.com/common/discovery/keys
        ```
    - *Audience Check*: to ensure the token is issued for `core-mq-service`. Please ensure the
      following property is set properly:
        ```properties
        security.oauth2.resource.id=abecaf4b-9c1d-4d74-8846-da5158e6cd47
        ```
    - *Expiry Date Check*: to avoid the token replay attack.
    - *Issuer Check*: to ensure the token is issued by ExxonMobil Azure AD tenant. Please ensure the
      following property is set properly:
        ```properties
        security.oauth2.resource.issuer=https://sts.windows.net/d1ee1acd-bc7a-4bc4-a787-938c49a83906/
        ```
- Authorization
    `core-mq-service` will accept the SAML Assertion from the http request header `SAML-Assertion`
    and use it to do the SAP authentication and authorization. Please ensure this SAML Assertion is
    exchanged/issued from Azure AD. You can refer to [dashboard-web][18] on how to create it.
- Implementation
    The following are how `core-mq-service` integrates with SAP in the code:
    1. Inject the `ODataClient` to `CountryRepository.java`, which is defined in
       `com.xom.odataclient.configuration.ODataClientAutoConfig`.
    1. Use the api that odata provide to access SAP API and get the response data
    1. Format the response data that sap api return to our model

### Load resource from OpenShift

For SAP access credential, we need configure it in Open Shift resource in encrypted text rather than
plain text in codebase.

1. Configure environment parameters in Open Shift configuration file
   [core-mq-service-deployment-config.yaml](openshift/core-mq-service-deployment-config.yaml)

    ```yaml
    ...
    spec:
      containers:
      - env:
        - name: SAP_ODATA_USERNAME
          valueFrom:
            secretKeyRef:
              key: username
              name: sap.odata
        - name: SAP_ODATA_PASSWORD
          valueFrom:
            secretKeyRef:
              key: password
              name: sap.odata
    ...
    ```

    `SAP_ODATA_USERNAME` and `SAP_ODATA_PASSWORD` are the environment parameters which are used to
    get credentials from Openshift.

1. Configure secret in Open Shift resource. In Open Shift, we can set the username and password for each secret,
and assign it to a specific application.

1. Expose the secret to environment parameters and use it in service. We can use Spring Value annotation to fetch the
secret username and password and assign it to the variable.

    ```java
    @Value("${SAP_ODATA_USERNAME:undefined}")
    private String basicUserName;

    @Value("${SAP_ODATA_PASSWORD:undefined}")
    private String basicPassword;
    ```

### Prometheus

Please see the document on this particular topic [here](custom-metric-readme.md).

### Tracing
In order to use Jaeger there are two steps:
* Add the dependency to build.gradle.

```groovy
 compile 'io.jaegertracing:jaeger-client:0.30.4'
```

* Add Jaeger Bean to the Application class.

```java
  @Bean
  public Tracer jaegerTracer() {
    B3TextMapCodec codec = new B3TextMapCodec.Builder().build();
    return new JaegerTracer.Builder("core-mq-service")
        .registerInjector(Format.Builtin.HTTP_HEADERS, codec)
        .registerExtractor(Format.Builtin.HTTP_HEADERS, codec)
        .build();

  }
```

Once the services have been started and the client has triggered at least one request, you can now open the
[Jaeger UI][6] selecting the “client” service to see the captured
traces.

If you select one, then the details view will show the interactions between client, service1 and service2.

### Visualization with Grafana

Grafana allows you to query, visualize, alert on and understand metrics from your services. To set up and view dashboards, Go to:
* Non-Prod - https://grafana-istio-system.apphn.ocp.na.xom.com
* Production - (TBD)

Follow [this guide][7] to get started with viewing, adding and editing dashboards, graphs and panels

[1]: https://www.liquibase.org
[2]: https://docs.apphn.ocp.na.xom.com/index.php/Getting_an_Application_to_Production
[3]: https://gitserver.xtonet.com/caas-public/promotion-reference/tree/master
[4]: https://docs.openshift.com/enterprise/3.0/architecture/core_concepts/builds_and_image_streams.html#image-streams
[5]: https://docs.openshift.com/online/architecture/core_concepts/pods_and_services.html#services
[6]: https://tracing-istio-system.apphn.ocp.na.xom.com
[7]: http://docs.grafana.org/guides/getting_started/
[8]: https://gitserver.xtonet.com/SMKT-CST/common/libraries/odataclient
[9]: https://portal.azure.com/#blade/Microsoft_AAD_IAM/ActiveDirectoryMenuBlade/Overview
[10]: https://gitserver.xtonet.com/SMKT-CST/starter-kit/starter-kit-guide/wikis/Glossary-for-Authentication-and-Authorization#identity-provider-idp
[11]: https://gitserver.xtonet.com/SMKT-CST/starter-kit/starter-kit-guide/wikis/Glossary-for-Authentication-and-Authorization#openid-connect-oidc
[12]: https://gitserver.xtonet.com/SMKT-CST/starter-kit/starter-kit-guide/wikis/How-To-Configure-Azure-AD
[13]: https://gitserver.xtonet.com/SMKT-CST/starter-kit/starter-kit-guide/wikis/Glossary-for-Authentication-and-Authorization#resource-server
[14]: https://gitserver.xtonet.com/SMKT-CST/starter-kit/starter-kit-guide/wikis/Glossary-for-Authentication-and-Authorization#app-role
[15]: https://gitserver.xtonet.com/SMKT-CST/starter-kit/starter-kit-guide/wikis/How-To-Configure-Azure-AD#assign-app-role-to-consumers
[16]: https://gitserver.xtonet.com/SMKT-CST/starter-kit/starter-kit-guide/wikis/How-To-Configure-Azure-AD#create-app-role
[17]: https://gitserver.xtonet.com/SMKT-CST/starter-kit/starter-kit-guide/wikis/How-To-Configure-Azure-AD#azure-ad-changes-1
[18]: https://gitserver.xtonet.com/SMKT-CST/starter-kit/dashboard-web
[20]: https://docs.spring.io/spring-boot/docs/current/reference/html/common-application-properties.html

