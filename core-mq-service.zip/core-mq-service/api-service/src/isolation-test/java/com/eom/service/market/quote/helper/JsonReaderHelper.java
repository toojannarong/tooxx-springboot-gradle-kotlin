package com.eom.service.market.quote.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Charsets;
import com.google.common.io.Resources;

import java.io.IOException;
import java.net.URL;

public class JsonReaderHelper {

  public static String readFromResourceFileAndMinify(String fileName) throws IOException {
    URL url = Resources.getResource(fileName);
    String text = Resources.toString(url, Charsets.UTF_8);

    ObjectMapper objectMapper = new ObjectMapper();
    JsonNode jsonNode = objectMapper.readValue(text, JsonNode.class);

    return jsonNode.toString();
  }

}
