package com.eom.service.market.quote.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.domain.entity.QuotationEntityId;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class QuotationEntityRepositoryIsolationTest {

  private static final LocalDateTime LOCAL_DATE_TIME = LocalDateTime.of(1997, 7, 30, 13, 5, 0, 0);

  private static final String DATE = "20140311";

  @Autowired
  private QuotationEntityRepository quotationEntityRepository;

  private List<QuotationEntity> exampleQuotationEntity = generateQuotationEntity();

  @BeforeEach
  void setUp() {
    quotationEntityRepository.save(exampleQuotationEntity.get(0));
    quotationEntityRepository.save(exampleQuotationEntity.get(1));
    quotationEntityRepository.save(exampleQuotationEntity.get(2));

    List<QuotationEntity> entityWithAnotherId = generateQuotationEntity();
    entityWithAnotherId.get(0).getQuotationEntityId().setId("GAS20TRUCK");
    entityWithAnotherId.get(1).getQuotationEntityId().setId("GAS20TRUCK");
    entityWithAnotherId.get(2).getQuotationEntityId().setId("GAS20TRUCK");
    quotationEntityRepository.save(entityWithAnotherId.get(0));
    quotationEntityRepository.save(entityWithAnotherId.get(1));
    quotationEntityRepository.save(entityWithAnotherId.get(2));
  }

  @AfterEach
  void cleanUp() {
    quotationEntityRepository.deleteAll();
  }

  @Test
  void findByQuotationEntityId() {
    QuotationEntityId quotationEntityId = new QuotationEntityId("DIESEL10CAR", "A1", DATE, "H");
    Optional<QuotationEntity> quotationEntity =
        quotationEntityRepository.findById(quotationEntityId);

    assertTrue(quotationEntity.isPresent());

    assertEquals(quotationEntity.get(), exampleQuotationEntity.get(0));
  }

  @Test
  void notFindByQuotationEntityId() {
    QuotationEntityId quotationEntityId = new QuotationEntityId("NON_EXISTENT_ID", "A1",
        DATE, "H");
    Optional<QuotationEntity> quotationEntity = quotationEntityRepository
        .findById(quotationEntityId);

    assertFalse(quotationEntity.isPresent());
  }

  private List<QuotationEntity> generateQuotationEntity() {
    return Arrays.asList(QuotationEntity.builder()
            .quotationEntityId(new QuotationEntityId("DIESEL10CAR", "A1", DATE, "H"))
            .price("200.000000")
            .unitOfMeasure("TO")
            .currency("USD")
            .createdAt(LOCAL_DATE_TIME)
            .updatedAt(null)
            .build(),
        QuotationEntity.builder()
            .quotationEntityId(new QuotationEntityId("DIESEL10CAR", "A1", DATE, "M"))
            .price("150.000000")
            .unitOfMeasure("TO")
            .currency("USD")
            .createdAt(LOCAL_DATE_TIME)
            .updatedAt(null)
            .build(),
        QuotationEntity.builder()
            .quotationEntityId(new QuotationEntityId("DIESEL10CAR", "A1", DATE, "L"))
            .price("100.000000")
            .unitOfMeasure("TO")
            .currency("USD")
            .createdAt(LOCAL_DATE_TIME)
            .updatedAt(null)
            .build()
    );
  }
}