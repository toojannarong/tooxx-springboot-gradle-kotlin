package com.eom.service.market.quote.service;

import com.eom.service.market.quote.api.response.ResponseContainer;
import com.eom.service.market.quote.domain.FactoryCalendar;
import com.eom.service.market.quote.domain.Price;
import com.eom.service.market.quote.domain.Quotation;
import com.eom.service.market.quote.domain.QuotationPrice;
import com.eom.service.market.quote.domain.QuotationSource;
import com.eom.service.market.quote.domain.QuotationType;
import com.eom.service.market.quote.domain.StripesReference;
import com.eom.service.market.quote.domain.StripesReferenceHeader;
import com.eom.service.market.quote.domain.UnitOfMeasure;
import com.eom.service.market.quote.domain.entity.GrdbUomEntity;
import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.domain.entity.QuotationEntityId;
import com.eom.service.market.quote.domain.entity.TM1UomEntity;
import com.eom.service.market.quote.domain.fromsap.PriceTypeSAP;
import com.eom.service.market.quote.domain.fromsap.QuotationIdSAP;
import com.eom.service.market.quote.domain.fromsap.QuotationSAP;
import com.eom.service.market.quote.domain.fromsap.QuotationSourceSAP;
import com.eom.service.market.quote.domain.fromsap.UnitOfMeasurementSAP;
import com.eom.service.market.quote.domain.fromsap.UomSAP;
import com.eom.service.market.quote.domain.fromtm1.QuotationTM1;
import com.eom.service.market.quote.repository.GrdbUomEntityRepository;
import com.eom.service.market.quote.repository.QuotationEntityRepository;
import com.eom.service.market.quote.repository.TM1UomEntityRepository;
import com.eom.service.market.quote.support.IsolationTest;
import com.google.common.collect.ImmutableList;
import com.microsoft.azure.eventhubs.EventData;
import com.xom.errors.exceptions.SystemException;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;

import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_QUOTE_BETWEEN_DAYS;
import static com.eom.service.market.quote.util.Constant.STRIPES_LIST;
import static com.xom.odataclient.domain.Stripe.AP;
import static com.xom.odataclient.domain.Stripe.EU;
import static com.xom.odataclient.domain.Stripe.NA;
import static java.time.LocalDate.now;
import static java.time.format.DateTimeFormatter.ofPattern;
import static java.util.Collections.singletonList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class SchedulerServiceIsolationTest extends IsolationTest {

  private final static LocalDateTime LOCAL_DATE_TIME = LocalDateTime.of(1997, 7, 30, 13, 5, 0, 0);

  @Autowired
  private QuotationEntityRepository quotationEntityRepository;

  @Autowired
  private SchedulerService schedulerService;

  @MockBean
  private RestTemplate restTemplate;

  @BeforeEach
  void setup() {
    redisTemplate.getConnectionFactory().getConnection().flushAll();
  }

  private void setupForSAP() {
    mockEventHub();
    mockForTheQuoteSources();
    mockForStaticData();
  }

  private void setupForTM1() {
    mockEventHub();
    mockQueryForPriceTypeDescription();
    mockQueryForQuoteSourceFromTM1();
  }

  @AfterEach
  void cleanUp() {
    quotationEntityRepository.deleteAll();
  }

  @Test
  void shouldPublishAndSaveNewQuoteWhenDoesntExistInDatabaseGivenQuotationSAP() {
    setupForSAP();
    mockQuotationADNOCFORMC("A2", EU);

    schedulerService.scheduledTaskSAP();

    verify(realtimeEventHub).send(expectedValueForQuotationFromSAP("A2"));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get());
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get()
            .getCreatedAt());
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get()
            .getUpdatedAt());
    assertEquals("USD",
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get()
            .getCurrency());
    assertEquals("BB6",
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get()
            .getUnitOfMeasure());
    assertEquals("ZH",
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get()
            .getCalendarCode());
    assertEquals("Only Tuesday workday",
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get()
            .getCalendarDescription());
  }

  @Test
  void shouldPublishAndSaveAllNewQuotesWhenDontExistInDatabaseGivenQuotationSAP() {
    setupForSAP();
    mockTwoQuotationsSAPFromQuoteSourceA2();

    schedulerService.scheduledTaskSAP();

    verify(realtimeEventHub).send(expectedTwoValuesForQuotationFromSAP());
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get());
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "M")).get());
  }

  @Test
  void shouldPublishAndSaveOnlyNewQuoteWhenDoesntExistInDatabaseGivenQuotationSAP() {
    setupForSAP();
    mockTwoQuotationsSAPFromQuoteSourceA2();
    quotationEntityRepository
        .save(createQuotationEntity("A2", "M", "USD", "2.000000", "BB6", LOCAL_DATE_TIME, null));

    schedulerService.scheduledTaskSAP();

    verify(realtimeEventHub).send(expectedValueForQuotationFromSAP("A2"));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get());
  }

  @Test
  void shouldPublishAndSaveNewQuoteWhenDoesntExistInDatabaseGivenQuotationTM1() {
    setupForTM1();
    QuotationTM1[] quotationTM1s = {QuotationTM1.builder()
        .quoteName("ALGNQNCITYGTCF")
        .quoteSource("PN")
        .value("2.33")
        .date(now().format(ofPattern("yyyyMMdd")))
        .quoteType("V")
        .currency("")
        .uom("")
        .cube("PLTMONG")
        .build()};
    when(restTemplate.getForEntity(ArgumentMatchers.any(URI.class), eq(QuotationTM1[].class)))
        .thenReturn(ResponseEntity.ok(quotationTM1s));

    schedulerService.scheduledTaskTM1();

    verify(realtimeEventHub)
        .send(expectedValueForQuotationFromTM1("PN_DESCRIPTION", "V", "VOLUME"));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ALGNQNCITYGTCF", "PN", "V"))
            .get());
  }

  @Test
  void shouldNotPublishAndSaveQuoteWhenQuoteExistInDatabaseGivenQuotationSAP() {
    setupForSAP();
    quotationEntityRepository.save(
        createQuotationEntity("A2", "H", "USD", "1.000000", "BB6", LOCAL_DATE_TIME,
            LOCAL_DATE_TIME));
    when(oDataClient.executeOSQL(eq(queryForQuotations("A2", EU)), eq(QuotationSAP.class)))
        .thenReturn(Stream.of(
            QuotationSAP.builder()
                .sourceCode("A2")
                .quotationNumber("ADNOCFORMC")
                .date(now().format(ofPattern("yyyy-MM-dd")))
                .quoteType("H")
                .quotePrice(100.00)
                .quantityForUom(100)
                .unitOfMeasureCode("BB6")
                .currency("USD")
                .factoryCalendarCode("ZH")
                .factoryCalendarDescription("Only Tuesday workday")
                .build()
        ));

    schedulerService.scheduledTaskSAP();

    verify(realtimeEventHub, never()).send(expectedValueForQuotationFromSAP("A2"));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get());
  }

  @Test
  void shouldNotPublishAndSaveQuoteWhenQuoteExistInDatabaseGivenQuotationTM1() {
    setupForTM1();
    quotationEntityRepository
        .save(createQuotationEntityFromTM1("V", "2.330000", LOCAL_DATE_TIME, LOCAL_DATE_TIME));
    QuotationTM1[] quotationTM1s = {QuotationTM1.builder()
        .quoteName("ALGNQNCITYGTCF")
        .quoteSource("PN")
        .value("2.33")
        .date(now().format(ofPattern("yyyyMMdd")))
        .quoteType("V")
        .currency("")
        .uom("")
        .cube("PLTMONG")
        .build()
    };
    when(restTemplate.getForEntity(ArgumentMatchers.any(URI.class), eq(QuotationTM1[].class)))
        .thenReturn(ResponseEntity.ok(quotationTM1s));

    schedulerService.scheduledTaskTM1();

    verify(realtimeEventHub, never())
        .send(expectedValueForQuotationFromTM1("PN_DESCRIPTION", "V", "VOLUME"));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ALGNQNCITYGTCF", "PN", "V"))
            .get());
  }

  @Test
  void shouldPublishAndSaveNewQuoteWhenQuoteExistInDatabaseButValueIsDifferentGivenQuotationSAP() {
    setupForSAP();
    mockQuotationADNOCFORMC("A2", EU);
    quotationEntityRepository.save(
        createQuotationEntity("A2", "H", "USD", "2.000000", "BB6", LOCAL_DATE_TIME,
            LOCAL_DATE_TIME));

    schedulerService.scheduledTaskSAP();

    verify(realtimeEventHub).send(expectedValueForQuotationFromSAP("A2"));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get());
    assertEquals("1.000000",
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get()
            .getPrice());
  }

  @Test
  void shouldPublishAndSaveNewQuoteWhenQuoteExistInDatabaseButValueIsDifferentGivenQuotationTM1() {
    setupForTM1();
    quotationEntityRepository
        .save(createQuotationEntityFromTM1("V", "2.340000", LOCAL_DATE_TIME, LOCAL_DATE_TIME));
    QuotationTM1[] quotationTM1s = {QuotationTM1.builder()
        .quoteName("ALGNQNCITYGTCF")
        .quoteSource("PN")
        .value("2.33")
        .date(now().format(ofPattern("yyyyMMdd")))
        .quoteType("V")
        .currency("")
        .uom("")
        .cube("PLTMONG")
        .build()};
    when(restTemplate.getForEntity(ArgumentMatchers.any(URI.class), eq(QuotationTM1[].class)))
        .thenReturn(ResponseEntity.ok(quotationTM1s));

    schedulerService.scheduledTaskTM1();

    verify(realtimeEventHub)
        .send(expectedValueForQuotationFromTM1("PN_DESCRIPTION", "V", "VOLUME"));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ALGNQNCITYGTCF", "PN", "V"))
            .get());
    assertEquals("2.330000",
        quotationEntityRepository.findById(createQuotationEntityId("ALGNQNCITYGTCF", "PN", "V"))
            .get().getPrice());
  }

  @Test
  void shouldPublishAndSaveEUQuotationWhenGetQuotationGivenOtherStripesAreDown() {
    setupForSAP();
    mockQuotationADNOCFORMC("A2", EU);
    mockFailedSAPStripeWhenGetQuotation("P7", AP);
    mockFailedSAPStripeWhenGetQuotation("A1", NA);

    schedulerService.scheduledTaskSAP();

    verify(realtimeEventHub).send(expectedValueForQuotationFromSAP("A2"));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get());
  }

  @Test
  void shouldPublishAndSaveNAQuotationWhenGetQuotationGivenOtherStripesAreDown() {
    setupForSAP();
    mockQuotationADNOCFORMC("A1", NA);
    mockFailedSAPStripeWhenGetQuotation("P7", AP);
    mockFailedSAPStripeWhenGetQuotation("A2", EU);

    schedulerService.scheduledTaskSAP();

    verify(realtimeEventHub).send(expectedValueForQuotationFromSAP("A1"));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A1", "H")).get());

  }

  @Test
  void shouldPublishAndSaveAPQuotationWhenGetQuotationGivenOtherStripesAreDown() {
    setupForSAP();
    mockQuotationADNOCFORMC("P7", AP);
    mockFailedSAPStripeWhenGetQuotation("A2", EU);
    mockFailedSAPStripeWhenGetQuotation("A1", NA);

    schedulerService.scheduledTaskSAP();

    verify(realtimeEventHub).send(expectedValueForQuotationFromSAP("P7"));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "P7", "H")).get());
  }

  @Test
  void shouldPublishAndSaveQuotationWhenGetQuotationGivenTM1IsDown() {
    setupForTM1();
    setupForSAP();
    mockQuotationADNOCFORMC("A2", EU);
    mockFailedTM1WhenGetQuotation("PN", EU);

    schedulerService.scheduledTaskSAP();

    verify(realtimeEventHub).send(expectedValueForQuotationFromSAP("A2"));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ADNOCFORMC", "A2", "H")).get());

  }

  @Test
  void shouldPublishAndSaveNewQuoteWithDescriptionWhenSAPIsDownAndCachedGivenQuotationTM1() {
    mockEventHub();
    mockQueryForPriceTypeDescription();
    mockCacheQuotationPriceTypeDescription();
    mockCacheQuotationSourceDescription();
    mockQuotationTM1();
    mockFailedSAPStripeWhenGetTypeDescription();
    mockFailedSAPStripeWhenGetQuotationSourceSAP();

    schedulerService.scheduledTaskTM1();

    verify(realtimeEventHub).send(expectedValueForQuotationFromTM1("PN_DESCRIPTION", "H", "HIGH"));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ALGNQNCITYGTCF", "PN", "H"))
            .get());
  }

  @Test
  void shouldPublishAndSaveNewQuoteWithoutDescriptionWhenSAPIsDownAndNotCachedGivenQuotationTM1() {
    mockEventHub();
    mockQuotationTM1();
    mockFailedSAPStripeWhenGetTypeDescription();
    mockFailedSAPStripeWhenGetQuotationSourceSAP();

    schedulerService.scheduledTaskTM1();

    verify(realtimeEventHub).send(expectedValueForQuotationFromTM1("", "H", ""));
    assertNotNull(
        quotationEntityRepository.findById(createQuotationEntityId("ALGNQNCITYGTCF", "PN", "H"))
            .get());
  }

  private void mockFailedSAPStripeWhenGetQuotationSourceSAP() {
    when(oDataClient.executeOSQL((SingleOSqlQuery) any(), eq(QuotationSourceSAP.class)))
        .thenThrow(new SystemException());
  }

  private void mockFailedSAPStripeWhenGetTypeDescription() {
    when(oDataClient.executeOSQL(eq(buildSingleOSqlQueryForTypeDescription("H", EU)),
        eq(PriceTypeSAP.class))).thenThrow(new SystemException());
  }

  private void mockQuotationTM1() {
    QuotationTM1[] quotationTM1s = {QuotationTM1.builder()
        .quoteName("ALGNQNCITYGTCF")
        .quoteSource("PN")
        .value("2.33")
        .date(now().format(ofPattern("yyyyMMdd")))
        .quoteType("H")
        .currency("")
        .uom("")
        .cube("PLTMONG")
        .build()};
    when(restTemplate.getForEntity(ArgumentMatchers.any(URI.class), eq(QuotationTM1[].class)))
        .thenReturn(ResponseEntity.ok(quotationTM1s));
  }

  private void mockFailedSAPStripeWhenGetQuotation(String quoteSource, Stripe stripe) {
    when(oDataClient
        .executeOSQL(eq(queryForQuotations(quoteSource, stripe)), eq(QuotationSAP.class)))
        .thenThrow(new SystemException());
  }


  private void mockFailedTM1WhenGetQuotation(String quoteSource, Stripe stripe) {
    when(oDataClient
        .executeOSQL(eq(queryForQuotations(quoteSource, stripe)), eq(QuotationSAP.class)))
        .thenThrow(new SystemException());
  }

  private EventData expectedValueForQuotationFromSAP(String quoteSource) {
    Quotation expectedEvent = Quotation.builder()
        .stripesReference(StripesReferenceHeader.builder()
            .description("ADNOC FORMURA")
            .id("ADNOCFORMC")
            .source(
                QuotationSource.builder()
                    .code(quoteSource)
                    .description("ARGUS NWE")
                    .build()
            )
            .calendar(
                FactoryCalendar.builder()
                    .code("ZH")
                    .description("Only Tuesday workday")
                    .build())
            .build())
        .prices(ImmutableList.of(
            QuotationPrice.builder()
                .date(now().format(ofPattern("yyyy-MM-dd")))
                .stripesReference(StripesReference.builder()
                    .type(
                        QuotationType.builder()
                            .code("H")
                            .description("HIGH")
                            .build()
                    )
                    .uom(UnitOfMeasure.builder()
                        .code("BB6")
                        .description("Barrel at 60 degrees")
                        .build())
                    .build())
                .price(Price.builder()
                    .currency("USD")
                    .amount("1.000000")
                    .build())
                .uom(
                    UnitOfMeasure.builder()
                        .code("A95")
                        .description("Gray")
                        .build()
                )
                .build()))
        .build();

    return EventData
        .create(ResponseContainer.buildDataJson(expectedEvent).getBytes(StandardCharsets.UTF_8));
  }

  private EventData expectedTwoValuesForQuotationFromSAP() {
    Quotation expectedEvent = Quotation.builder()
        .stripesReference(StripesReferenceHeader.builder()
            .description("ADNOC FORMURA")
            .id("ADNOCFORMC")
            .source(
                QuotationSource.builder()
                    .code("A2")
                    .description("ARGUS NWE")
                    .build()
            )
            .calendar(
                FactoryCalendar.builder()
                    .code("ZH")
                    .description("Only Tuesday workday")
                    .build())
            .build())
        .prices(ImmutableList.of(
            QuotationPrice.builder()
                .date(now().format(ofPattern("yyyy-MM-dd")))
                .stripesReference(StripesReference.builder()
                    .type(
                        QuotationType.builder()
                            .code("H")
                            .description("HIGH")
                            .build()
                    )
                    .uom(UnitOfMeasure.builder()
                        .code("BB6")
                        .description("Barrel at 60 degrees")
                        .build())
                    .build())
                .price(Price.builder()
                    .currency("USD")
                    .amount("1.000000")
                    .build())
                .uom(
                    UnitOfMeasure.builder()
                        .code("A95")
                        .description("Gray")
                        .build()
                )
                .build(),
            QuotationPrice.builder()
                .date(now().format(ofPattern("yyyy-MM-dd")))
                .stripesReference(StripesReference.builder()
                    .type(
                        QuotationType.builder()
                            .code("M")
                            .description("MEDIUM")
                            .build()
                    )
                    .uom(UnitOfMeasure.builder()
                        .code("BB6")
                        .description("Barrel at 60 degrees")
                        .build())
                    .build())
                .price(Price.builder()
                    .currency("USD")
                    .amount("2.000000")
                    .build())
                .uom(
                    UnitOfMeasure.builder()
                        .code("A95")
                        .description("Gray")
                        .build()
                )
                .build()))
        .build();

    return EventData
        .create(ResponseContainer.buildDataJson(expectedEvent).getBytes(StandardCharsets.UTF_8));
  }

  private EventData expectedValueForQuotationFromTM1(String quoteSourceDescription,
                                                     String priceType, String priceTypeDescription) {
    Quotation expectedEvent = Quotation.builder()
        .stripesReference(StripesReferenceHeader.builder()
            .id("ALGNQNCITYGTCF")
            .description("Algonquin CG FDt Com")
            .source(
                QuotationSource.builder()
                    .code("PN")
                    .description(quoteSourceDescription)
                    .build()
            )
            .build())
        .prices(ImmutableList.of(
            QuotationPrice.builder()
                .date(now().format(ofPattern("yyyy-MM-dd")))
                .stripesReference(StripesReference.builder()
                    .type(
                        QuotationType.builder()
                            .code(priceType)
                            .description(priceTypeDescription)
                            .build()
                    )
                    .build())
                .price(Price.builder()
                    .amount("2.330000")
                    .currency("USD")
                    .build())
                .uom(UnitOfMeasure.builder()
                    .code("MBT")
                    .description("million Btu (IT)")
                    .build())
                .build()))
        .build();

    return EventData
        .create(ResponseContainer.buildDataJson(expectedEvent).getBytes(StandardCharsets.UTF_8));
  }

  private QuotationEntity createQuotationEntity(String sourceQuote, String type, String currency,
                                                String price, String unitOfMeasure, LocalDateTime createdAt, LocalDateTime updatedAt) {

    return QuotationEntity.builder()
        .quotationEntityId(QuotationEntityId.builder()
            .id("ADNOCFORMC")
            .sourceCode(sourceQuote)
            .date(now().format(ofPattern("yyyy-MM-dd")))
            .type(type)
            .build())
        .price(price)
        .currency(currency)
        .unitOfMeasure(unitOfMeasure)
        .calendarCode("ZH")
        .calendarDescription("Only Tuesday workday")
        .createdAt(createdAt)
        .updatedAt(updatedAt)
        .build();
  }

  private QuotationEntity createQuotationEntityFromTM1(String type, String price,
                                                       LocalDateTime createdAt, LocalDateTime updatedAt) {
    return QuotationEntity.builder()
        .quotationEntityId(QuotationEntityId.builder()
            .id("ALGNQNCITYGTCF")
            .sourceCode("Algonquin CG FDt Com")
            .sourceCode("PN")
            .date(now().format(ofPattern("yyyy-MM-dd")))
            .type(type)
            .build())
        .currency("USD")
        .price(price)
        .unitOfMeasure("")
        .calendarDescription(null)
        .calendarCode(null)
        .createdAt(createdAt)
        .updatedAt(updatedAt)
        .build();
  }

  private void mockQueryForQuoteId() {
    when(oDataClient.executeOSQL((SingleOSqlQuery) any(), eq(QuotationIdSAP.class)))
        .thenAnswer(invocation -> Stream.of(QuotationIdSAP.builder()
                .source("A2")
                .quotationIdDescription("ADNOC FORMURA")
                .id("ADNOCFORMC")
                .build(),
            QuotationIdSAP.builder()
                .source("P7")
                .quotationIdDescription("ADNOC FORMURA")
                .id("ADNOCFORMC")
                .build(),
            QuotationIdSAP.builder()
                .source("A1")
                .quotationIdDescription("ADNOC FORMURA")
                .id("ADNOCFORMC")
                .build()
        ));
  }

  private void mockForSAPUom() {
    when(oDataClient.executeOSQL((SingleOSqlQuery) any(), eq(UomSAP.class)))
        .thenAnswer(invocation -> Stream.of(UomSAP.builder()
            .unconvertedUom("BB6")
            .isoCode("A95")
            .convertedUom("BB6")
            .build()));
  }

  private void mockQueryForUom() {
    when(oDataClient.executeOSQL((SingleOSqlQuery) any(), eq(UnitOfMeasurementSAP.class)))
        .thenAnswer(invocation -> Stream.of(UnitOfMeasurementSAP
            .builder()
            .longDescription("Barrel at 60 degrees")
            .id("BB6")
            .build()));
  }

  private void mockPriceTypeDescription(String code, String typeDescription, Stripe stripe) {
    when(oDataClient.executeOSQL(eq(buildSingleOSqlQueryForTypeDescription(code, stripe)),
        eq(PriceTypeSAP.class))).thenAnswer(invocation -> Stream.of(
        PriceTypeSAP.builder()
            .typeDescription(typeDescription)
            .id(code)
            .language("EN")
            .build()));
  }

  private Map<String, String> getPriceTypeDescriptionMap() {
    Map<String, String> priceTypeDescriptionMap = new HashMap<>();
    priceTypeDescriptionMap.put("H", "HIGH");
    priceTypeDescriptionMap.put("M", "MEDIUM");
    priceTypeDescriptionMap.put("V", "VOLUME");
    return priceTypeDescriptionMap;
  }

  private SingleOSqlQuery queryForQuotations(String quoteSource, Stripe stripesInstance) {
    LocalDate today = now();
    String fromDateFormatted = today.minusDays(30).format(ofPattern("yyyyMMdd"));
    String toDateFormatted = today.format(ofPattern("yyyyMMdd"));

    String sql = String
        .format("SELECT OICQP~QUOTNO, OICQP~QUOSRC, OICQP~DEFUOM, OICQP~QUOTYP, OICQP~PRICE, " +
                "OICQP~DEFPER, OICQP~DEFCURR, OICQP~QUOTDATE, OICQC~FACTCAL, TFACT~LTEXT " +
                "FROM OICQP LEFT JOIN OICQC ON OICQC~QUOSRC EQ OICQP~QUOSRC " +
                "AND OICQC~QUOTNO EQ OICQP~QUOTNO AND OICQC~QUOTYP EQ OICQP~QUOTYP LEFT JOIN TFACT ON TFACT~IDENT EQ OICQC~FACTCAL " +
                "WHERE TFACT~SPRAS EQ 'E' AND OICQP~QUOSRC EQ '%s' " +
                "AND OICQP~QUOTDATE BETWEEN '%s' AND '%s'", quoteSource, fromDateFormatted,
            toDateFormatted);

    return SingleOSqlQuery.builder()
        .uid(MARKET_QUOTE_DOMAIN_QUOTE_BETWEEN_DAYS)
        .query(sql)
        .stripe(stripesInstance)
        .build();
  }

  private void mockQueryForQuoteSource() {
    when(oDataClient.executeOSQL((SingleOSqlQuery) any(), eq(QuotationSourceSAP.class)))
        .thenAnswer(invocation -> Stream.of(
            QuotationSourceSAP.builder().sourceDescription("ARGUS NWE").id("A2").build(),
            QuotationSourceSAP.builder().sourceDescription("ARGUS GERMANY").id("AG").build(),
            QuotationSourceSAP.builder().sourceDescription("OMR EUR/TON EAG").id("DR").build(),
            QuotationSourceSAP.builder().sourceDescription("PLATTS NWE").id("P2").build(),
            QuotationSourceSAP.builder().sourceDescription("PLATTS MED").id("P3").build(),
            QuotationSourceSAP.builder().sourceDescription("PLATTS SINGAPORE").id("P7").build(),
            QuotationSourceSAP.builder().sourceDescription("PLATTS SIGNAPORE PMA").id("PD").build(),
            QuotationSourceSAP.builder().sourceDescription("RIM JAPAN").id("R8").build(),
            QuotationSourceSAP.builder().sourceDescription("EXTAP WEEKLY ALPHAS").id("S1").build(),
            QuotationSourceSAP.builder().sourceDescription("SAUDI LPG").id("S3").build(),
            QuotationSourceSAP.builder().sourceDescription("A1_DESCRIPTION").id("A1").build()
        ));
  }

  private SingleOSqlQuery buildSingleOSqlQueryForTypeDescription(String type, Stripe stripe) {
    return SingleOSqlQuery.builder()
        .uid("MARKET_QUOTE_DOMAIN_PRICE_TYPE_DESCRIPTION_V1.1")
        .query(String.format(
            "SELECT QUOTYP, SPRAS, TYPDESC FROM OICQTT WHERE OICQTT~QUOTYP = '%s' AND SPRAS = 'E'",
            type))
        .stripe(stripe)
        .build();
  }

  private void mockEventHub() {
    when(realtimeEventHub.send(any(EventData.class)))
        .thenReturn(CompletableFuture.completedFuture(null));
  }

  private void mockForTheQuoteSources() {
    doReturn(Stream.empty()).when(oDataClient).executeOSQL(any(SingleOSqlQuery.class), eq(QuotationSAP.class));
  }

  private void mockForStaticData() {
    mockQueryForPriceTypeDescription();
    mockQueryForUom();
    mockQueryForQuoteSource();
    mockQueryForQuoteId();
    mockForSAPUom();
  }

  private void mockQueryForPriceTypeDescription() {
    Map<String, String> priceTypeDescriptionMap = getPriceTypeDescriptionMap();
    priceTypeDescriptionMap
        .forEach((k, v) -> STRIPES_LIST.forEach(stripe -> mockPriceTypeDescription(k, v, stripe)));
  }

  private void mockQueryForQuoteSourceFromTM1() {
    when(oDataClient.executeOSQL((SingleOSqlQuery) any(), eq(QuotationSourceSAP.class)))
        .thenAnswer(invocation -> Stream.of(
            QuotationSourceSAP.builder().sourceDescription("PN_DESCRIPTION").id("PN").build()
        ));
  }

  private void mockQuotationADNOCFORMC(String quoteSource, Stripe stripe) {
    when(oDataClient
        .executeOSQL(eq(queryForQuotations(quoteSource, stripe)), eq(QuotationSAP.class)))
        .thenReturn(Stream.of(
            QuotationSAP.builder()
                .sourceCode(quoteSource)
                .quotationNumber("ADNOCFORMC")
                .date(now().format(ofPattern("yyyy-MM-dd")))
                .quoteType("H")
                .quotePrice(100.00)
                .quantityForUom(100)
                .unitOfMeasureCode("BB6")
                .currency("USD")
                .factoryCalendarCode("ZH")
                .factoryCalendarDescription("Only Tuesday workday")
                .stripe(EU)
                .build()
        ));
  }

  private void mockTwoQuotationsSAPFromQuoteSourceA2() {
    when(oDataClient.executeOSQL(eq(queryForQuotations("A2", EU)), eq(QuotationSAP.class)))
        .thenReturn(Stream.of(
            QuotationSAP.builder()
                .sourceCode("A2")
                .quotationNumber("ADNOCFORMC")
                .date(now().format(ofPattern("yyyy-MM-dd")))
                .quoteType("H")
                .quotePrice(100.00)
                .quantityForUom(100)
                .unitOfMeasureCode("BB6")
                .currency("USD")
                .factoryCalendarCode("ZH")
                .factoryCalendarDescription("Only Tuesday workday")
                .stripe(EU)
                .build(),
            QuotationSAP.builder()
                .sourceCode("A2")
                .quotationNumber("ADNOCFORMC")
                .date(now().format(ofPattern("yyyy-MM-dd")))
                .quoteType("M")
                .quotePrice(200.00)
                .quantityForUom(100)
                .unitOfMeasureCode("BB6")
                .currency("USD")
                .factoryCalendarCode("ZH")
                .factoryCalendarDescription("Only Tuesday workday")
                .stripe(EU)
                .build()
        ));
  }

  private void mockCacheQuotationSourceDescription() {
    redisTemplate.getConnectionFactory().getConnection()
        .set("quotationSourceDescription::PN:EU".getBytes(),
            "{\"@class\":\"com.eom.service.market.quote.domain.fromsap.QuotationSourceSAP\",\"stripe\":\"EU\",\"QUOSRC\":\"PN\",\"SRCDESC\":\"PN_DESCRIPTION\"}"
                .getBytes());
  }

  private void mockCacheQuotationPriceTypeDescription() {
    redisTemplate.getConnectionFactory().getConnection()
        .set("quotationPriceTypeDescription::H:EU".getBytes(),
            "{\"@class\":\"com.eom.service.market.quote.domain.fromsap.PriceTypeSAP\",\"stripe\":\"EU\",\"QUOTYP\":\"H\",\"SPRAS\":\"E\",\"TYPDESC\":\"HIGH\"}"
                .getBytes());
  }

  private QuotationEntityId createQuotationEntityId(String quoteName, String quoteSource,
                                                    String type) {
    return QuotationEntityId.builder()
        .id(quoteName)
        .sourceCode(quoteSource)
        .date(now().format(ofPattern("yyyy-MM-dd")))
        .type(type)
        .build();
  }
}
