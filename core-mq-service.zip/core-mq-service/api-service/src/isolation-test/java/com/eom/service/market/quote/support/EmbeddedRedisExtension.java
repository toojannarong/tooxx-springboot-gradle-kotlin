package com.eom.service.market.quote.support;

import org.junit.jupiter.api.extension.AfterAllCallback;
import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.ExtensionContext;
import redis.embedded.RedisServer;

public class EmbeddedRedisExtension implements BeforeAllCallback, AfterAllCallback {

  private RedisServer redisServer;

  @Override
  public void beforeAll(ExtensionContext context) {
    redisServer = RedisServer.builder()
        .setting("bind 127.0.0.1")
        .port(6380)
        .build();
    try {
      redisServer.start();
    } catch (Exception e) {
      redisServer.stop();
    }
  }

  @Override
  public void afterAll(ExtensionContext context) {
    redisServer.stop();
  }
}
