package com.eom.service.market.quote.support;

import com.eom.service.market.quote.configuration.CustomizedProxy;
import com.microsoft.azure.eventhubs.EventHubClient;
import com.xom.odataclient.core.ODataClient;
import io.restassured.RestAssured;
import io.zonky.test.db.AutoConfigureEmbeddedDatabase;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith({MockitoExtension.class, SpringExtension.class, EmbeddedRedisExtension.class})
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@AutoConfigureEmbeddedDatabase
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    properties =  "io.reflectoring.scheduling.enabled=false")
@DirtiesContext
public class IsolationTest {

  @MockBean(name = "oDataClient")
  protected ODataClient oDataClient;

  @MockBean
  @Qualifier("realtimeEventHub")
  protected EventHubClient realtimeEventHub;

  @Autowired
  protected RedisTemplate<String, Object> redisTemplate;

  @MockBean
  protected CustomizedProxy customizedProxy;

  @LocalServerPort
  private int port;

  @BeforeEach
  public void setDefaultsForRestAssured() {
    RestAssured.port = port;
    redisTemplate.getConnectionFactory().getConnection().flushDb();
  }

  @AfterEach
  public void resetRestAssured() {
    RestAssured.reset();
  }

}
