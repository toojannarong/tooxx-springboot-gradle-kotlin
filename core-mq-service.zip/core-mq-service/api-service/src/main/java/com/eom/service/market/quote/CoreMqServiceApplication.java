package com.eom.service.market.quote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@SpringBootApplication
@EnableWebSecurity
public class CoreMqServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(CoreMqServiceApplication.class, args);
  }
}
