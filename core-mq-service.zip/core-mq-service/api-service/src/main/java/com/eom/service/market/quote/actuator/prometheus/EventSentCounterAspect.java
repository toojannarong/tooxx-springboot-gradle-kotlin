package com.eom.service.market.quote.actuator.prometheus;

import com.xom.errors.exceptions.SystemException;
import io.micrometer.core.instrument.Metrics;
import io.micrometer.core.instrument.Tag;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

@Aspect
@Component
public class EventSentCounterAspect {

  @Value("${azure.eventhub.topic-name}")
  private String topicName;

  @Around("@annotation(com.eom.service.market.quote.actuator.prometheus.EventSentCounter)")
  public Object countEventSent(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {

    long startTime = System.nanoTime();

    Object result = proceedingJoinPoint.proceed();

    if (!isCompletableFuture(result)) {
      return result;
    }

    ((CompletableFuture<?>) result).thenAcceptAsync(Void -> {
      handleEventSentSucceed(startTime);
    }).exceptionally(Throwable -> {
      handleEventSentFailed(startTime);
      throw new SystemException(Throwable);
    });

    return result;
  }

  private void handleEventSentFailed(long startTime) {
    recordToTimer("event_sent_failed", startTime);
  }

  private void handleEventSentSucceed(long startTime) {
    recordToTimer("event_sent", startTime);
  }

  private void recordToTimer(String timerName, long startTime) {
    Metrics.timer(timerName, Collections.singletonList(
        Tag.of("eventhub_topic", topicName))
    ).record(System.nanoTime() - startTime, TimeUnit.NANOSECONDS);
  }

  private boolean isCompletableFuture(Object result) {
    return CompletableFuture.class.isAssignableFrom(result.getClass());
  }
}
