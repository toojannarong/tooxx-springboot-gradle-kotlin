package com.eom.service.market.quote.actuator.prometheus;

public @interface SourceOfDataCounter {

}
