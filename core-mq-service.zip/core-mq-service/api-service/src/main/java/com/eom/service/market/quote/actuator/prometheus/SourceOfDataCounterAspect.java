package com.eom.service.market.quote.actuator.prometheus;

import io.micrometer.core.instrument.Metrics;
import io.micrometer.core.instrument.Tag;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Slf4j
@Aspect
@Component
public class SourceOfDataCounterAspect {


  @Around("@annotation(com.eom.service.market.quote.actuator.prometheus.SourceOfDataCounter)")
  public Object countQuoteData(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {

    Object[] args = proceedingJoinPoint.getArgs();

    String sourceCode = args[0].toString();
    Object stripe = args[1];

    Object result = proceedingJoinPoint.proceed(args);
    List<?> list = ((Stream<?>) result).collect(Collectors.toList());

    int count = list.size();

    if (isTM1(sourceCode)) {
      onSourceOfDataReceived("TM1", count);
    } else {
      onSourceOfDataReceived(stripe, count);
    }
    return list.stream();

  }

  private Boolean isTM1(Object object) {
    return object.toString().equals("PN");
  }

  private void onSourceOfDataReceived(Object stripe, int count) {

    try {
      recordToGauge("sap_received", stripe, count);
    } catch (Exception ex) {
      log.error("metrics error", ex);
    }

  }

  private void recordToGauge(String timerName, Object stripe, int count) {

    Metrics.gauge(timerName, Arrays.asList(
        Tag.of("sap_source", stripe.toString())),
        count);
  }


}
