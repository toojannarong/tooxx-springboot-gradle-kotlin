package com.eom.service.market.quote.api.response;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@Data
@ApiModel
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class ResponseContainer<T> {

  @ApiModelProperty
  private T data;

  public static <T> String buildDataJson(T entity) {
    Gson gson = new GsonBuilder().serializeNulls().create();
    ResponseContainer<T> response = new ResponseContainer(entity);

    return gson.toJson(response);
  }

}
