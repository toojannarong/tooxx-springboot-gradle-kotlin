package com.eom.service.market.quote.api.response;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class ResponseHelper {

  public <T> ResponseEntity<ResponseContainer<T>> response(T object) {
    return ResponseEntity.ok(new ResponseContainer<>(object));
  }

}
