package com.eom.service.market.quote.cache;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;

import static java.lang.String.format;

@Slf4j
public abstract class CacheTask implements ApplicationRunner {

  public abstract void initCache();

  @Override
  public void run(ApplicationArguments args) {
    String referenceName = getReferenceName();
    log.info(format("start init the %s cache!", referenceName));

    try {
      initCache();
    } catch (Exception e) {
      log.error(format("%s cache init failed %s", referenceName, e.getMessage()));
    }

    log.info(format("init the %s cache end!", referenceName));
  }

  private String getReferenceName() {
    return this.getClass().getSimpleName().replace("Task", "");
  }
}
