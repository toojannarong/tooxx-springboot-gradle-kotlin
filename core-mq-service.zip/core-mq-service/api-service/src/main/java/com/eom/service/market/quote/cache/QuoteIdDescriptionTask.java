package com.eom.service.market.quote.cache;

import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_QUOTATION_ID_DESCRIPTION;

import com.eom.service.market.quote.repository.QuotationIdDescriptionRepository;
import com.eom.service.market.quote.repository.cache.DashDelimitedParametersKeyGenerator;
import com.xom.odataclient.domain.Stripe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(value = "spring.cache.type", havingValue = "redis")
@Profile("!test")
@Order(0)
public class QuoteIdDescriptionTask extends CacheTask {

  @Autowired
  private QuotationIdDescriptionRepository quotationIdDescriptionRepository;

  @Autowired
  private DashDelimitedParametersKeyGenerator generator;

  @Autowired
  private RedisTemplate<String, Object> redisTemplate;

  @Override
  public void initCache() {
    quotationIdDescriptionRepository.findAll().forEach(quoteId -> redisTemplate.opsForValue()
        .set(generateKey(quoteId.getId(), quoteId.getSource(), quoteId.getStripe()), quoteId));
  }

  private String generateKey(String id, String source, Stripe stripe) {
    return generator.generate(CACHE_QUOTATION_ID_DESCRIPTION, id, source, stripe);
  }
}
