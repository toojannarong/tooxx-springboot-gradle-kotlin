package com.eom.service.market.quote.cache;

import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_QUOTATION_SOURCE_DESCRIPTION;

import com.eom.service.market.quote.repository.QuotationSourceDescriptionRepository;
import com.eom.service.market.quote.repository.cache.DashDelimitedParametersKeyGenerator;
import com.xom.odataclient.domain.Stripe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(value = "spring.cache.type", havingValue = "redis")
@Profile("!test")
@Order(1)
public class QuoteSourceDescriptionTask extends CacheTask {

  @Autowired
  private QuotationSourceDescriptionRepository quotationSourceDescriptionRepository;

  @Autowired
  private DashDelimitedParametersKeyGenerator generator;

  @Autowired
  private RedisTemplate<String, Object> redisTemplate;

  @Override
  public void initCache() {
    quotationSourceDescriptionRepository.findAll().forEach(
        quotationSource -> redisTemplate.opsForValue()
            .set(generateKey(quotationSource.getId(), quotationSource.getStripe()),
                quotationSource));
  }

  private String generateKey(String id, Stripe stripe) {
    return generator.generate(CACHE_QUOTATION_SOURCE_DESCRIPTION, id, stripe);
  }
}
