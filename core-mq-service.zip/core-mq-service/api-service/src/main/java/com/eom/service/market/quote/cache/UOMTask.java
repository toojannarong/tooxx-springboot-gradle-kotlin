package com.eom.service.market.quote.cache;

import com.eom.service.market.quote.repository.UomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import static com.eom.service.market.quote.util.Constant.STRIPES_LIST;

@Component
@ConditionalOnProperty(value = "spring.cache.type", havingValue = "redis")
@Profile("!test")
@Order(4)
public class UOMTask extends CacheTask {

  @Autowired private UomRepository uomRepository;

  @Override
  public void initCache() {
    STRIPES_LIST.forEach(
        stripe -> uomRepository.getAllUom(stripe));
  }
}
