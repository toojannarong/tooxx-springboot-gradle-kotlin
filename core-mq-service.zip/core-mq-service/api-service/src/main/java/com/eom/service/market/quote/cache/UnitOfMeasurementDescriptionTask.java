package com.eom.service.market.quote.cache;

import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_QUOTATION_UNIT_OF_MEASUREMENT_DESCRIPTION;

import com.eom.service.market.quote.repository.QuotationUnitOfMeasurementDescriptionRepository;
import com.eom.service.market.quote.repository.cache.DashDelimitedParametersKeyGenerator;
import com.xom.odataclient.domain.Stripe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(value = "spring.cache.type", havingValue = "redis")
@Profile("!test")
@Order(3)
public class UnitOfMeasurementDescriptionTask extends CacheTask {

  @Autowired
  private QuotationUnitOfMeasurementDescriptionRepository quotationUnitOfMeasurementDescriptionRepository;

  @Autowired
  private DashDelimitedParametersKeyGenerator generator;

  @Autowired
  private RedisTemplate<String, Object> redisTemplate;

  @Override
  public void initCache() {
    quotationUnitOfMeasurementDescriptionRepository.findAll().forEach(
        uom -> redisTemplate.opsForValue().set(generateKey(uom.getId(), uom.getStripe()), uom));
  }

  private String generateKey(String id, Stripe stripe) {
    return generator.generate(CACHE_QUOTATION_UNIT_OF_MEASUREMENT_DESCRIPTION, id, stripe);
  }
}
