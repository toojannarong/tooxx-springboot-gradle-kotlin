package com.eom.service.market.quote.configuration;


import com.microsoft.aad.msal4j.ClientCredentialFactory;
import com.microsoft.aad.msal4j.ClientCredentialParameters;
import com.microsoft.aad.msal4j.ConfidentialClientApplication;
import com.microsoft.aad.msal4j.IAuthenticationResult;
import com.microsoft.azure.eventhubs.AzureActiveDirectoryTokenProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;
import java.util.concurrent.CompletableFuture;

@Configuration
public class AzureADTokenProviderConfiguration {
  @Value("${azure.ad.client-id}")
  private String clientId;
  @Value("${azure.ad.client-secret}")
  private String clientSecret;
  @Value("${azure.ad.authority}")
  private String authority;

  @Bean
  public AuthCallback authCallback() {
    return new AuthCallback(clientId, clientSecret);
  }

  @Bean
  public AzureActiveDirectoryTokenProvider azureActiveDirectoryTokenProvider(AuthCallback authCallback) {
    return new AzureActiveDirectoryTokenProvider(authCallback, authority, null);
  }

  class AuthCallback implements AzureActiveDirectoryTokenProvider.AuthenticationCallback {
    private String clientId;
    private String clientSecret;

    public AuthCallback(final String clientId, final String clientSecret) {
      this.clientId = clientId;
      this.clientSecret = clientSecret;
    }

    @Override
    public CompletableFuture<String> acquireToken(String audience, String authority, Object state) {
      try {
        ConfidentialClientApplication app = ConfidentialClientApplication.builder(this.clientId, ClientCredentialFactory.createFromSecret(this.clientSecret))
            .authority(authority)
            .build();
        ClientCredentialParameters parameters = ClientCredentialParameters.builder(Collections.singleton(audience + ".default")).build();
        return app.acquireToken(parameters).thenApply(IAuthenticationResult::accessToken);
      } catch (Exception e) {
        CompletableFuture<String> failed = new CompletableFuture<>();
        failed.completeExceptionally(e);
        return failed;
      }
    }
  }
}
