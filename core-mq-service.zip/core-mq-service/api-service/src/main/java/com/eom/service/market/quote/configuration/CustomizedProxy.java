package com.eom.service.market.quote.configuration;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Slf4j
@Component
public class CustomizedProxy extends ProxySelector {

  private final String proxyHostName;
  private final int proxyHostPort;
  private final String eventHubHostEnding;

  private final List<Proxy> noProxy = new ArrayList<>();
  private final List<Proxy> eventHubProxy = new ArrayList<>();

  public CustomizedProxy(@Value("${proxy.host.name}") String proxyHostName,
                         @Value("${proxy.host.port}") int proxyHostPort,
                         @Value("${proxy.target}") String eventHubHostEnding) {
    this.proxyHostName = proxyHostName;
    this.proxyHostPort = proxyHostPort;
    this.eventHubHostEnding = eventHubHostEnding;

    initializeProxy();
  }

  private void initializeProxy() {
    noProxy.add(Proxy.NO_PROXY);
    eventHubProxy.add(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHostName, proxyHostPort)));

    ProxySelector.setDefault(this);
    log.info("Proxy initialized!");
  }

  @Override
  public List<Proxy> select(URI uri) {
    if (uri.getHost().toLowerCase(Locale.ENGLISH).endsWith(eventHubHostEnding)) {
      return eventHubProxy;
    }

    return noProxy;
  }

  @Override
  public void connectFailed(URI uri, SocketAddress sa, IOException ioe) {
    log.error("URI is: {}, SocketAddress is: {}, IOException is: {}", uri, sa, ioe);
  }
}
