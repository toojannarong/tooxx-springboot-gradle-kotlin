package com.eom.service.market.quote.configuration;

import static com.eom.service.market.quote.util.Constant.SECURITY_CONFIG_DEFAULT_ORDER;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@Order(SECURITY_CONFIG_DEFAULT_ORDER)
public class DefaultSecurityConfig extends WebSecurityConfigurerAdapter {
  @Override
  public void configure(HttpSecurity http) throws Exception {
    http.authorizeRequests().anyRequest().permitAll();
  }
}
