package com.eom.service.market.quote.configuration;

import com.xom.logging.logger.annotations.Loggable;
import com.microsoft.azure.eventhubs.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

@Loggable
@Configuration
public class EventHubConfig {

  @Value("${azure.eventhub.topic-name}")
  private String topicName;

  @Value("${azure.eventhub.namespace}")
  private String namespace;

  @Bean
  @Qualifier("eventHubExecutor")
  ScheduledExecutorService scheduledExecutorService() {
    return Executors.newScheduledThreadPool(4);
  }

  @Bean
  @Qualifier("realtimeEventHub")
  @DependsOn("customizedProxy")
  public EventHubClient realtimeEventHub(ScheduledExecutorService executor,
                                         AzureActiveDirectoryTokenProvider azureActiveDirectoryTokenProvider)
      throws IOException, EventHubException, URISyntaxException, ExecutionException, InterruptedException {
    return EventHubClient.createWithTokenProvider(new URI(namespace), topicName, azureActiveDirectoryTokenProvider, executor, getEventHubClientOptions()).get();
  }

  EventHubClientOptions getEventHubClientOptions() {
    EventHubClientOptions options = new EventHubClientOptions();
    options.setTransportType(TransportType.AMQP_WEB_SOCKETS);
    return options;
  }
}
