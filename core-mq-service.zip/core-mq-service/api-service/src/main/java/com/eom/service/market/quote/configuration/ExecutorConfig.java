package com.eom.service.market.quote.configuration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

@Configuration
@Profile("!test")
public class ExecutorConfig {

  @Bean
  @Qualifier("retryTaskExecutor")
  Executor executor() {
    return Executors.newFixedThreadPool(10);
  }
}
