package com.eom.service.market.quote.configuration;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@ConditionalOnProperty(
    value = "app.database.enabled", havingValue = "true", matchIfMissing = true
)
@Configuration
@EnableJpaRepositories(basePackages = "com.eom.service.market.quote")
public class JpaConfiguration {

}