package com.eom.service.market.quote.configuration;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

  @Value("${mq.tm1.timeout}")
  private int timeout;

  @Bean
  public RestTemplate getRestTemplate()
      throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
    RestTemplate restTemplate = new RestTemplate();
    restTemplate.setRequestFactory(buildRequestFactory());
    return restTemplate;
  }

  private ClientHttpRequestFactory buildRequestFactory()
      throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException {
    TrustStrategy acceptingTrustStrategy = (chain, authType) -> true;

    SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(
        SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build(),
        NoopHostnameVerifier.INSTANCE);

    RequestConfig config = RequestConfig.custom()
        .setConnectTimeout(timeout)
        .setConnectionRequestTimeout(timeout)
        .setSocketTimeout(timeout)
        .build();

    HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(
        HttpClients.custom()
            .setDefaultRequestConfig(config)
            .setSSLSocketFactory(sslConnectionSocketFactory)
            .setSSLHostnameVerifier(new NoopHostnameVerifier()).build());
    return new BufferingClientHttpRequestFactory(requestFactory);
  }

}
