package com.eom.service.market.quote.configuration;

import io.jaegertracing.internal.JaegerTracer;
import io.jaegertracing.internal.propagation.B3TextMapCodec;
import io.opentracing.Tracer;
import io.opentracing.propagation.Format;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TraceConfig {

  @Bean
  public Tracer jaegerTracer() {
    B3TextMapCodec codec = new B3TextMapCodec.Builder().build();
    return new JaegerTracer.Builder("core-mq-service")
        .registerInjector(Format.Builtin.HTTP_HEADERS, codec)
        .registerExtractor(Format.Builtin.HTTP_HEADERS, codec)
        .build();
  }
}
