package com.eom.service.market.quote.domain;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class Price {

  @ApiModelProperty(example = "934.750000")
  private String amount;

  @ApiModelProperty(example = "USD")
  private String currency;
}

