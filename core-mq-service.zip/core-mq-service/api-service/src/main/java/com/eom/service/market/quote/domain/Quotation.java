package com.eom.service.market.quote.domain;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class Quotation {

  @ApiModelProperty
  private StripesReferenceHeader stripesReference;

  @ApiModelProperty
  private List<QuotationPrice> prices;

}
