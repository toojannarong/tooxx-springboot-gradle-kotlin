package com.eom.service.market.quote.domain;


import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class QuotationPrice {

  @ApiModelProperty(example = "2014-03-11")
  private String date;

  @ApiModelProperty
  private StripesReference stripesReference;

  @ApiModelProperty
  private Price price;

  @ApiModelProperty
  private UnitOfMeasure uom;
}
