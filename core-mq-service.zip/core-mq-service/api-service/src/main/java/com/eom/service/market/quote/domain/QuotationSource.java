package com.eom.service.market.quote.domain;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class QuotationSource {

  @ApiModelProperty(example = "A2")
  private String code;

  @ApiModelProperty(example = "ARGUS NWE")
  private String description;

}
