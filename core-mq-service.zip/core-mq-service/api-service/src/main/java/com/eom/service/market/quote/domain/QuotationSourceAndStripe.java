package com.eom.service.market.quote.domain;

import com.xom.odataclient.domain.Stripe;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class QuotationSourceAndStripe {

  @ApiModelProperty
  private String quotationSource;

  @ApiModelProperty
  private Stripe stripe;

  private int queryTime;
}

