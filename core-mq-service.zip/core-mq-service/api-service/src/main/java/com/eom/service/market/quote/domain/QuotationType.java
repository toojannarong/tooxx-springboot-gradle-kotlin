package com.eom.service.market.quote.domain;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class QuotationType {

  @ApiModelProperty(example = "H")
  private String code;

  @ApiModelProperty(example = "HIGH")
  private String description;
}
