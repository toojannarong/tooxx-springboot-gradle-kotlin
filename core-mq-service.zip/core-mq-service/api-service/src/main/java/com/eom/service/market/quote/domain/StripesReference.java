package com.eom.service.market.quote.domain;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class StripesReference {

  @ApiModelProperty
  private QuotationType type;

  @ApiModelProperty
  private UnitOfMeasure uom;

}
