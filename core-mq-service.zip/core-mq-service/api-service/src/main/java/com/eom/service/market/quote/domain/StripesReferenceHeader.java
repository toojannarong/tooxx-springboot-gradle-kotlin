package com.eom.service.market.quote.domain;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class StripesReferenceHeader {

  @ApiModelProperty(example = "MOGASUNLRFOB")
  private String id;

  @ApiModelProperty(example = "OLD MOGAS UNL REG BARGE FOB ROTTERDAM")
  private String description;

  @ApiModelProperty
  private QuotationSource source;

  @ApiModelProperty
  private FactoryCalendar calendar;

}
