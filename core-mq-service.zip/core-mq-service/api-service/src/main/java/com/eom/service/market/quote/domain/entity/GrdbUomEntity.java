package com.eom.service.market.quote.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@Entity
@Table(name = "iso_unit_of_measure")
public class GrdbUomEntity {

  @Id
  @Column(name = "ISO_UOM_CODE")
  private String isoUomCode;

  @Column(name = "ISO_UOM_NAME")
  private String isoUomName;

}