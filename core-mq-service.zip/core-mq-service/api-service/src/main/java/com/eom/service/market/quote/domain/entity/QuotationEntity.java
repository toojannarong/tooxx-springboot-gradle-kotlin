package com.eom.service.market.quote.domain.entity;


import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@Entity
@Table(name = "current_quotation")
public class QuotationEntity {

  @EmbeddedId
  private QuotationEntityId quotationEntityId;

  private String price;

  @Column(name = "UNIT_OF_MEASURE")
  private String unitOfMeasure;

  @Column(name = "CALENDAR_CODE")
  private String calendarCode;

  @Column(name = "CALENDAR_DESCRIPTION")
  private String calendarDescription;

  private String currency;

  @CreationTimestamp
  @Column(name = "CREATED_AT", updatable = false)
  private LocalDateTime createdAt;

  @UpdateTimestamp
  @Column(name = "UPDATED_AT")
  private LocalDateTime updatedAt;
}