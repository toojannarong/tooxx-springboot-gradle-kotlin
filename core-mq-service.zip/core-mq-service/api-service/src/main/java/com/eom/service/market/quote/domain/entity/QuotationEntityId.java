package com.eom.service.market.quote.domain.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class QuotationEntityId implements Serializable {

  String id;

  @Column(name = "SOURCE_CODE")
  String sourceCode;

  String date;

  String type;
}
