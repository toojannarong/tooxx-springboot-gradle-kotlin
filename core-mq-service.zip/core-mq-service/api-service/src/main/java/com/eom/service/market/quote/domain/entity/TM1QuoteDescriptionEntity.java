package com.eom.service.market.quote.domain.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "TM1_QUOTE_DESCRIPTION")
public class TM1QuoteDescriptionEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "ID")
  private Integer id;

  @Column(name = "VENDOR_CODE")
  private String code;

  @Column(name = "VENDOR_DESCRIPTION")
  private String description;

  @Column(name = "QUOTE_SOURCE")
  private String quoteSource;

  @Column(name = "QUOTE_NUMBER")
  private String quoteNumber;

}
