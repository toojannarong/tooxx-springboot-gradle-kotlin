package com.eom.service.market.quote.domain.fromsap;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.xom.odataclient.annotations.Column;
import com.xom.odataclient.annotations.SelectSet;
import com.xom.odataclient.domain.Stripe;
import com.xom.odataclient.domain.StripeDomain;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@SelectSet(table = "OICQCT")
public class QuotationIdSAP implements StripeDomain {

  @JsonProperty("QUOTNO")
  @Column("QUOTNO")
  private String id;

  @JsonProperty("QUOSRC")
  @Column("QUOSRC")
  private String source;

  @JsonProperty("QUOTDESC")
  @Column("QUOTDESC")
  private String quotationIdDescription;

  private Stripe stripe;
}
