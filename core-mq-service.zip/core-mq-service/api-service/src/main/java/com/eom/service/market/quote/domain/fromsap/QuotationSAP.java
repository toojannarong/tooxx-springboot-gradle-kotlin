package com.eom.service.market.quote.domain.fromsap;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.xom.odataclient.annotations.Column;
import com.xom.odataclient.annotations.SelectSet;
import com.xom.odataclient.domain.Stripe;
import com.xom.odataclient.domain.StripeDomain;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@SelectSet(table = "OICQP")
public class QuotationSAP implements StripeDomain {

  @JsonProperty("QUOTNO")
  @Column("QUOTNO")
  private String quotationNumber;

  @JsonProperty("QUOSRC")
  @Column("QUOSRC")
  private String sourceCode;

  @JsonProperty("DEFUOM")
  @Column("DEFUOM")
  private String unitOfMeasureCode;

  @JsonProperty("QUOTYP")
  @Column("QUOTYP")
  private String quoteType;

  @JsonProperty("PRICE")
  @Column("PRICE")
  private Double quotePrice;

  @JsonProperty("DEFPER")
  @Column("DEFPER")
  private Integer quantityForUom;

  @JsonProperty("DEFCURR")
  @Column("DEFCURR")
  private String currency;

  @JsonProperty("QUOTDATE")
  @Column("QUOTDATE")
  private String date;

  @JsonProperty("FACTCAL")
  @Column("FACTCAL")
  private String factoryCalendarCode;

  @JsonProperty("LTEXT")
  @Column("LTEXT")
  private String factoryCalendarDescription;

  private Stripe stripe;
}
