package com.eom.service.market.quote.domain.fromsap;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.xom.odataclient.annotations.Column;
import com.xom.odataclient.annotations.SelectSet;
import com.xom.odataclient.domain.Stripe;
import com.xom.odataclient.domain.StripeDomain;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@SelectSet(table = "T006A")
public class UnitOfMeasurementSAP implements StripeDomain {

  @JsonProperty("MSEHI")
  @Column("MSEHI")
  private String id;

  @JsonProperty("MSEHL")
  @Column("MSEHL")
  private String longDescription;

  private Stripe stripe;
}
