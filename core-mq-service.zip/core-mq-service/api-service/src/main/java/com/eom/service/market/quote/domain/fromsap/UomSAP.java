package com.eom.service.market.quote.domain.fromsap;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.xom.odataclient.annotations.Column;
import com.xom.odataclient.annotations.SelectSet;
import com.xom.odataclient.domain.Stripe;
import com.xom.odataclient.domain.StripeDomain;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@SelectSet
public class UomSAP implements StripeDomain {

  @Column("MSEHI")
  @JsonProperty("MSEHI")
  private String unconvertedUom;

  @Column("MSEH3")
  @JsonProperty("MSEH3")
  private String convertedUom;

  @Column("ISOCODE")
  @JsonProperty("ISOCODE")
  private String isoCode;

  private Stripe stripe;
}
