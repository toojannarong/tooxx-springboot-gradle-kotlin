package com.eom.service.market.quote.domain.fromtm1;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class QuotationTM1 {

  @JsonProperty("QuoteSource")
  private String quoteSource;

  @JsonProperty("QuoteType")
  private String quoteType;

  @JsonProperty("QuoteName")
  private String quoteName;

  @JsonProperty("Quote")
  private String quote;

  @JsonProperty("Date")
  private String date;

  @JsonProperty("Value")
  private String value;

  @JsonProperty("Currency")
  private String currency;

  @JsonProperty("UOM")
  private String uom;

  @JsonProperty("Cube")
  private String cube;

}