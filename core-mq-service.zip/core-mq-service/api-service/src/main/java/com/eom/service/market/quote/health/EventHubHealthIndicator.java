package com.eom.service.market.quote.health;

import com.microsoft.azure.eventhubs.EventHubClient;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health.Builder;
import org.springframework.boot.actuate.health.Status;
import org.springframework.stereotype.Component;
import static com.eom.service.market.quote.util.Constant.ACTIVE;
import static com.eom.service.market.quote.util.Constant.INACTIVE;

@Component("eventHub")
public class EventHubHealthIndicator extends AbstractHealthIndicator {

  private final EventHubClient eventHubClient;

  public EventHubHealthIndicator(
      @Qualifier("realtimeEventHub") EventHubClient realTimeEventHub) {
    this.eventHubClient = realTimeEventHub;
  }

  @Override
  protected void doHealthCheck(Builder builder) {
    Map<String, EventHubStatus> statusDetail = getEventHubStatusDetails();
    Status status = areAllStatusActive(statusDetail) ? ACTIVE : INACTIVE;
    builder.up().status(status.getCode()).withDetails(statusDetail);
  }

  @Data
  @AllArgsConstructor
  public static class EventHubStatus {

    private final Status status;
    private final Instant createdAt;
    private final int partitionCount;
    private final String error;

    public static EventHubStatus ofActive(Instant createdAt, int partitionCount) {
      return new EventHubStatus(ACTIVE, createdAt, partitionCount, null);
    }

    public static EventHubStatus ofError(String errorMessage) {
      return new EventHubStatus(INACTIVE, null, 0, errorMessage);
    }
  }

  private boolean areAllStatusActive(Map<String, EventHubStatus> statusDetail) {
    return statusDetail.values()
        .stream()
        .allMatch(eventHubStatus -> ACTIVE.equals(eventHubStatus.status));
  }

  private Map<String, EventHubStatus> getEventHubStatusDetails() {
    Map<String, EventHubStatus> statusDetail = new HashMap<>();
    statusDetail.put(eventHubClient.getEventHubName(), getStatus(eventHubClient).join());
    return statusDetail;
  }

  private CompletableFuture<EventHubStatus> getStatus(EventHubClient client) {
    return client.getRuntimeInformation()
        .thenApply(
            (eventHubRuntimeInformation -> EventHubStatus.ofActive(eventHubRuntimeInformation.getCreatedAt(),
                                                                   eventHubRuntimeInformation.getPartitionCount())))
        .exceptionally(exception -> EventHubStatus.ofError(exception.getMessage()));
  }
}
