package com.eom.service.market.quote.repository;

import com.eom.service.market.quote.actuator.prometheus.EventSentCounter;
import com.eom.service.market.quote.api.response.ResponseContainer;
import com.microsoft.azure.eventhubs.EventData;
import com.microsoft.azure.eventhubs.EventHubClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

@Repository
public class EventHubRepository {

  @Autowired
  @Qualifier("realtimeEventHub")
  private EventHubClient realtimeEventHub;

  @EventSentCounter
  public <T> CompletableFuture<Void> sendToEventHub(T event) {
    return realtimeEventHub.send(buildEventData(event));
  }

  private <T> EventData buildEventData(T event) {
    return EventData.create(ResponseContainer.buildDataJson(event).getBytes(StandardCharsets.UTF_8));
  }
}
