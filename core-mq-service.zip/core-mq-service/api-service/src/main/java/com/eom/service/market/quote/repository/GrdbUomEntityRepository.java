package com.eom.service.market.quote.repository;

import com.eom.service.market.quote.domain.entity.GrdbUomEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface GrdbUomEntityRepository extends JpaRepository<GrdbUomEntity, String> {
  Optional<GrdbUomEntity> findByIsoUomCode(String isoUomCode);
}

