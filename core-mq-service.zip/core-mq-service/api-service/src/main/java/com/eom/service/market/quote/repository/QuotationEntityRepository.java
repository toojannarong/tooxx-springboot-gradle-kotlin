package com.eom.service.market.quote.repository;

import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.domain.entity.QuotationEntityId;
import com.xom.logging.logger.annotations.Loggable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
@Loggable
public interface QuotationEntityRepository extends
    JpaRepository<QuotationEntity, QuotationEntityId> {
}
