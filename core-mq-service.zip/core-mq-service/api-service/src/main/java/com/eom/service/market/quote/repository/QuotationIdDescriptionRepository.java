package com.eom.service.market.quote.repository;

import com.eom.service.market.quote.domain.fromsap.QuotationIdSAP;
import com.xom.logging.logger.annotations.Loggable;
import com.xom.logging.logger.annotations.LoggableEvent;
import com.xom.odataclient.core.ODataClient;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Optional;
import java.util.stream.Stream;

import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_QUOTATION_ID_DESCRIPTION;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.ENGLISH;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.LANGUAGE;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_ALL_QUOTE_ID_DESCRIPTIONS;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_QUOTE_ID_DESCRIPTION;
import static com.eom.service.market.quote.util.Constant.STRIPES_LIST;
import static com.xom.logging.logger.domain.ApplicationTier.REPOSITORY;
import static com.xom.odataclient.query.CriteriaBuilder.createQuery;
import static com.xom.odataclient.query.expression.BasicExpression.eq;

@Repository
@Loggable
public class QuotationIdDescriptionRepository {

  @Resource private ODataClient oDataClient;

  @LoggableEvent(applicationTier = REPOSITORY, action = "FIND_ALL_QUOTE_ID_DESCRIPTION")
  public Stream<QuotationIdSAP> findAll() {
    return STRIPES_LIST.stream()
        .map(this::getQuotationIdDescriptionForCache)
        .reduce(Stream::concat)
        .orElse(Stream.empty());
  }

  private Stream<QuotationIdSAP> getQuotationIdDescriptionForCache(Stripe stripe) {
    String sql = createQuery(QuotationIdSAP.class).where(eq(LANGUAGE, ENGLISH)).build();
    SingleOSqlQuery query =
        SingleOSqlQuery.builder()
            .uid(MARKET_QUOTE_DOMAIN_ALL_QUOTE_ID_DESCRIPTIONS)
            .stripe(stripe)
            .query(sql)
            .build();
    return oDataClient.executeOSQL(query, QuotationIdSAP.class);
  }

  @Cacheable(CACHE_QUOTATION_ID_DESCRIPTION)
  public Optional<QuotationIdSAP> getQuotationIdDescription(
      String quotationId, String source, Stripe stripe) {
    String query =
        createQuery(QuotationIdSAP.class)
            .where(eq("OICQCT~QUOTNO", quotationId).and(eq(LANGUAGE, ENGLISH)))
            .build();

    SingleOSqlQuery singleOSqlQuery =
        SingleOSqlQuery.builder()
            .uid(MARKET_QUOTE_DOMAIN_QUOTE_ID_DESCRIPTION)
            .stripe(stripe)
            .query(query)
            .build();

    Stream<QuotationIdSAP> entities =
        oDataClient.executeOSQL(singleOSqlQuery, QuotationIdSAP.class);

    return entities.filter(quotationIdSAP -> quotationIdSAP.getSource().equals(source)).findFirst();
  }
}
