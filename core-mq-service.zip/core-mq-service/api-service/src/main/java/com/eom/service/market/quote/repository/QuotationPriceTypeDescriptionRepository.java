package com.eom.service.market.quote.repository;

import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_QUOTATION_PRICE_TYPE_DESCRIPTION;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.ENGLISH;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.LANGUAGE;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_ALL_PRICE_TYPE_DESCRIPTIONS;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_PRICE_TYPE_DESCRIPTION;
import static com.eom.service.market.quote.util.Constant.PRICE_DESCRIPTION_TYPE_VOLUME;
import static com.eom.service.market.quote.util.Constant.PRICE_TYPE_VOLUME;
import static com.eom.service.market.quote.util.Constant.STRIPES_LIST;
import static com.xom.logging.logger.domain.ApplicationTier.REPOSITORY;
import static com.xom.odataclient.query.CriteriaBuilder.createQuery;
import static com.xom.odataclient.query.expression.BasicExpression.eq;

import com.xom.logging.logger.annotations.Loggable;
import com.xom.logging.logger.annotations.LoggableEvent;
import com.eom.service.market.quote.domain.fromsap.PriceTypeSAP;
import com.xom.odataclient.core.ODataClient;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import java.util.Optional;
import java.util.stream.Stream;
import javax.annotation.Resource;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

@Repository
@Loggable
public class QuotationPriceTypeDescriptionRepository {

  @Resource
  private ODataClient oDataClient;

  @LoggableEvent(applicationTier = REPOSITORY, action = "FIND_ALL_PRICE_TYPE")
  public Stream<PriceTypeSAP> findAll() {
    return STRIPES_LIST.stream()
        .map(this::getQuotationPriceTypeDescriptionForCache)
        .reduce(Stream::concat)
        .orElse(Stream.empty());
  }

  private Stream<PriceTypeSAP> getQuotationPriceTypeDescriptionForCache(Stripe stripe) {
    String sql = createQuery(PriceTypeSAP.class)
        .where(eq(LANGUAGE, ENGLISH))
        .build();
    SingleOSqlQuery query = SingleOSqlQuery.builder()
        .uid(MARKET_QUOTE_DOMAIN_ALL_PRICE_TYPE_DESCRIPTIONS)
        .stripe(stripe)
        .query(sql)
        .build();
    return oDataClient.executeOSQL(query, PriceTypeSAP.class);
  }

  @Cacheable(CACHE_QUOTATION_PRICE_TYPE_DESCRIPTION)
  public Optional<PriceTypeSAP> getQuotationPriceTypeDescription(String priceType, Stripe stripe) {
    if (PRICE_TYPE_VOLUME.equals(priceType)) {
      return Optional
          .of(PriceTypeSAP.builder().typeDescription(PRICE_DESCRIPTION_TYPE_VOLUME).build());
    }
    return getQuotationPriceTypeDescriptionFromSAP(priceType, stripe);
  }

  private Optional<PriceTypeSAP> getQuotationPriceTypeDescriptionFromSAP(String priceType,
      Stripe stripe) {
    String query = createQuery(PriceTypeSAP.class)
        .where(eq("OICQTT~QUOTYP", priceType).and(eq(LANGUAGE, ENGLISH)))
        .build();

    SingleOSqlQuery singleOSqlQuery = SingleOSqlQuery.builder()
        .uid(MARKET_QUOTE_DOMAIN_PRICE_TYPE_DESCRIPTION)
        .query(query)
        .stripe(stripe)
        .build();

    Stream<PriceTypeSAP> entities = oDataClient.executeOSQL(singleOSqlQuery, PriceTypeSAP.class);
    return entities.findAny();
  }

}
