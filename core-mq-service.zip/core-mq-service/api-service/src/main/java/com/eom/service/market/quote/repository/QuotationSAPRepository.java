package com.eom.service.market.quote.repository;

import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_QUOTE_BETWEEN_DAYS;
import static com.xom.logging.logger.domain.ApplicationTier.REPOSITORY;

import com.eom.service.market.quote.actuator.prometheus.SourceOfDataCounter;
import com.eom.service.market.quote.domain.fromsap.QuotationSAP;
import com.xom.logging.logger.annotations.Loggable;
import com.xom.logging.logger.annotations.LoggableEvent;
import com.xom.odataclient.core.ODataClient;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.stream.Stream;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
@Loggable
public class QuotationSAPRepository {

  @Resource
  private ODataClient oDataClient;

  @SourceOfDataCounter
  @LoggableEvent(applicationTier = REPOSITORY, action = "GET_QUOTATIONS_SAP_BY_SOURCE_STRIPE_AND_DATE_RANGE")
  public Stream<QuotationSAP> getQuotationsSAPBySourceStripeAndDateRange(
      String sourceCode, Stripe stripe, LocalDate fromDate, LocalDate toDate) {
    if (fromDate.isAfter(toDate)) {
      throw new IllegalArgumentException("'from' date is bigger than 'to' date");
    }

    String fromDateFormatted = fromDate.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
    String toDateFormatted = toDate.format(DateTimeFormatter.ofPattern("yyyyMMdd"));

    String sql = String
        .format("SELECT OICQP~QUOTNO, OICQP~QUOSRC, OICQP~DEFUOM, OICQP~QUOTYP, OICQP~PRICE, " +
                "OICQP~DEFPER, OICQP~DEFCURR, OICQP~QUOTDATE, OICQC~FACTCAL, TFACT~LTEXT " +
                "FROM OICQP LEFT JOIN OICQC ON OICQC~QUOSRC EQ OICQP~QUOSRC " +
                "AND OICQC~QUOTNO EQ OICQP~QUOTNO AND OICQC~QUOTYP EQ OICQP~QUOTYP LEFT JOIN TFACT ON TFACT~IDENT EQ OICQC~FACTCAL " +
                "WHERE TFACT~SPRAS EQ 'E' AND OICQP~QUOSRC EQ '%s' " +
                "AND OICQP~QUOTDATE BETWEEN '%s' AND '%s'", sourceCode, fromDateFormatted,
            toDateFormatted);

    SingleOSqlQuery singleOSqlQuery = SingleOSqlQuery.builder()
        .uid(MARKET_QUOTE_DOMAIN_QUOTE_BETWEEN_DAYS)
        .query(sql)
        .stripe(stripe)
        .build();

    return oDataClient.executeOSQL(singleOSqlQuery, QuotationSAP.class);
  }
}
