package com.eom.service.market.quote.repository;

import static com.xom.logging.logger.domain.ApplicationTier.REPOSITORY;
import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_QUOTATION_SOURCE_DESCRIPTION;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.ENGLISH;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.LANGUAGE;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_ALL_QUOTE_SOURCE_DESCRIPTIONS;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_QUOTE_SOURCE_DESCRIPTION;
import static com.eom.service.market.quote.util.Constant.STRIPES_LIST;
import static com.xom.odataclient.query.CriteriaBuilder.createQuery;
import static com.xom.odataclient.query.expression.BasicExpression.eq;

import com.xom.logging.logger.annotations.Loggable;
import com.xom.logging.logger.annotations.LoggableEvent;
import com.eom.service.market.quote.domain.fromsap.QuotationSourceSAP;
import com.xom.odataclient.core.ODataClient;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import java.util.Optional;
import java.util.stream.Stream;
import javax.annotation.Resource;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

@Repository
@Loggable
public class QuotationSourceDescriptionRepository {

  @Resource
  private ODataClient oDataClient;

  @LoggableEvent(applicationTier = REPOSITORY, action = "FIND_ALL_QUOTATION_SOURCE_DESCRIPTION")
  public Stream<QuotationSourceSAP> findAll() {
    return STRIPES_LIST.stream()
        .map(this::getQuotationSourceSAPForCache)
        .reduce(Stream::concat)
        .orElse(Stream.empty());
  }

  private Stream<QuotationSourceSAP> getQuotationSourceSAPForCache(Stripe stripe) {
    String sql = createQuery(QuotationSourceSAP.class)
        .where(eq(LANGUAGE, ENGLISH))
        .build();
    SingleOSqlQuery query = SingleOSqlQuery.builder()
        .uid(MARKET_QUOTE_DOMAIN_ALL_QUOTE_SOURCE_DESCRIPTIONS)
        .stripe(stripe)
        .query(sql)
        .build();
    return oDataClient.executeOSQL(query, QuotationSourceSAP.class);
  }


  @Cacheable(CACHE_QUOTATION_SOURCE_DESCRIPTION)
  public Optional<QuotationSourceSAP> getQuotationSourceDescription(String quotationSource,
      Stripe stripe) {
    String query = createQuery(QuotationSourceSAP.class)
        .where(eq("OICQST~QUOSRC", quotationSource).and(eq(LANGUAGE, ENGLISH)))
        .build();

    SingleOSqlQuery singleOSqlQuery = SingleOSqlQuery.builder()
        .uid(MARKET_QUOTE_DOMAIN_QUOTE_SOURCE_DESCRIPTION)
        .query(query)
        .stripe(stripe)
        .build();

    return oDataClient.executeOSQL(singleOSqlQuery, QuotationSourceSAP.class).findAny();
  }
}
