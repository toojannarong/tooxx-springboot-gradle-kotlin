package com.eom.service.market.quote.repository;

import com.eom.service.market.quote.domain.QuotationSourceAndStripe;
import com.xom.odataclient.domain.Stripe;
import java.util.stream.Stream;
import org.springframework.stereotype.Repository;

@Repository
public class QuotationSourcesAndStripesRepository {

  public Stream<QuotationSourceAndStripe> getQuotationsSourcesAndStripes() {
    return Stream.of(
        // PSES
        new QuotationSourceAndStripe("A2", Stripe.EU,1),
        new QuotationSourceAndStripe("AG", Stripe.EU,2),
        new QuotationSourceAndStripe("DR", Stripe.EU,1),
        new QuotationSourceAndStripe("P2", Stripe.EU,1),
        new QuotationSourceAndStripe("P3", Stripe.EU,1),
        new QuotationSourceAndStripe("P7", Stripe.AP,1),
        new QuotationSourceAndStripe("PD", Stripe.AP,1),
        new QuotationSourceAndStripe("R8", Stripe.AP,1),
        new QuotationSourceAndStripe("S1", Stripe.AP,1),
        new QuotationSourceAndStripe("S3", Stripe.AP,1),
        // SCARP
        new QuotationSourceAndStripe("FT", Stripe.AP,1),
        new QuotationSourceAndStripe("IC", Stripe.AP,1),
        new QuotationSourceAndStripe("P1", Stripe.AP,2),
        new QuotationSourceAndStripe("AS", Stripe.EU,1),
        new QuotationSourceAndStripe("AW", Stripe.EU,1),
        new QuotationSourceAndStripe("AX", Stripe.EU,1),
        new QuotationSourceAndStripe("IP", Stripe.NA,15),
        new QuotationSourceAndStripe("A1", Stripe.NA,1),
        // UDDF
        new QuotationSourceAndStripe("AD", Stripe.NA,1),
        new QuotationSourceAndStripe("R1", Stripe.NA,2),
        new QuotationSourceAndStripe("NY", Stripe.NA,1)
    );
  }

}
