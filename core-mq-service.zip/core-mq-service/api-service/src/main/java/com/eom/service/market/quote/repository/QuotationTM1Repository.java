package com.eom.service.market.quote.repository;

import static com.xom.logging.logger.domain.ApplicationTier.REPOSITORY;
import static java.lang.String.format;
import static java.time.format.DateTimeFormatter.ofPattern;

import com.eom.service.market.quote.actuator.prometheus.SourceOfDataCounter;
import com.xom.logging.logger.annotations.Loggable;
import com.xom.logging.logger.annotations.LoggableEvent;
import com.eom.service.market.quote.domain.fromtm1.QuotationTM1;
import java.net.URI;
import java.time.LocalDate;
import java.util.Objects;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Repository
@Loggable
@Slf4j
public class QuotationTM1Repository {

  @Autowired
  RestTemplate restTemplate;

  @Value("${mq.tm1.url}")
  private String tm1Uri;

  @SourceOfDataCounter
  @LoggableEvent(applicationTier = REPOSITORY, action = "GET_QUOTATIONS_TM1_BY_QUOTE_SOURCE_AND_START_DATE_AND_END_DATE")
  public Stream<QuotationTM1> getQuotationsTM1ByQuoteSourceAndStartDateAndEndDate(
      String quoteSource, LocalDate startDate, LocalDate endDate) {
    String startDateFormatted = startDate.format(ofPattern("yyyyMMdd"));
    String endDateFormatted = endDate.format(ofPattern("yyyyMMdd"));
    URI uri = UriComponentsBuilder.fromUriString(tm1Uri + "/api/sap")
        .queryParam("quotesource", quoteSource)
        .queryParam("date", format("%s,%s", startDateFormatted, endDateFormatted))
        .build()
        .toUri();
    log.info("Call TM1 url is {}", uri.toString());
    try {
      QuotationTM1[] responseBody = restTemplate.getForEntity(uri, QuotationTM1[].class).getBody();
      log.info("Call TM1 response quotations length is {}", responseBody.length);
      return Stream.of(Objects.requireNonNull(responseBody));
    } catch (Exception e) {
      log.error("Call TM1 failed ", e);
      return Stream.empty();
    }
  }
}
