package com.eom.service.market.quote.repository;

import static com.xom.logging.logger.domain.ApplicationTier.REPOSITORY;
import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_QUOTATION_UNIT_OF_MEASUREMENT_DESCRIPTION;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.ENGLISH;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.LANGUAGE;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_ALL_UOM_DESCRIPTIONS;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_UOM_DESCRIPTION;
import static com.eom.service.market.quote.util.Constant.STRIPES_LIST;
import static com.xom.odataclient.query.CriteriaBuilder.createQuery;
import static com.xom.odataclient.query.expression.BasicExpression.eq;

import com.xom.logging.logger.annotations.Loggable;
import com.xom.logging.logger.annotations.LoggableEvent;
import com.eom.service.market.quote.domain.fromsap.UnitOfMeasurementSAP;
import com.xom.odataclient.core.ODataClient;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import java.util.Optional;
import java.util.stream.Stream;
import javax.annotation.Resource;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

@Repository
@Loggable
public class QuotationUnitOfMeasurementDescriptionRepository {

  @Resource
  private ODataClient oDataClient;

  @LoggableEvent(applicationTier = REPOSITORY, action = "FIND_ALL_UNITS_OF_MEASUREMENT")
  public Stream<UnitOfMeasurementSAP> findAll() {
    return STRIPES_LIST.stream()
        .map(this::getUnitOfMeasurementDescriptionForCache)
        .reduce(Stream::concat)
        .orElse(Stream.empty());
  }

  private Stream<UnitOfMeasurementSAP> getUnitOfMeasurementDescriptionForCache(Stripe stripe) {
    String sql = createQuery(UnitOfMeasurementSAP.class)
        .where(eq(LANGUAGE, ENGLISH))
        .build();
    SingleOSqlQuery query = SingleOSqlQuery.builder()
        .uid(MARKET_QUOTE_DOMAIN_ALL_UOM_DESCRIPTIONS)
        .stripe(stripe)
        .query(sql)
        .build();
    return oDataClient.executeOSQL(query, UnitOfMeasurementSAP.class);
  }

  @Cacheable(CACHE_QUOTATION_UNIT_OF_MEASUREMENT_DESCRIPTION)
  public Optional<UnitOfMeasurementSAP> getQuotationUnitOfMeasurementDescription(String uom,
      Stripe stripe) {
    String query = createQuery(UnitOfMeasurementSAP.class)
        .where(eq("T006A~MSEHI", uom).and(eq(LANGUAGE, ENGLISH)))
        .build();

    SingleOSqlQuery singleOSqlQuery = SingleOSqlQuery.builder()
        .uid(MARKET_QUOTE_DOMAIN_UOM_DESCRIPTION)
        .query(query)
        .stripe(stripe)
        .build();

    Stream<UnitOfMeasurementSAP> entities = oDataClient
        .executeOSQL(singleOSqlQuery, UnitOfMeasurementSAP.class);
    return entities.findAny();
  }
}
