package com.eom.service.market.quote.repository;

import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_TM1_CURRENCY;

import com.xom.logging.logger.annotations.Loggable;
import com.eom.service.market.quote.domain.entity.TM1CurrencyEntity;
import java.util.Optional;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
@Loggable
public interface TM1CurrencyEntityRepository extends JpaRepository<TM1CurrencyEntity, Long> {

  @Cacheable(CACHE_TM1_CURRENCY)
  Optional<TM1CurrencyEntity> findByQuoteNumberAndAndQuoteSource(String quoteNumber, String quoteSource);
}
