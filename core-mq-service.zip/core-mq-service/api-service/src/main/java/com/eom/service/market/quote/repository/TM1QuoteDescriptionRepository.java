package com.eom.service.market.quote.repository;

import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_TM1_ID_DESCRIPTION;

import com.xom.logging.logger.annotations.Loggable;
import com.eom.service.market.quote.domain.entity.TM1QuoteDescriptionEntity;
import java.util.Optional;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
@Loggable
public interface TM1QuoteDescriptionRepository extends
    JpaRepository<TM1QuoteDescriptionEntity, Integer> {

  @Cacheable(CACHE_TM1_ID_DESCRIPTION)
  Optional<TM1QuoteDescriptionEntity> findByQuoteNumberAndQuoteSource(String quoteNumber, String quoteSource);

}
