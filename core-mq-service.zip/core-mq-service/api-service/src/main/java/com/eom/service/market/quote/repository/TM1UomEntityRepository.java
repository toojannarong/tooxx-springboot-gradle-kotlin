package com.eom.service.market.quote.repository;

import com.eom.service.market.quote.domain.entity.TM1UomEntity;
import com.xom.logging.logger.annotations.Loggable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
@Loggable
public interface TM1UomEntityRepository extends JpaRepository<TM1UomEntity, Long> {
  Optional<TM1UomEntity> findByQuoteNumberAndAndQuoteSource(String quoteNumber, String quoteSource);
}
