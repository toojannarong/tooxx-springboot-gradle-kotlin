package com.eom.service.market.quote.repository;

import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_UOM_FROM_SAP;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_UNCONVERTED_CONVERTED_ISO_UOM;
import static java.util.stream.Collectors.toList;

import com.eom.service.market.quote.domain.fromsap.UomSAP;
import com.xom.odataclient.core.ODataClient;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

@Repository
@RequiredArgsConstructor(onConstructor = @__({@Autowired}))
public class UomRepository {

  private final ODataClient oDataClient;

  @Cacheable(CACHE_UOM_FROM_SAP)
  public List<UomSAP> getAllUom(Stripe stripe) {
    SingleOSqlQuery singleOSqlQuery = SingleOSqlQuery.builder()
        .uid(MARKET_QUOTE_DOMAIN_UNCONVERTED_CONVERTED_ISO_UOM)
        .query(
            "SELECT T006A~MSEHI, MSEH3, ISOCODE FROM T006A LEFT JOIN T006 ON T006A~MSEHI EQ T006~MSEHI WHERE SPRAS = 'E'")
        .stripe(stripe)
        .build();

    return oDataClient.executeOSQL(singleOSqlQuery, UomSAP.class).collect(toList());
  }
}
