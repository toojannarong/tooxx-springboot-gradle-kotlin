package com.eom.service.market.quote.repository.cache;

import com.google.common.base.Joiner;
import java.lang.reflect.Method;
import java.util.stream.Stream;
import org.springframework.cache.interceptor.KeyGenerator;

import static java.lang.String.format;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toList;

public class DashDelimitedParametersKeyGenerator implements KeyGenerator {

  private static final Joiner DASH_JOINER = Joiner.on(':');

  @Override
  public Object generate(Object target, Method method, Object... params) {
    return generate(params);
  }

  public String generate(String name, Object... params) {
    return format("%s::%s", name, generate(params));
  }

  private String generate(Object... params) {
    return DASH_JOINER.join(Stream.of(ofNullable(params).orElse(new Object[]{}))
        .map(String::valueOf)
        .collect(toList()));
  }
}
