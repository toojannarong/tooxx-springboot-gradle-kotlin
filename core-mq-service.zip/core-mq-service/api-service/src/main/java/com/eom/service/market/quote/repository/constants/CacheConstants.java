package com.eom.service.market.quote.repository.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class CacheConstants {

  public static final String CACHE_QUOTATION_ID_DESCRIPTION = "quotationIdDescription";
  public static final String CACHE_QUOTATION_SOURCE_DESCRIPTION = "quotationSourceDescription";
  public static final String CACHE_QUOTATION_PRICE_TYPE_DESCRIPTION = "quotationPriceTypeDescription";
  public static final String CACHE_QUOTATION_UNIT_OF_MEASUREMENT_DESCRIPTION = "quotationUnitOfMeasurementDescription";
  public static final String CACHE_TM1_ID_DESCRIPTION = "tm1IdDescription";
  public static final String CACHE_TM1_CURRENCY = "tm1Currency";
  public static final String CACHE_UOM_FROM_SAP = "uomFromSAP";
}
