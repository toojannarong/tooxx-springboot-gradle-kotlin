package com.eom.service.market.quote.service;

import com.eom.service.market.quote.domain.Quotation;
import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.repository.QuotationEntityRepository;
import com.eom.service.market.quote.transformers.QuotationEntityTransformer;
import com.xom.logging.logger.annotations.Loggable;
import com.xom.logging.logger.annotations.LoggableEvent;
import com.xom.logging.logger.domain.ApplicationTier;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static com.eom.service.market.quote.util.Constant.RELEVANT_PRICE_TYPES;
import static java.lang.String.format;

@Service
@Loggable
@Slf4j
public class QuotationEntityService {

  @Autowired
  private QuotationEntityRepository quotationEntityRepository;

  @Autowired
  private QuotationEntityTransformer quotationEntityTransformer;

  @LoggableEvent(
      applicationTier = ApplicationTier.SERVICE,
      action = "FILTER_NEW_AND_UPDATED_QUOTATIONS")
  public Stream<QuotationEntity> filterNewAndUpdatedQuotationSAPs(
      Stream<QuotationEntity> quotations) {
    return quotations
        .filter(e -> RELEVANT_PRICE_TYPES.contains(e.getQuotationEntityId().getType()))
        .filter(this::filterNewOrUpdatedPriceType);
  }


  private boolean filterNewOrUpdatedPriceType(QuotationEntity quotationEntity) {
    Optional<QuotationEntity> quotationEntityFromDB =
        quotationEntityRepository.findById(quotationEntity.getQuotationEntityId());

    return quotationEntityFromDB.map(e -> !quotationEntity.getPrice().equals(e.getPrice()))
        .orElse(true);
  }

  @LoggableEvent(applicationTier = ApplicationTier.SERVICE, action = "SAVE_AS_QUOTATION_ENTITY")
  public void saveAsQuotationEntity(Quotation quotation) {
    List<QuotationEntity> quotationEntityList = quotationEntityTransformer.transformToEntityFromQuotation(quotation);
    quotationEntityList.forEach(
        quotationEntity -> {
          try {
            quotationEntityRepository.save(quotationEntity);
            log.info("Save quotation Entity: {}", quotationEntity);
          } catch (RuntimeException e) {
            log.error(format("Error while saving Quotation Entity: %s", quotationEntity), e);
          }
        });
  }
}
