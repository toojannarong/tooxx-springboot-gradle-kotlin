package com.eom.service.market.quote.service;

import com.eom.service.market.quote.domain.QueryPeriod;
import com.eom.service.market.quote.domain.QuotationSourceAndStripe;
import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.domain.fromsap.QuotationSAP;
import com.eom.service.market.quote.repository.QuotationSAPRepository;
import com.eom.service.market.quote.transformers.QuotationEntityTransformer;
import com.xom.logging.logger.annotations.Loggable;
import com.xom.logging.logger.annotations.LoggableEvent;
import com.xom.logging.logger.domain.ApplicationTier;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.stream.Stream;

@Service
@Loggable
@Slf4j
public class QuotationSAPService {

  @Autowired private QuotationSAPRepository quotationSAPRepository;

  @Autowired private QuotationEntityTransformer quotationEntityTransformer;

  @LoggableEvent(
      applicationTier = ApplicationTier.SERVICE,
      action = "GET_QUOTATIONS_SAP_FOR_PERIOD_TIME")
  public Stream<QuotationEntity> getQuotationsSAPForPeriodTime(QueryPeriod queryPeriod) {
    Stream<QuotationEntity> quotations;
    try {
      quotations =
          getQuotationSapAndTransform(
              queryPeriod.getQuotationSourceAndStripe(),
              queryPeriod.getFromDate(),
              queryPeriod.getToDate());
    } catch (Exception e) {
      log.error("Cannot get quotations from {}", queryPeriod, e);
      quotations = Stream.empty();
    }
    return quotations;
  }

  private Stream<QuotationEntity> getQuotationSapAndTransform(
      QuotationSourceAndStripe quotationSourceAndStripe, LocalDate fromDate, LocalDate toDate) {
    Stream<QuotationSAP> quotationSAPStream =
        quotationSAPRepository.getQuotationsSAPBySourceStripeAndDateRange(
            quotationSourceAndStripe.getQuotationSource(),
            quotationSourceAndStripe.getStripe(),
            fromDate,
            toDate);
    return quotationEntityTransformer.transformToEntityFromSap(quotationSAPStream);
  }
}
