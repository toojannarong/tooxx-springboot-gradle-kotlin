package com.eom.service.market.quote.service;

import com.eom.service.market.quote.domain.QueryPeriod;
import com.eom.service.market.quote.domain.Quotation;
import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.repository.EventHubRepository;
import com.eom.service.market.quote.repository.QuotationSourcesAndStripesRepository;
import com.eom.service.market.quote.transformers.QuotationEntityTransformer;
import com.google.common.collect.Lists;
import com.xom.logging.logger.annotations.Loggable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import static java.lang.String.format;

@Service
@Loggable
@Slf4j
public class QuotationSendService {

  private static final int GROUP_SIZE = 1000;

  @Value("${mq.sap.quotations.days}")
  private int daysForQuotations;

  @Autowired private EventHubRepository eventHubRepository;

  @Autowired private QuotationEntityService quotationEntityService;

  @Autowired private QuotationEntityTransformer quotationEntityTransformer;

  @Autowired private QuotationSAPService quotationSAPService;

  @Autowired private QuotationSourcesAndStripesRepository quotationSourcesAndStripesRepository;

  @Autowired private QuotationTM1Service quotationTM1Service;

  public int sendAndSaveQuotationsForSap() {
    LocalDate today = LocalDate.now();
    LocalDate severalDaysAgo = today.minusDays(daysForQuotations);
    return getQueryPeriodStream(severalDaysAgo)
        .parallel()
        .map(this::sendAndSaveQuotationsForSap)
        .reduce(0, Integer::sum);
  }

  private int sendAndSaveQuotationsForSap(QueryPeriod queryPeriod) {
    Stream<QuotationEntity> quotationEntityStream =
        quotationSAPService.getQuotationsSAPForPeriodTime(queryPeriod);
    Stream<QuotationEntity> filteredQuotationEntityStream =
        quotationEntityService.filterNewAndUpdatedQuotationSAPs(quotationEntityStream);
    List<Quotation> quotationList =
        quotationEntityTransformer.transformToQuotationForSap(
            filteredQuotationEntityStream, queryPeriod.getQuotationSourceAndStripe());
    return sendAndSaveQuotations(quotationList);
  }

  public int sendAndSaveQuotationsForTM1() {
    Stream<QuotationEntity> quotationList = quotationTM1Service.getQuotationsTM1ForPeriodTime();
    Stream<QuotationEntity> filteredQuotation = quotationEntityService
        .filterNewAndUpdatedQuotationSAPs(quotationList);
    List<Quotation> quotations = quotationEntityTransformer.transformToQuotationForTm1(filteredQuotation);
    AtomicInteger atomicInteger = new AtomicInteger(quotations.size());
    Lists.partition(quotations, GROUP_SIZE)
        .forEach(q -> sendAndSaveQuotationList(q, atomicInteger));
    return atomicInteger.get();
  }

  private Stream<QueryPeriod> getQueryPeriodStream(LocalDate severalDaysAgo) {
    return quotationSourcesAndStripesRepository
        .getQuotationsSourcesAndStripes()
        .map(
            e -> {
              LocalDate fromDate = severalDaysAgo;
              LocalDate toDate;
              List<QueryPeriod> queryPeriods = new ArrayList<>();
              for (int i = 0; i < e.getQueryTime(); i++) {
                toDate = fromDate.minusDays(0L - daysForQuotations / e.getQueryTime());
                queryPeriods.add(
                    QueryPeriod.builder()
                        .fromDate(fromDate)
                        .toDate(toDate)
                        .quotationSourceAndStripe(e)
                        .build());
                fromDate = toDate;
              }
              return queryPeriods;
            })
        .flatMap(Collection::stream);
  }

  private int sendAndSaveQuotations(List<Quotation> quotations) {
    AtomicInteger atomicInteger = new AtomicInteger(quotations.size());
    Lists.partition(quotations, GROUP_SIZE)
        .forEach(quotationList -> sendAndSaveQuotationList(quotationList, atomicInteger));
    return atomicInteger.get();
  }

  private void sendAndSaveQuotationList(List<Quotation> quotations, AtomicInteger atomicInteger) {
    final CompletableFuture[] completableFutures =
        quotations
            .parallelStream()
            .map(quotation -> sendAndSaveQuotation(quotation, atomicInteger))
            .toArray(CompletableFuture[]::new);
    CompletableFuture.allOf(completableFutures).join();
  }

  @Transactional
  public CompletableFuture<Void> sendAndSaveQuotation(
      Quotation quotation, AtomicInteger atomicInteger) {
    return eventHubRepository
        .sendToEventHub(quotation)
        .thenAccept(
            aVoid -> {
              log.info("Successfully sent market quote event to eventhub: {}", quotation);
              quotationEntityService.saveAsQuotationEntity(quotation);
            })
        .exceptionally(
            throwable -> {
              atomicInteger.decrementAndGet();
              log.error(format("Failed to send to eventhub: %s", quotation), throwable);
              return null;
            });
  }
}
