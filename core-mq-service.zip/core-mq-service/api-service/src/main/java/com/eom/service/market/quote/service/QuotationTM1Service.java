package com.eom.service.market.quote.service;

import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.domain.fromtm1.QuotationTM1;
import com.eom.service.market.quote.repository.QuotationTM1Repository;
import com.eom.service.market.quote.transformers.QuotationEntityTransformer;
import com.xom.logging.logger.annotations.Loggable;
import com.xom.logging.logger.annotations.LoggableEvent;
import com.xom.logging.logger.domain.ApplicationTier;
import java.time.LocalDate;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Loggable
public class QuotationTM1Service {

  @Autowired
  private QuotationTM1Repository quotationTM1Repository;

  @Autowired
  private QuotationEntityTransformer quotationEntityTransformer;

  @Value("${mq.tm1.quotations.days}")
  private int daysForQuotations;

  @LoggableEvent(applicationTier = ApplicationTier.SERVICE, action = "GET_QUOTATIONS_TM1_FOR_PERIOD_TIME")
  public Stream<QuotationEntity> getQuotationsTM1ForPeriodTime() {
    LocalDate today = LocalDate.now();
    LocalDate severalDaysAgo = today.minusDays(daysForQuotations);
    Stream<QuotationTM1> quotationTM1 = quotationTM1Repository
        .getQuotationsTM1ByQuoteSourceAndStartDateAndEndDate("PN", severalDaysAgo, today);

    return quotationEntityTransformer.transformToEntityFromTM1(quotationTM1);
  }
}
