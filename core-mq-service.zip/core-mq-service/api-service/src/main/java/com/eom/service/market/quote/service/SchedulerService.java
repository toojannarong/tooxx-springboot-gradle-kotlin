package com.eom.service.market.quote.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;

@Service
@Order(5)
@Slf4j
public class SchedulerService {

  @Autowired
  private QuotationSendService quotationSendService;

  @Scheduled(cron = "${mq.sap.scheduler.cron}")
  public void scheduledTaskSAP() {
    log.info("Starting SAP scheduler job...");
    startSAP();
  }

  @Scheduled(cron = "${mq.tm1.scheduler.cron}")
  public void scheduledTaskTM1() {
    log.info("Starting TM1 scheduler job...");
    startTM1();
  }

  void startSAP() {
    StopWatch stopwatch = new StopWatch();
    stopwatch.start();
    int successCounts = quotationSendService.sendAndSaveQuotationsForSap();
    stopwatch.stop();
    log.info("Finished sending SAP {} quotations to EventHub costs {}ms", successCounts,
        stopwatch.getTotalTimeMillis());
  }

  void startTM1() {
    StopWatch stopwatch = new StopWatch();
    stopwatch.start();
    int successCounts = quotationSendService.sendAndSaveQuotationsForTM1();
    stopwatch.stop();
    log.info("Finished sending TM1 {} quotations to EventHub costs {}ms", successCounts,
        stopwatch.getTotalTimeMillis());
  }
}
