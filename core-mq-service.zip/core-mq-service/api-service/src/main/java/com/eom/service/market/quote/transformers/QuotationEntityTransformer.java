package com.eom.service.market.quote.transformers;

import com.eom.service.market.quote.domain.FactoryCalendar;
import com.eom.service.market.quote.domain.Price;
import com.eom.service.market.quote.domain.Quotation;
import com.eom.service.market.quote.domain.QuotationPrice;
import com.eom.service.market.quote.domain.QuotationSource;
import com.eom.service.market.quote.domain.QuotationSourceAndStripe;
import com.eom.service.market.quote.domain.QuotationType;
import com.eom.service.market.quote.domain.StripesReference;
import com.eom.service.market.quote.domain.StripesReferenceHeader;
import com.eom.service.market.quote.domain.UnitOfMeasure;
import com.eom.service.market.quote.domain.entity.GrdbUomEntity;
import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.domain.entity.QuotationEntityId;
import com.eom.service.market.quote.domain.entity.TM1CurrencyEntity;
import com.eom.service.market.quote.domain.entity.TM1QuoteDescriptionEntity;
import com.eom.service.market.quote.domain.entity.TM1UomEntity;
import com.eom.service.market.quote.domain.fromsap.PriceTypeSAP;
import com.eom.service.market.quote.domain.fromsap.QuotationIdSAP;
import com.eom.service.market.quote.domain.fromsap.QuotationSAP;
import com.eom.service.market.quote.domain.fromsap.QuotationSourceSAP;
import com.eom.service.market.quote.domain.fromsap.UnitOfMeasurementSAP;
import com.eom.service.market.quote.domain.fromsap.UomSAP;
import com.eom.service.market.quote.domain.fromtm1.QuotationTM1;
import com.eom.service.market.quote.repository.GrdbUomEntityRepository;
import com.eom.service.market.quote.repository.QuotationIdDescriptionRepository;
import com.eom.service.market.quote.repository.QuotationPriceTypeDescriptionRepository;
import com.eom.service.market.quote.repository.QuotationSourceDescriptionRepository;
import com.eom.service.market.quote.repository.QuotationUnitOfMeasurementDescriptionRepository;
import com.eom.service.market.quote.repository.TM1CurrencyEntityRepository;
import com.eom.service.market.quote.repository.TM1QuoteDescriptionRepository;
import com.eom.service.market.quote.repository.TM1UomEntityRepository;
import com.eom.service.market.quote.repository.UomRepository;
import com.google.common.base.Strings;
import com.xom.logging.logger.annotations.LoggableEvent;
import com.xom.logging.logger.domain.ApplicationTier;
import com.xom.odataclient.domain.Stripe;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static com.eom.service.market.quote.util.Constant.EMPTY_STRING;
import static com.eom.service.market.quote.util.Constant.RELEVANT_PRICE_TYPES;
import static com.eom.service.market.quote.util.TransformerUtil.scaleStringToSixDigits;
import static com.xom.odataclient.domain.Stripe.EU;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

@Component
@Slf4j
public class QuotationEntityTransformer {

  private static final int MAX_DECIMAL_NUMBER = 6;

  @Autowired
  private QuotationSourceDescriptionRepository quotationSourceDescriptionRepository;

  @Autowired
  private QuotationIdDescriptionRepository quotationIdDescriptionRepository;

  @Autowired
  private QuotationPriceTypeDescriptionRepository quotationPriceTypeDescriptionRepository;

  @Autowired
  private QuotationUnitOfMeasurementDescriptionRepository
      quotationUnitOfMeasurementDescriptionRepository;

  @Autowired
  private UomRepository uomRepository;

  @Autowired
  private GrdbUomEntityRepository grdbUomEntityRepository;

  @Autowired
  private TM1UomEntityRepository tm1UomEntityRepository;

  @Autowired
  private TM1QuoteDescriptionRepository tm1QuoteDescriptionRepository;

  @Autowired
  private TM1CurrencyEntityRepository tm1CurrencyEntityRepository;

  public List<QuotationEntity> transformToEntityFromQuotation(Quotation quotation) {
    return quotation.getPrices().stream()
        .map(
            quotationPrice -> {
              QuotationEntityId quotationEntityId =
                  buildQuotationEntityId(quotation, quotationPrice);
              return buildQuotationEntity(quotation, quotationPrice, quotationEntityId);
            })
        .collect(toList());
  }

  private QuotationEntityId buildQuotationEntityId(
      Quotation quotation, QuotationPrice quotationPrice) {
    return QuotationEntityId.builder()
        .id(quotation.getStripesReference().getId())
        .sourceCode(quotation.getStripesReference().getSource().getCode())
        .type(quotationPrice.getStripesReference().getType().getCode())
        .date(quotationPrice.getDate())
        .build();
  }

  private QuotationEntity buildQuotationEntity(
      Quotation quotation, QuotationPrice quotationPrice, QuotationEntityId quotationEntityId) {

    QuotationEntity.QuotationEntityBuilder quotationEntityBuilder =
        QuotationEntity.builder()
            .quotationEntityId(quotationEntityId)
            .currency(quotationPrice.getPrice().getCurrency())
            .price(quotationPrice.getPrice().getAmount());

    if (quotationPrice.getStripesReference().getUom() != null) {
      quotationEntityBuilder.unitOfMeasure(quotationPrice.getStripesReference().getUom().getCode());
    }
    if (quotation.getStripesReference().getCalendar() != null) {
      quotationEntityBuilder
          .calendarCode(quotation.getStripesReference().getCalendar().getCode())
          .calendarDescription(quotation.getStripesReference().getCalendar().getDescription());
    }
    return quotationEntityBuilder.build();
  }

  public Stream<QuotationEntity> transformToEntityFromSap(Stream<QuotationSAP> quotationSAPStream) {
    return quotationSAPStream.map(this::transformSap);
  }

  private QuotationEntity transformSap(QuotationSAP quotationSAP) {
    QuotationEntityId quotationEntityId = buildEntityIdFromSap(quotationSAP);
    QuotationEntity quotationEntity = buildEntityFromSap(quotationSAP);
    quotationEntity.setQuotationEntityId(quotationEntityId);
    return quotationEntity;
  }

  private QuotationEntity buildEntityFromSap(QuotationSAP quotationSAP) {
    return QuotationEntity.builder()
        .currency(quotationSAP.getCurrency())
        .price(calculatePricePerUnit(quotationSAP))
        .unitOfMeasure(quotationSAP.getUnitOfMeasureCode())
        .calendarCode(quotationSAP.getFactoryCalendarCode())
        .calendarDescription(quotationSAP.getFactoryCalendarDescription())
        .build();
  }

  private String calculatePricePerUnit(QuotationSAP pricePerDaySap) {
    return BigDecimal.valueOf(pricePerDaySap.getQuotePrice())
        .divide(
            new BigDecimal(pricePerDaySap.getQuantityForUom()),
            MAX_DECIMAL_NUMBER,
            BigDecimal.ROUND_HALF_UP)
        .toString();
  }

  private QuotationEntityId buildEntityIdFromSap(QuotationSAP quotationSAP) {
    return QuotationEntityId.builder()
        .id(quotationSAP.getQuotationNumber())
        .sourceCode(quotationSAP.getSourceCode())
        .type(quotationSAP.getQuoteType())
        .date(quotationSAP.getDate())
        .build();
  }

  public Stream<QuotationEntity> transformToEntityFromTM1(Stream<QuotationTM1> quotationTM1) {
    return quotationTM1.map(this::transformTM1);
  }

  private QuotationEntity transformTM1(QuotationTM1 quotationTM1) {
    QuotationEntityId quotationEntityId = buildEntityIdFromTM1(quotationTM1);
    QuotationEntity quotationEntity = buildEntityFromTM1(quotationTM1);
    quotationEntity.setQuotationEntityId(quotationEntityId);
    return quotationEntity;
  }

  private QuotationEntityId buildEntityIdFromTM1(QuotationTM1 quotationTM1) {
    return QuotationEntityId.builder()
        .id(quotationTM1.getQuoteName())
        .sourceCode(quotationTM1.getQuoteSource())
        .type(quotationTM1.getQuoteType())
        .date(LocalDate.parse(quotationTM1.getDate(), DateTimeFormatter.ofPattern("yyyyMMdd"))
            .format(DateTimeFormatter.ISO_DATE))
        .build();
  }

  private QuotationEntity buildEntityFromTM1(QuotationTM1 quotationTM1) {
    return QuotationEntity.builder()
        .price(scaleStringToSixDigits(quotationTM1.getValue()))
        .currency(buildPriceCurrency(quotationTM1))
        .unitOfMeasure(quotationTM1.getUom())
        .build();
  }

  @LoggableEvent(applicationTier = ApplicationTier.TRANSFORMER, action = "TRANSFORM_QUOTATIONS")
  public List<Quotation> transformToQuotationForSap(
      Stream<QuotationEntity> quotationEntityStream,
      QuotationSourceAndStripe quotationSourceAndStripe) {
    return quotationEntityStream.collect(groupingBy(this::quotationGroupKey)).values().stream()
        .map(
            e -> buildQuotationGroupingRelevantPricesFromQuotationEntityList(
                e, quotationSourceAndStripe))
        .collect(toList());
  }

  @LoggableEvent(applicationTier = ApplicationTier.TRANSFORMER, action = "TRANSFORM_QUOTATIONS")
  public List<Quotation> transformToQuotationForTm1(Stream<QuotationEntity> quotationEntityStream) {
    QuotationSourceAndStripe quotationSourceAndStripe =
        QuotationSourceAndStripe.builder().stripe(Stripe.EU).quotationSource("").build();
    return quotationEntityStream.collect(groupingBy(this::quotationGroupKey)).values().stream()
        .map(
            e -> buildQuotationGroupingRelevantPricesFromQuotationTM1List(
                e, quotationSourceAndStripe))
        .collect(toList());
  }

  private String quotationGroupKey(QuotationEntity quotationEntity) {
    return String.format(
        "%s#%s",
        quotationEntity.getQuotationEntityId().getId(),
        quotationEntity.getQuotationEntityId().getDate());
  }

  private Quotation buildQuotationGroupingRelevantPricesFromQuotationTM1List(
      List<QuotationEntity> quotationListWithPricesToBeGrouped,
      QuotationSourceAndStripe quotationSourceAndStripe) {
    QuotationEntity firstQuoteToReference = quotationListWithPricesToBeGrouped.get(0);

    String quotationId = firstQuoteToReference.getQuotationEntityId().getId();
    String sourceCode = firstQuoteToReference.getQuotationEntityId().getSourceCode();

    return Quotation.builder()
        .stripesReference(
            StripesReferenceHeader.builder()
                .id(quotationId)
                .description(getTM1IdDescription(quotationId, sourceCode))
                .source(buildSource(sourceCode, quotationSourceAndStripe.getStripe()))
                .calendar(null)
                .build())
        .prices(buildPricesFromQuotationList(quotationListWithPricesToBeGrouped, EU))
        .build();
  }

  private String getTM1IdDescription(String quotationId, String source) {
    return tm1QuoteDescriptionRepository
        .findByQuoteNumberAndQuoteSource(quotationId, source)
        .map(TM1QuoteDescriptionEntity::getDescription)
        .orElse(EMPTY_STRING);
  }

  private Quotation buildQuotationGroupingRelevantPricesFromQuotationEntityList(
      List<QuotationEntity> quotationListWithPricesToBeGrouped,
      QuotationSourceAndStripe quotationSourceAndStripe) {
    QuotationEntity firstQuoteToReference = quotationListWithPricesToBeGrouped.get(0);

    String quotationId = firstQuoteToReference.getQuotationEntityId().getId();
    String sourceCode = firstQuoteToReference.getQuotationEntityId().getSourceCode();
    Stripe stripe = quotationSourceAndStripe.getStripe();

    return Quotation.builder()
        .stripesReference(
            StripesReferenceHeader.builder()
                .id(quotationId)
                .description(getIdDescription(quotationId, sourceCode, stripe))
                .source(buildSource(sourceCode, stripe))
                .calendar(buildFactoryCalendar(firstQuoteToReference))
                .build())
        .prices(buildPricesFromQuotationList(quotationListWithPricesToBeGrouped, stripe))
        .build();
  }

  private QuotationSource buildSource(String sourceCode, Stripe stripe) {
    String desc;
    try {
      desc =
          quotationSourceDescriptionRepository
              .getQuotationSourceDescription(sourceCode, stripe)
              .map(QuotationSourceSAP::getSourceDescription).orElse(EMPTY_STRING);
    } catch (Exception e) {
      log.error("Cannot get Source Description from SAP ", e);
      desc = EMPTY_STRING;
    }
    return QuotationSource.builder().code(sourceCode).description(desc).build();
  }

  private String getIdDescription(String quotationId, String source, Stripe stripe) {
    return quotationIdDescriptionRepository
        .getQuotationIdDescription(quotationId, source, stripe)
        .map(QuotationIdSAP::getQuotationIdDescription)
        .orElse(EMPTY_STRING);
  }

  private FactoryCalendar buildFactoryCalendar(QuotationEntity firstQuoteToReference) {
    String factoryCalendarCode = firstQuoteToReference.getCalendarCode();
    String factoryCalendarDescription = firstQuoteToReference.getCalendarDescription();

    if (Strings.isNullOrEmpty(factoryCalendarCode)) {
      return null;
    }

    return FactoryCalendar.builder()
        .code(factoryCalendarCode)
        .description(factoryCalendarDescription)
        .build();
  }

  private List<QuotationPrice> buildPricesFromQuotationList(
      List<QuotationEntity> quotationListWithPricesToBeGrouped, Stripe stripe) {
    List<QuotationPrice> priceList = new ArrayList<>();

    for (QuotationEntity quotationEntity : quotationListWithPricesToBeGrouped) {
      boolean isARelevantPriceType =
          RELEVANT_PRICE_TYPES.contains(quotationEntity.getQuotationEntityId().getType());
      if (isARelevantPriceType) {
        priceList.add(buildPriceFromQuotation(quotationEntity, stripe));
      }
    }
    return priceList;
  }

  private QuotationPrice buildPriceFromQuotation(
      QuotationEntity quotationEntity, Stripe stripe) {
    QuotationType quotationType =
        QuotationType.builder()
            .code(quotationEntity.getQuotationEntityId().getType())
            .description(
                getTypeDescription(quotationEntity.getQuotationEntityId().getType(), stripe))
            .build();

    Price price = buildPrice(quotationEntity);

    Optional<UomSAP> uomCode = getUomCode(quotationEntity.getUnitOfMeasure(), stripe);

    return QuotationPrice.builder()
        .date(quotationEntity.getQuotationEntityId().getDate())
        .stripesReference(
            StripesReference.builder()
                .type(quotationType)
                .uom(buildUomTypeSAPForQuotationSAP(quotationEntity, uomCode, stripe).orElse(null))
                .build())
        .price(price)
        .uom(buildUomTypeISOForQuotationSAP(uomCode, quotationEntity).orElse(null))
        .build();
  }

  private Price buildPrice(QuotationEntity quotationEntity) {
    return Price.builder()
        .amount(quotationEntity.getPrice())
        .currency(quotationEntity.getCurrency())
        .build();
  }

  private String buildPriceCurrency(QuotationTM1 quotationTm1) {
    return tm1CurrencyEntityRepository
        .findByQuoteNumberAndAndQuoteSource(quotationTm1.getQuoteName(),
            quotationTm1.getQuoteSource())
        .map(TM1CurrencyEntity::getCurrency)
        .orElse(EMPTY_STRING);
  }

  private String getTypeDescription(String priceType, Stripe stripe) {
    try {
      return quotationPriceTypeDescriptionRepository
          .getQuotationPriceTypeDescription(priceType, stripe)
          .map(PriceTypeSAP::getTypeDescription)
          .orElse(EMPTY_STRING);
    } catch (Exception e) {
      log.error("Cannot get Type Description from SAP ", e);
      return EMPTY_STRING;
    }
  }

  private Optional<UomSAP> getUomCode(String unconvertedUom, Stripe stripe) {
    return uomRepository.getAllUom(stripe).stream()
        .filter(uomSAP -> unconvertedUom.equals(uomSAP.getUnconvertedUom()))
        .findAny();
  }

  private Optional<UnitOfMeasure> buildUomTypeSAPForQuotationSAP(
      QuotationEntity quotationEntity, Optional<UomSAP> uomCode, Stripe stripe) {
    String sapUomString =
        uomCode.map(UomSAP::getConvertedUom).orElse(quotationEntity.getUnitOfMeasure());
    if (EMPTY_STRING.equals(sapUomString)) {
      return Optional.empty();
    }
    return Optional.of(
        UnitOfMeasure.builder()
            .code(sapUomString)
            .description(
                getUnitOfMeasurementDescriptionFromSAP(quotationEntity.getUnitOfMeasure(), stripe))
            .build());
  }

  private String getUnitOfMeasurementDescriptionFromSAP(String unitOfMeasureCode, Stripe stripe) {
    if (EMPTY_STRING.equals(unitOfMeasureCode)) {
      return EMPTY_STRING;
    }
    return quotationUnitOfMeasurementDescriptionRepository
        .getQuotationUnitOfMeasurementDescription(unitOfMeasureCode, stripe)
        .map(UnitOfMeasurementSAP::getLongDescription)
        .orElse(EMPTY_STRING);
  }

  private Optional<UnitOfMeasure> buildUomTypeISOForQuotationSAP(Optional<UomSAP> uomCode, QuotationEntity quotationEntity) {
    if (isFromTM1(quotationEntity)) {
      return buildUomTypeISOForQuotationTM1(quotationEntity);
    } else {
      return uomCode.map(uom -> grdbUomEntityRepository.findByIsoUomCode(uom.getIsoCode()).map(grdbUomEntity ->
          UnitOfMeasure.builder()
              .code(grdbUomEntity.getIsoUomCode())
              .description(grdbUomEntity.getIsoUomName())
              .build()).orElse(null));
    }
  }

  private boolean isFromTM1(QuotationEntity quotationEntity) {
    return quotationEntity.getQuotationEntityId().getSourceCode().equals("PN");
  }

  private String getUnitOfMeasurementDescriptionFromDB(String isoUom) {
    return grdbUomEntityRepository
        .findById(isoUom)
        .map(GrdbUomEntity::getIsoUomName)
        .orElse(EMPTY_STRING);
  }

  private Optional<String> getUomTypeISOForQuotationTM1(String quoteNumber, String quoteSource) {
    return tm1UomEntityRepository.findByQuoteNumberAndAndQuoteSource(quoteNumber, quoteSource)
        .map(TM1UomEntity::getIsoUom);
  }

  private Optional<UnitOfMeasure> buildUomTypeISOForQuotationTM1(QuotationEntity quotationEntity) {
    return getUomTypeISOForQuotationTM1(quotationEntity.getQuotationEntityId().getId(), quotationEntity.getQuotationEntityId().getSourceCode())
        .map(
            isoUom ->
                UnitOfMeasure.builder()
                    .code(isoUom)
                    .description(getUnitOfMeasurementDescriptionFromDB(isoUom))
                    .build());
  }
}
