package com.eom.service.market.quote.util;

import static com.xom.odataclient.domain.Stripe.AP;
import static com.xom.odataclient.domain.Stripe.EU;
import static com.xom.odataclient.domain.Stripe.NA;
import static java.util.Arrays.asList;

import com.xom.odataclient.domain.Stripe;
import java.util.List;
import lombok.experimental.UtilityClass;
import org.springframework.boot.actuate.health.Status;

@UtilityClass
public class Constant {

  public static final int SECURITY_CONFIG_DEFAULT_ORDER = 99;
  public static final Status ACTIVE = new Status("ACTIVE");
  public static final Status INACTIVE = new Status("INACTIVE");
  public static final String EMPTY_STRING = "";
  public static final String PRICE_TYPE_HIGH = "H";
  public static final String PRICE_TYPE_MEDIUM = "M";
  public static final String PRICE_TYPE_LOW = "L";
  public static final String PRICE_TYPE_CLOSED = "C";
  public static final String PRICE_TYPE_INDEX = "I";
  public static final String PRICE_TYPE_VOLUME = "V";
  public static final String PRICE_DESCRIPTION_TYPE_VOLUME = "VOLUME";
  public static final String UOM_TYPE_SAP = "SAP";
  public static final String UOM_TYPE_ISO = "ISO";
  public static final List<Stripe> STRIPES_LIST = asList(NA, EU, AP);

  public static final List<String> RELEVANT_PRICE_TYPES =
      asList("H", "M", "L", "C", "I", "V", "S", "P");

}
