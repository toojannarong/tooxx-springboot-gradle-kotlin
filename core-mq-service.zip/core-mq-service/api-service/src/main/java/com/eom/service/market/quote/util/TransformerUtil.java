package com.eom.service.market.quote.util;

import java.math.BigDecimal;
import lombok.experimental.UtilityClass;
import org.springframework.util.Assert;

@UtilityClass
public class TransformerUtil {

  public static String scaleStringToSixDigits(String number) {
    Assert.notNull(number, "number should not be null");

    return new BigDecimal(number).setScale(6, BigDecimal.ROUND_HALF_UP).toString();
  }
}
