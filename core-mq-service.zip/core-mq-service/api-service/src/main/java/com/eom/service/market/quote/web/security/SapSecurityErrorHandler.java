package com.eom.service.market.quote.web.security;

import com.eom.errors.errorhandling.domain.ErrorsContext;
import com.xom.auth.azuread.security.SecurityErrorResponseTranslator;
import com.xom.odataclient.security.ODataAuthenticationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.HttpStatus.FORBIDDEN;

@ResponseBody
@ControllerAdvice(
    annotations = {RestController.class}
)
@RequiredArgsConstructor(onConstructor = @__({@Autowired}))
@Slf4j
public class SapSecurityErrorHandler {
  private final SecurityErrorResponseTranslator securityErrorResponseTranslator;

  @ResponseStatus(FORBIDDEN)
  @ExceptionHandler({ODataAuthenticationException.class})
  public ResponseEntity<ErrorsContext> handleODataAuthenticationException(
      ODataAuthenticationException e) {
    log.error("Failed to Authorize with SAP", e);
    return securityErrorResponseTranslator.translateErrorResponse(FORBIDDEN);
  }
}
