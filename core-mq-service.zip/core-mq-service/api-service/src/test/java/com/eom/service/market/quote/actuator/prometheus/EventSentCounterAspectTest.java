package com.eom.service.market.quote.actuator.prometheus;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.xom.errors.exceptions.SystemException;
import io.micrometer.core.instrument.Metrics;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
public class EventSentCounterAspectTest {

  @Mock
  ProceedingJoinPoint proceedingJoinPoint;

  private EventSentCounterAspect eventSentCounterAspect = new EventSentCounterAspect();

  @AfterEach
  void tearDown() {
    Metrics.globalRegistry.remove(Metrics.globalRegistry.getMeters().get(0).getId());
  }

  @Test
  void shouldShowSuccessMetricGivenEventHubPublishSuccess() throws Throwable {

    ReflectionTestUtils
        .setField(eventSentCounterAspect, "topicName", "market-quote-quote-change-dev-v1");

    CompletableFuture<Object> completableFuture = CompletableFuture.supplyAsync(() -> null);
    when(proceedingJoinPoint.proceed()).thenReturn(completableFuture);

    eventSentCounterAspect.countEventSent(proceedingJoinPoint);
    TimeUnit.SECONDS.sleep(1);

    assertEquals(1, Metrics.globalRegistry.getMeters().size());
    assertEquals("event_sent", Metrics.globalRegistry.getMeters().get(0).getId().getName());
    assertEquals("market-quote-quote-change-dev-v1", Metrics.globalRegistry.getMeters()
        .get(0).getId().getTag("eventhub_topic"));
  }

  @Test
  void shouldShowFailMetricGivenEventHubPublishFailed() throws Throwable {

    ReflectionTestUtils
        .setField(eventSentCounterAspect, "topicName", "market-quote-quote-change-dev-v1");

    CompletableFuture<Object> completableFuture = CompletableFuture.supplyAsync(() -> {
      throw new SystemException(new Exception());
    });
    when(proceedingJoinPoint.proceed()).thenReturn(completableFuture);

    eventSentCounterAspect.countEventSent(proceedingJoinPoint);

    TimeUnit.SECONDS.sleep(1);

    assertEquals(1, Metrics.globalRegistry.getMeters().size());
    assertEquals("event_sent_failed", Metrics.globalRegistry.getMeters().get(0).getId().getName());
    assertEquals("market-quote-quote-change-dev-v1", Metrics.globalRegistry.getMeters()
        .get(0).getId().getTag("eventhub_topic"));
  }
}
