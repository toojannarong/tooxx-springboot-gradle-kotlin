package com.eom.service.market.quote.actuator.prometheus;

import static com.xom.odataclient.domain.Stripe.EU;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.eom.service.market.quote.domain.fromsap.QuotationSAP;
import com.eom.service.market.quote.domain.fromtm1.QuotationTM1;
import io.micrometer.core.instrument.Metrics;
import java.util.stream.Stream;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class SourceOfDataCounterAspectTest {

  @Mock
  ProceedingJoinPoint proceedingJoinPoint;

  private SourceOfDataCounterAspect sourceOfDataCounterAspect = new SourceOfDataCounterAspect();

  @AfterEach
  void tearDown() {
    Metrics.globalRegistry.remove(Metrics.globalRegistry.getMeters().get(0).getId());
  }


  @Test
  void shouldShowCountMetricGivenConnectToSAP() throws Throwable {

    when(proceedingJoinPoint.getArgs()).thenReturn(new Object[]{"A2", EU});

    Stream<QuotationSAP> expectedQuotation = Stream.of(QuotationSAP.builder().build());

    when(proceedingJoinPoint.proceed(new Object[]{"A2", EU})).thenReturn(expectedQuotation);

    sourceOfDataCounterAspect.countQuoteData(proceedingJoinPoint);

    assertEquals(1, Metrics.globalRegistry.getMeters().size());
    assertEquals("sap_received", Metrics.globalRegistry.getMeters().get(0).getId().getName());
    assertEquals("EU", Metrics.globalRegistry.getMeters()
        .get(0).getId().getTag("sap_source"));

  }

  @Test
  void shouldShowCountMetricGivenConnectToTM1() throws Throwable {

    when(proceedingJoinPoint.getArgs()).thenReturn(new Object[]{"PN", "TM1"});

    Stream<QuotationTM1> expectedQuotation = Stream.of(QuotationTM1.builder().build());

    when(proceedingJoinPoint.proceed(new Object[]{"PN", "TM1"})).thenReturn(expectedQuotation);

    sourceOfDataCounterAspect.countQuoteData(proceedingJoinPoint);

    assertEquals(1, Metrics.globalRegistry.getMeters().size());
    assertEquals("sap_received", Metrics.globalRegistry.getMeters().get(0).getId().getName());
    assertEquals("TM1", Metrics.globalRegistry.getMeters()
        .get(0).getId().getTag("sap_source"));

  }

}
