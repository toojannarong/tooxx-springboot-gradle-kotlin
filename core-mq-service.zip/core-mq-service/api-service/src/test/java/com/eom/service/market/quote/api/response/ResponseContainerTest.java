package com.eom.service.market.quote.api.response;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ResponseContainerTest {

  @Test
  void buildJsonPrecededByData() {
    String expected = "{\"data\":\"Sample\"}";
    String actual = ResponseContainer.buildDataJson("Sample");

    assertThat(actual).isEqualTo(expected);
  }

}