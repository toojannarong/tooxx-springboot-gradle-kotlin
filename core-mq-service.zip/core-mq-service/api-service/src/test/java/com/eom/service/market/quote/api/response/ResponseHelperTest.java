package com.eom.service.market.quote.api.response;

import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ResponseHelperTest {

  private ResponseHelper responseHelper = new ResponseHelper();

  @Test
  void shouldReturnCorrectResponse() {
    Object object = new Object();
    ResponseEntity<ResponseContainer<Object>> expected =
        ResponseEntity.ok(new ResponseContainer<>(object));

    assertEquals(expected, responseHelper.response(object));
  }
}