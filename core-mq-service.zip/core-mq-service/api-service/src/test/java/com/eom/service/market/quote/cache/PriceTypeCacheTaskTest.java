package com.eom.service.market.quote.cache;

import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_QUOTATION_PRICE_TYPE_DESCRIPTION;
import static com.xom.odataclient.domain.Stripe.AP;
import static com.xom.odataclient.domain.Stripe.EU;
import static com.xom.odataclient.domain.Stripe.NA;
import static org.assertj.core.util.Lists.newArrayList;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.internal.verification.VerificationModeFactory.times;

import com.eom.service.market.quote.domain.fromsap.PriceTypeSAP;
import com.eom.service.market.quote.repository.QuotationPriceTypeDescriptionRepository;
import com.eom.service.market.quote.repository.cache.DashDelimitedParametersKeyGenerator;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.redis.core.RedisTemplate;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class PriceTypeCacheTaskTest {

  @Mock
  private QuotationPriceTypeDescriptionRepository quotationPriceTypeDescriptionRepository;

  @Mock
  private DashDelimitedParametersKeyGenerator generator;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private RedisTemplate<String, Object> redisTemplate;

  @InjectMocks
  private PriceTypeCacheTask priceTypeCacheTask;

  @Test
  void shouldCallQuotationPriceTypeDescriptionRepositoryToGetAllData() {
    priceTypeCacheTask.run(null);

    verify(quotationPriceTypeDescriptionRepository).findAll();
  }

  @Test
  void shouldCatchExceptionAndNotReThrowItBecauseOurSystemCanGetThisInformationDirectlyFromSAPWhenAConsumerCalls() {
    when(quotationPriceTypeDescriptionRepository.findAll()).thenThrow(new RuntimeException());

    assertDoesNotThrow(() -> priceTypeCacheTask.run(null));
  }

  @Test
  void shouldStoreEachPriceTypesResponseToRedis() {
    PriceTypeSAP priceTypeSAP = PriceTypeSAP.builder().id("code1").language("EN").stripe(AP).build();
    PriceTypeSAP priceTypeSAP1 = PriceTypeSAP.builder().id("code2").language("EN").stripe(AP).build();
    when(quotationPriceTypeDescriptionRepository.findAll())
        .thenReturn(Stream.of(priceTypeSAP, priceTypeSAP1));

    when(generator.generate(CACHE_QUOTATION_PRICE_TYPE_DESCRIPTION, "code1", AP))
        .thenReturn("code1");
    when(generator.generate(CACHE_QUOTATION_PRICE_TYPE_DESCRIPTION, "code1", NA))
        .thenReturn("code1");
    when(generator.generate(CACHE_QUOTATION_PRICE_TYPE_DESCRIPTION, "code1", EU))
        .thenReturn("code1");
    when(generator.generate(CACHE_QUOTATION_PRICE_TYPE_DESCRIPTION, "code2", AP))
        .thenReturn("code2");
    when(generator.generate(CACHE_QUOTATION_PRICE_TYPE_DESCRIPTION, "code2", NA))
        .thenReturn("code2");
    when(generator.generate(CACHE_QUOTATION_PRICE_TYPE_DESCRIPTION, "code2", EU))
        .thenReturn("code2");

    priceTypeCacheTask.run(null);

    ArgumentCaptor<String> stringArgumentCaptor = ArgumentCaptor.forClass(String.class);
    ArgumentCaptor<PriceTypeSAP> priceTypeSAPArgumentCaptor = ArgumentCaptor
        .forClass(PriceTypeSAP.class);
    verify(redisTemplate.opsForValue(), times(2))
        .set(stringArgumentCaptor.capture(), priceTypeSAPArgumentCaptor.capture());

    assertEquals(newArrayList("code1", "code2"), stringArgumentCaptor.getAllValues());
    assertEquals(newArrayList(priceTypeSAP, priceTypeSAP1),
        priceTypeSAPArgumentCaptor.getAllValues());
  }

}
