package com.eom.service.market.quote.cache;

import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_QUOTATION_ID_DESCRIPTION;
import static com.xom.odataclient.domain.Stripe.AP;
import static com.xom.odataclient.domain.Stripe.EU;
import static com.xom.odataclient.domain.Stripe.NA;
import static org.assertj.core.util.Lists.newArrayList;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.internal.verification.VerificationModeFactory.times;

import com.eom.service.market.quote.domain.fromsap.QuotationIdSAP;
import com.eom.service.market.quote.repository.QuotationIdDescriptionRepository;
import com.eom.service.market.quote.repository.cache.DashDelimitedParametersKeyGenerator;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.redis.core.RedisTemplate;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class QuoteIdDescriptionTaskTest {

  @Mock
  private QuotationIdDescriptionRepository quotationIdDescriptionRepository;

  @Mock
  private DashDelimitedParametersKeyGenerator generator;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private RedisTemplate<String, Object> redisTemplate;

  @InjectMocks
  private QuoteIdDescriptionTask quoteIdDescriptionTask;

  @Test
  void shouldCallQuotationIdDescriptionRepositoryToGetAllData() {
    quoteIdDescriptionTask.run(null);

    verify(quotationIdDescriptionRepository).findAll();
  }

  @Test
  void shouldCatchExceptionAndNotReThrowItBecauseOurSystemCanGetThisInformationDirectlyFromSAPWhenAConsumerCalls() {
    when(quotationIdDescriptionRepository.findAll()).thenThrow(new RuntimeException());

    assertDoesNotThrow(() -> quoteIdDescriptionTask.run(null));
  }

  @Test
  void shouldStoreEachQuotationIdDescriptionResponseToRedis() {
    QuotationIdSAP quotationIdSAP = QuotationIdSAP.builder().id("code1").source("A1").stripe(AP).build();
    QuotationIdSAP quotationIdSAP1 = QuotationIdSAP.builder().id("code2").source("A2").stripe(AP).build();
    when(quotationIdDescriptionRepository.findAll())
        .thenReturn(Stream.of(quotationIdSAP, quotationIdSAP1));

    when(generator.generate(CACHE_QUOTATION_ID_DESCRIPTION, "code1", "A1", AP)).thenReturn("code1");
    when(generator.generate(CACHE_QUOTATION_ID_DESCRIPTION, "code1", "A1", NA)).thenReturn("code1");
    when(generator.generate(CACHE_QUOTATION_ID_DESCRIPTION, "code1", "A1", EU)).thenReturn("code1");
    when(generator.generate(CACHE_QUOTATION_ID_DESCRIPTION, "code2", "A2", AP)).thenReturn("code2");
    when(generator.generate(CACHE_QUOTATION_ID_DESCRIPTION, "code2", "A2", NA)).thenReturn("code2");
    when(generator.generate(CACHE_QUOTATION_ID_DESCRIPTION, "code2", "A2", EU)).thenReturn("code2");

    quoteIdDescriptionTask.run(null);

    ArgumentCaptor<String> stringArgumentCaptor = ArgumentCaptor.forClass(String.class);
    ArgumentCaptor<QuotationIdSAP> quotationIdDescriptionCaptor = ArgumentCaptor
        .forClass(QuotationIdSAP.class);
    verify(redisTemplate.opsForValue(), times(2))
        .set(stringArgumentCaptor.capture(), quotationIdDescriptionCaptor.capture());

    assertEquals(newArrayList("code1", "code2"), stringArgumentCaptor.getAllValues());
    assertEquals(newArrayList(quotationIdSAP, quotationIdSAP1),
        quotationIdDescriptionCaptor.getAllValues());
  }

}
