package com.eom.service.market.quote.cache;

import static com.eom.service.market.quote.repository.constants.CacheConstants.CACHE_QUOTATION_SOURCE_DESCRIPTION;
import static com.xom.odataclient.domain.Stripe.AP;
import static com.xom.odataclient.domain.Stripe.EU;
import static com.xom.odataclient.domain.Stripe.NA;
import static org.assertj.core.util.Lists.newArrayList;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.internal.verification.VerificationModeFactory.times;

import com.eom.service.market.quote.domain.fromsap.QuotationIdSAP;
import com.eom.service.market.quote.domain.fromsap.QuotationSourceSAP;
import com.eom.service.market.quote.repository.QuotationSourceDescriptionRepository;
import com.eom.service.market.quote.repository.cache.DashDelimitedParametersKeyGenerator;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.redis.core.RedisTemplate;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class QuoteSourceDescriptionTaskTest {

  @Mock
  private QuotationSourceDescriptionRepository quotationSourceDescriptionRepository;

  @Mock
  private DashDelimitedParametersKeyGenerator generator;

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private RedisTemplate<String, Object> redisTemplate;

  @InjectMocks
  private QuoteSourceDescriptionTask quoteSourceDescriptionTask;

  @Test
  void shouldCallQuotationSourceDescriptionRepositoryToGetAllData() {
    quoteSourceDescriptionTask.run(null);

    verify(quotationSourceDescriptionRepository).findAll();
  }

  @Test
  void shouldCatchExceptionAndNotReThrowItBecauseOurSystemCanGetThisInformationDirectlyFromSAPWhenAConsumerCalls() {
    when(quotationSourceDescriptionRepository.findAll()).thenThrow(new RuntimeException());

    assertDoesNotThrow(() -> quoteSourceDescriptionTask.run(null));
  }

  @Test
  void shouldStoreEachQuotationSourceDescriptionResponseToRedis() {
    QuotationSourceSAP quotationSourceSAP = QuotationSourceSAP.builder().id("code1").stripe(AP).build();
    QuotationSourceSAP quotationSourceSAP1 = QuotationSourceSAP.builder().id("code2").stripe(AP).build();
    when(quotationSourceDescriptionRepository.findAll())
        .thenReturn(Stream.of(quotationSourceSAP, quotationSourceSAP1));

    when(generator.generate(CACHE_QUOTATION_SOURCE_DESCRIPTION, "code1", AP)).thenReturn("code1");
    when(generator.generate(CACHE_QUOTATION_SOURCE_DESCRIPTION, "code1", NA)).thenReturn("code1");
    when(generator.generate(CACHE_QUOTATION_SOURCE_DESCRIPTION, "code1", EU)).thenReturn("code1");
    when(generator.generate(CACHE_QUOTATION_SOURCE_DESCRIPTION, "code2", AP)).thenReturn("code2");
    when(generator.generate(CACHE_QUOTATION_SOURCE_DESCRIPTION, "code2", NA)).thenReturn("code2");
    when(generator.generate(CACHE_QUOTATION_SOURCE_DESCRIPTION, "code2", EU)).thenReturn("code2");

    quoteSourceDescriptionTask.run(null);

    ArgumentCaptor<String> stringArgumentCaptor = ArgumentCaptor.forClass(String.class);
    ArgumentCaptor<QuotationIdSAP> quotationSourceDescriptionCaptor = ArgumentCaptor
        .forClass(QuotationIdSAP.class);
    verify(redisTemplate.opsForValue(), times(2))
        .set(stringArgumentCaptor.capture(), quotationSourceDescriptionCaptor.capture());

    assertEquals(newArrayList("code1", "code2"), stringArgumentCaptor.getAllValues());
    assertEquals(newArrayList(quotationSourceSAP, quotationSourceSAP1),
        quotationSourceDescriptionCaptor.getAllValues());
  }
}
