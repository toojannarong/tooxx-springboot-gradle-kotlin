package com.eom.service.market.quote.health;

import com.eom.service.market.quote.health.EventHubHealthIndicator.EventHubStatus;
import com.microsoft.azure.eventhubs.EventHubClient;
import com.microsoft.azure.eventhubs.EventHubRuntimeInformation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Answers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.actuate.health.Health;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static com.eom.service.market.quote.util.Constant.ACTIVE;
import static com.eom.service.market.quote.util.Constant.INACTIVE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EventHubHealthIndicatorTest {

  private static final String MY_EVENTHUB_NAME = "my-eventhub";

  @Mock(answer = Answers.RETURNS_DEEP_STUBS)
  private EventHubClient eventHubClient;

  @Mock
  private Health.Builder healthCheckBuilder;

  private EventHubHealthIndicator eventHubHealthIndicator;

  @BeforeEach
  void setUp() {
    when(healthCheckBuilder.up()).thenReturn(healthCheckBuilder);
    when(healthCheckBuilder.withDetails(any())).thenReturn(healthCheckBuilder);
    eventHubHealthIndicator = new EventHubHealthIndicator(eventHubClient);
  }

  @Test
  void returnsActiveStatusHealthCheck() {
    when(healthCheckBuilder.status(ACTIVE.getCode())).thenReturn(healthCheckBuilder);
    provideInformationToEventHubClient(eventHubClient, MY_EVENTHUB_NAME, Instant.ofEpochMilli(10000));

    eventHubHealthIndicator.doHealthCheck(healthCheckBuilder);
    Health eventHubHealth = eventHubHealthIndicator.health();

    assertEquals(ACTIVE.getCode(), eventHubHealth.getStatus().toString());
    verify(healthCheckBuilder).status(ACTIVE.getCode());
  }

  @Test
  void returnsInactiveStatusHealthCheck() {
    when(healthCheckBuilder.status(INACTIVE.getCode())).thenReturn(healthCheckBuilder);
    makeEventHubConnectionDown(eventHubClient, MY_EVENTHUB_NAME);

    eventHubHealthIndicator.doHealthCheck(healthCheckBuilder);
    Health eventHubHealth = eventHubHealthIndicator.health();

    assertEquals(INACTIVE.getCode(), eventHubHealth.getStatus().toString());
    verify(healthCheckBuilder).status(INACTIVE.getCode());
  }

  @Test
  void returnsEventHubStatusDetails() {
    when(healthCheckBuilder.up()).thenReturn(healthCheckBuilder);
    when(healthCheckBuilder.status(ACTIVE.getCode())).thenReturn(healthCheckBuilder);
    when(healthCheckBuilder.withDetails(any())).thenReturn(healthCheckBuilder);
    provideInformationToEventHubClient(eventHubClient, MY_EVENTHUB_NAME, Instant.ofEpochMilli(10000));

    eventHubHealthIndicator.doHealthCheck(healthCheckBuilder);

    Health eventHubHealth = eventHubHealthIndicator.health();
    Map<String, Object> eventHubHealthDetails = eventHubHealth.getDetails();
    EventHubStatus expectedStatusDetail = EventHubStatus.ofActive(Instant.ofEpochMilli(10000), 32);
    assertEquals(expectedStatusDetail, eventHubHealthDetails.get(MY_EVENTHUB_NAME));
  }

  private void provideInformationToEventHubClient(EventHubClient eventHubClient, String eventHubName, Instant createdAt) {
    when(eventHubClient.getEventHubName()).thenReturn(eventHubName);
    EventHubRuntimeInformation runtimeInformation =
        new EventHubRuntimeInformation(eventHubName, createdAt, 32, null);
    when(eventHubClient.getRuntimeInformation()).thenReturn(CompletableFuture.completedFuture(runtimeInformation));
  }

  private void makeEventHubConnectionDown(EventHubClient eventHubClient, String eventHubName) {
    when(eventHubClient.getEventHubName()).thenReturn(eventHubName);
    when(eventHubClient.getRuntimeInformation()).thenReturn(CompletableFuture.supplyAsync(() -> {
      throw new RuntimeException("Exception Message");
    }));
  }
}