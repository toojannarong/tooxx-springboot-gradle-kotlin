package com.eom.service.market.quote.repository;

import static java.util.Collections.singletonList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

import com.eom.service.market.quote.api.response.ResponseContainer;
import com.eom.service.market.quote.domain.FactoryCalendar;
import com.eom.service.market.quote.domain.Price;
import com.eom.service.market.quote.domain.Quotation;
import com.eom.service.market.quote.domain.QuotationPrice;
import com.eom.service.market.quote.domain.QuotationSource;
import com.eom.service.market.quote.domain.QuotationType;
import com.eom.service.market.quote.domain.StripesReference;
import com.eom.service.market.quote.domain.StripesReferenceHeader;
import com.eom.service.market.quote.domain.UnitOfMeasure;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.microsoft.azure.eventhubs.EventData;
import com.microsoft.azure.eventhubs.EventHubClient;
import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ClassPathResource;

@ExtendWith(MockitoExtension.class)
class EventHubRepositoryTest {

  @Mock
  @Qualifier("realtimeEventHub")
  EventHubClient eventHubClient;

  @InjectMocks
  EventHubRepository eventHubRepository;

  @Test
  void sendEventToEventHub() throws IOException {
    Quotation expectedQuotation = Quotation.builder()
        .stripesReference(StripesReferenceHeader.builder()
            .id("DIESEL10CAR")
            .description("DIESEL 10PPM GERMANY BARGE NWE")
            .source(QuotationSource.builder()
                .code("A1")
                .description("ARGUS CRUDE").build())
            .calendar(FactoryCalendar.builder()
                .code("ZH")
                .description("Only Tuesday workday").build())
            .build())
        .prices(singletonList(QuotationPrice.builder()
            .date("2019-12-12")
            .stripesReference(StripesReference.builder()
                .type(QuotationType.builder()
                    .code("H")
                    .description("HIGH")
                    .build())
                .uom(UnitOfMeasure.builder()
                    .code("BB6")
                    .description("Barrel at 60 degrees")
                    .build())
                .build())
            .price(Price.builder().amount("12.999999").currency("USD").build())
            .uom(null)
            .build()
        ))
        .build();

    eventHubRepository.sendToEventHub(expectedQuotation);

    ArgumentCaptor<EventData> captor = ArgumentCaptor.forClass(EventData.class);

    verify(eventHubClient).send(captor.capture());

    TypeReference<ResponseContainer<Quotation>> typeReference =
        new TypeReference<ResponseContainer<Quotation>>() {
        };

    assertEquals(
        readFromFilePath("data/valid_quotation_response.json", typeReference),
        readValue(captor.getValue().getBytes(), typeReference));
  }

  private <T> T readFromFilePath(String filePath, TypeReference<T> typeReference)
      throws IOException {
    ObjectMapper objectMapper = new ObjectMapper()
        .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
        .registerModule(new JavaTimeModule());
    return objectMapper.readValue(new ClassPathResource(filePath).getFile(), typeReference);
  }

  private <T> T readValue(byte[] bytes, TypeReference<T> typeReference) throws IOException {
    ObjectMapper objectMapper = new ObjectMapper()
        .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
        .registerModule(new JavaTimeModule());
    return objectMapper.readValue(bytes, typeReference);
  }
}

