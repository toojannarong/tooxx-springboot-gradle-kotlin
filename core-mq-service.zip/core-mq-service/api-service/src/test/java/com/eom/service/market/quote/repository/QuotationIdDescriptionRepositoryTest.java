package com.eom.service.market.quote.repository;

import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_ALL_QUOTE_ID_DESCRIPTIONS;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_QUOTE_ID_DESCRIPTION;
import static com.xom.odataclient.domain.Stripe.AP;
import static com.xom.odataclient.domain.Stripe.EU;
import static com.xom.odataclient.domain.Stripe.NA;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.eom.service.market.quote.domain.fromsap.QuotationIdSAP;
import com.xom.odataclient.core.ODataClient;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class QuotationIdDescriptionRepositoryTest {

  private static final String QUOTATION_ID = "DIESEL10CAR";
  private static final String IRRELEVANT_SOURCE = "";
  @Mock
  private ODataClient oDataClient;
  @InjectMocks
  private QuotationIdDescriptionRepository repository;

  @Test
  void queryQuotationIdDescriptionSAPFromEUByQuotationId() {
    String sql = "SELECT QUOTNO, QUOSRC, QUOTDESC FROM OICQCT WHERE OICQCT~QUOTNO = 'DIESEL10CAR' AND SPRAS = 'E'";
    SingleOSqlQuery query = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_QUOTE_ID_DESCRIPTION, EU);

    repository.getQuotationIdDescription(QUOTATION_ID, IRRELEVANT_SOURCE, EU);

    verify(oDataClient).executeOSQL(query, QuotationIdSAP.class);
  }

  @Test
  void queryQuotationIdDescriptionSAPFromAPByQuotationId() {
    String sql = "SELECT QUOTNO, QUOSRC, QUOTDESC FROM OICQCT WHERE OICQCT~QUOTNO = 'DIESEL10CAR' AND SPRAS = 'E'";
    SingleOSqlQuery query = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_QUOTE_ID_DESCRIPTION, AP);

    repository.getQuotationIdDescription(QUOTATION_ID, IRRELEVANT_SOURCE, AP);

    verify(oDataClient).executeOSQL(query, QuotationIdSAP.class);
  }

  @Test
  void queryQuotationIdDescriptionSAPFromNAByQuotationId() {
    String sql = "SELECT QUOTNO, QUOSRC, QUOTDESC FROM OICQCT WHERE OICQCT~QUOTNO = 'DIESEL10CAR' AND SPRAS = 'E'";
    SingleOSqlQuery query = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_QUOTE_ID_DESCRIPTION, NA);

    repository.getQuotationIdDescription(QUOTATION_ID, IRRELEVANT_SOURCE, NA);

    verify(oDataClient).executeOSQL(query, QuotationIdSAP.class);
  }

  @Test
  void shouldReturnAllQuoteIDDescriptionsFromSapInEnglish() {
    String sql = "SELECT QUOTNO, QUOSRC, QUOTDESC FROM OICQCT WHERE SPRAS = 'E'";
    final SingleOSqlQuery queryEU = mockOSqlQuery(sql,
        MARKET_QUOTE_DOMAIN_ALL_QUOTE_ID_DESCRIPTIONS, EU);
    final SingleOSqlQuery queryAP = mockOSqlQuery(sql,
        MARKET_QUOTE_DOMAIN_ALL_QUOTE_ID_DESCRIPTIONS, AP);
    final SingleOSqlQuery queryNA = mockOSqlQuery(sql,
        MARKET_QUOTE_DOMAIN_ALL_QUOTE_ID_DESCRIPTIONS, NA);

    repository.findAll();

    verify(oDataClient).executeOSQL(queryEU, QuotationIdSAP.class);
    verify(oDataClient).executeOSQL(queryAP, QuotationIdSAP.class);
    verify(oDataClient).executeOSQL(queryNA, QuotationIdSAP.class);
  }

  @Test
  void getQuotationIdDescriptionOnSAP() {
    String expectedQuotationIdDescription = "DIESEL 10PPM GERMANY BARGE NWE";
    QuotationIdSAP quotationIdSAP = QuotationIdSAP.builder()
        .quotationIdDescription(expectedQuotationIdDescription).source("A2").build();
    QuotationIdSAP quotationIdSAPWithDifferentSource = QuotationIdSAP.builder()
        .quotationIdDescription("TEST DESC").source("A3").build();
    Stream<QuotationIdSAP> responseStream = Stream
        .of(quotationIdSAP, quotationIdSAPWithDifferentSource);
    when(oDataClient.executeOSQL(any(SingleOSqlQuery.class), eq(QuotationIdSAP.class)))
        .thenReturn(responseStream);

    Optional<QuotationIdSAP> result = repository.getQuotationIdDescription(QUOTATION_ID, "A2", EU);

    assertEquals(quotationIdSAP, result.get());
  }

  @Test
  void handleReturnWhenQuotationIdDescriptionDoesNotExist() {
    Stream<QuotationIdSAP> responseStream = Stream.empty();
    when(oDataClient.executeOSQL(any(SingleOSqlQuery.class), eq(QuotationIdSAP.class)))
        .thenReturn(responseStream);

    Optional<QuotationIdSAP> result = repository
        .getQuotationIdDescription("UNEXISTING FUEL", IRRELEVANT_SOURCE, EU);

    assertEquals(Optional.empty(), result);
  }

  private SingleOSqlQuery mockOSqlQuery(String sql, String uid, Stripe stripe) {
    return SingleOSqlQuery.builder()
        .uid(uid)
        .query(sql)
        .stripe(stripe)
        .build();
  }
}

