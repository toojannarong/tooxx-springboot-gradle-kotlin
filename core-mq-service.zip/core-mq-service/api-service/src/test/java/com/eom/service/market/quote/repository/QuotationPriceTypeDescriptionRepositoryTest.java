package com.eom.service.market.quote.repository;

import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_ALL_PRICE_TYPE_DESCRIPTIONS;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_PRICE_TYPE_DESCRIPTION;
import static com.xom.odataclient.domain.Stripe.AP;
import static com.xom.odataclient.domain.Stripe.EU;
import static com.xom.odataclient.domain.Stripe.NA;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.eom.service.market.quote.domain.fromsap.PriceTypeSAP;
import com.xom.odataclient.core.ODataClient;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class QuotationPriceTypeDescriptionRepositoryTest {

  private static final String PRICE_TYPE = "M";

  @Mock
  private ODataClient oDataClient;

  @InjectMocks
  private QuotationPriceTypeDescriptionRepository quotationPriceTypeDescriptionRepository;

  @Test
  void shouldQuerySAPForPriceTypeDescriptionFromEUByPriceType() {
    String sql = "SELECT QUOTYP, SPRAS, TYPDESC FROM OICQTT WHERE OICQTT~QUOTYP = 'M' AND SPRAS = 'E'";
    SingleOSqlQuery query = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_PRICE_TYPE_DESCRIPTION, EU);

    quotationPriceTypeDescriptionRepository.getQuotationPriceTypeDescription(PRICE_TYPE, EU);

    verify(oDataClient).executeOSQL(query, PriceTypeSAP.class);
  }

  @Test
  void shouldQuerySAPForPriceTypeDescriptionFromAPByPriceType() {
    String sql = "SELECT QUOTYP, SPRAS, TYPDESC FROM OICQTT WHERE OICQTT~QUOTYP = 'M' AND SPRAS = 'E'";
    SingleOSqlQuery query = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_PRICE_TYPE_DESCRIPTION, AP);

    quotationPriceTypeDescriptionRepository.getQuotationPriceTypeDescription(PRICE_TYPE, AP);

    verify(oDataClient).executeOSQL(query, PriceTypeSAP.class);
  }

  @Test
  void shouldQuerySAPForPriceTypeDescriptionFromNAByPriceType() {
    String sql = "SELECT QUOTYP, SPRAS, TYPDESC FROM OICQTT WHERE OICQTT~QUOTYP = 'M' AND SPRAS = 'E'";
    SingleOSqlQuery query = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_PRICE_TYPE_DESCRIPTION, NA);

    quotationPriceTypeDescriptionRepository.getQuotationPriceTypeDescription(PRICE_TYPE, NA);

    verify(oDataClient).executeOSQL(query, PriceTypeSAP.class);
  }

  @Test
  void shouldReturnAllPriceTypesDescriptionsFromSapInEnglish() {
    String sql = "SELECT QUOTYP, SPRAS, TYPDESC FROM OICQTT WHERE SPRAS = 'E'";
    final SingleOSqlQuery queryEU = mockOSqlQuery(sql,
        MARKET_QUOTE_DOMAIN_ALL_PRICE_TYPE_DESCRIPTIONS, EU);
    final SingleOSqlQuery queryNA = mockOSqlQuery(sql,
        MARKET_QUOTE_DOMAIN_ALL_PRICE_TYPE_DESCRIPTIONS, NA);
    final SingleOSqlQuery queryAP = mockOSqlQuery(sql,
        MARKET_QUOTE_DOMAIN_ALL_PRICE_TYPE_DESCRIPTIONS, AP);

    quotationPriceTypeDescriptionRepository.findAll();

    verify(oDataClient).executeOSQL(queryEU, PriceTypeSAP.class);
    verify(oDataClient).executeOSQL(queryAP, PriceTypeSAP.class);
    verify(oDataClient).executeOSQL(queryNA, PriceTypeSAP.class);
  }

  @Test
  void shouldReturnPriceTypeDescriptionWhenItExists() {
    String expectedPriceTypeDescription = "Medium";
    PriceTypeSAP priceTypeSAP = PriceTypeSAP.builder()
        .typeDescription(expectedPriceTypeDescription).build();
    Stream<PriceTypeSAP> responseStream = Stream
        .of(priceTypeSAP);
    when(oDataClient.executeOSQL(any(SingleOSqlQuery.class), eq(PriceTypeSAP.class)))
        .thenReturn(responseStream);

    Optional<PriceTypeSAP> result = quotationPriceTypeDescriptionRepository
        .getQuotationPriceTypeDescription(PRICE_TYPE, EU);

    assertEquals(result.get().getTypeDescription(), expectedPriceTypeDescription);
  }

  @Test
  void shouldReturnPriceTypeVolumeDescriptionWhenPriceTypeIsV() {
    String expectedPriceTypeDescription = "VOLUME";

    Optional<PriceTypeSAP> result = quotationPriceTypeDescriptionRepository
        .getQuotationPriceTypeDescription("V", EU);

    assertEquals(result.get().getTypeDescription(), expectedPriceTypeDescription);
  }

  @Test
  void shouldReturnEmptyPriceTypeDescriptionWhenItDoesNotExists() {
    Stream<PriceTypeSAP> responseStream = Stream.empty();
    when(oDataClient.executeOSQL(any(SingleOSqlQuery.class), eq(PriceTypeSAP.class)))
        .thenReturn(responseStream);

    Optional<PriceTypeSAP> result = quotationPriceTypeDescriptionRepository
        .getQuotationPriceTypeDescription("UNEXISTING TYPE", EU);

    assertEquals(result, Optional.empty());
  }

  private SingleOSqlQuery mockOSqlQuery(String sql, String uid, Stripe stripe) {
    return SingleOSqlQuery.builder()
        .uid(uid)
        .query(sql)
        .stripe(stripe)
        .build();
  }
}

