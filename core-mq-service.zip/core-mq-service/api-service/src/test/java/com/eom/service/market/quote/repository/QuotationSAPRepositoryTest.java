package com.eom.service.market.quote.repository;

import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_QUOTE_BETWEEN_DAYS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.eom.service.market.quote.domain.fromsap.QuotationSAP;
import com.xom.odataclient.core.ODataClient;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import constant.Constant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class QuotationSAPRepositoryTest {

  private static final String SOURCE_CODE = "A1";
  private static final Stripe STRIPE = Stripe.EU;
  private static final LocalDate TODAY = LocalDate.now();
  private static final LocalDate SEVERAL_DAYS_AGO = LocalDate.now()
      .minusDays(Constant.DAYS_FOR_QUOTATIONS);

  @Mock
  private ODataClient oDataClient;

  @InjectMocks
  private QuotationSAPRepository quotationSAPRepository;

  @Test
  void queryQuotationsSAPBySourceStripeAndDateRange() {
    String todayDateTime = TODAY.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
    String daysAgoDateTime = SEVERAL_DAYS_AGO.format(DateTimeFormatter.ofPattern("yyyyMMdd"));

    String sql = String
        .format("SELECT OICQP~QUOTNO, OICQP~QUOSRC, OICQP~DEFUOM, OICQP~QUOTYP, OICQP~PRICE, " +
                "OICQP~DEFPER, OICQP~DEFCURR, OICQP~QUOTDATE, OICQC~FACTCAL, TFACT~LTEXT " +
                "FROM OICQP LEFT JOIN OICQC ON OICQC~QUOSRC EQ OICQP~QUOSRC " +
                "AND OICQC~QUOTNO EQ OICQP~QUOTNO AND OICQC~QUOTYP EQ OICQP~QUOTYP LEFT JOIN TFACT ON TFACT~IDENT EQ OICQC~FACTCAL " +
                "WHERE TFACT~SPRAS EQ 'E' AND OICQP~QUOSRC EQ '%s' " +
                "AND OICQP~QUOTDATE BETWEEN '%s' AND '%s'", SOURCE_CODE, daysAgoDateTime,
            todayDateTime);

    Stream<QuotationSAP> expectedQuotation = Stream.of(QuotationSAP.builder().build());

    SingleOSqlQuery query = SingleOSqlQuery.builder()
        .uid(MARKET_QUOTE_DOMAIN_QUOTE_BETWEEN_DAYS)
        .query(sql)
        .stripe(STRIPE)
        .build();

    when(oDataClient.executeOSQL(query, QuotationSAP.class)).thenReturn(expectedQuotation);

    Stream<QuotationSAP> result = quotationSAPRepository
        .getQuotationsSAPBySourceStripeAndDateRange(SOURCE_CODE, STRIPE,
            SEVERAL_DAYS_AGO, TODAY);

    assertEquals(result, expectedQuotation);
  }

  @Test
  void throwsExceptionWhenGetQuotationsBySourceStripeAndDateRangeHasFromDateBiggerThenToDate() {
    assertThrows(IllegalArgumentException.class,
        () -> quotationSAPRepository
            .getQuotationsSAPBySourceStripeAndDateRange(SOURCE_CODE, STRIPE, TODAY,
                SEVERAL_DAYS_AGO),
        "'from' date is bigger then 'to' date");
  }
}
