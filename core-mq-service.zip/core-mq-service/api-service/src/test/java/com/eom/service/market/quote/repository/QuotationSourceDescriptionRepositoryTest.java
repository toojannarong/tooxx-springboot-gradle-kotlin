package com.eom.service.market.quote.repository;

import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_ALL_QUOTE_SOURCE_DESCRIPTIONS;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_QUOTE_SOURCE_DESCRIPTION;
import static com.xom.odataclient.domain.Stripe.AP;
import static com.xom.odataclient.domain.Stripe.EU;
import static com.xom.odataclient.domain.Stripe.NA;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.eom.service.market.quote.domain.fromsap.QuotationSourceSAP;
import com.xom.odataclient.core.ODataClient;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class QuotationSourceDescriptionRepositoryTest {

  private static final String QUOTATION_SOURCE = "A1";

  @Mock
  private ODataClient oDataClient;

  @InjectMocks
  private QuotationSourceDescriptionRepository repository;

  @Test
  void queryQuotationSourceDescriptionInEnglishSAPFromEUByQuotationSource() {
    String sql = String
        .format("SELECT QUOSRC, SRCDESC FROM OICQST WHERE OICQST~QUOSRC = 'A1' AND SPRAS = 'E'");
    SingleOSqlQuery query = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_QUOTE_SOURCE_DESCRIPTION, EU);

    repository.getQuotationSourceDescription(QUOTATION_SOURCE, EU);

    verify(oDataClient).executeOSQL(query, QuotationSourceSAP.class);
  }

  @Test
  void queryQuotationSourceDescriptionInEnglishSAPFromNAByQuotationSource() {
    String sql = String
        .format("SELECT QUOSRC, SRCDESC FROM OICQST WHERE OICQST~QUOSRC = 'A1' AND SPRAS = 'E'");
    SingleOSqlQuery query = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_QUOTE_SOURCE_DESCRIPTION, NA);

    repository.getQuotationSourceDescription(QUOTATION_SOURCE, NA);

    verify(oDataClient).executeOSQL(query, QuotationSourceSAP.class);
  }

  @Test
  void queryQuotationSourceDescriptionInEnglishSAPFromAPByQuotationSource() {
    String sql = String
        .format("SELECT QUOSRC, SRCDESC FROM OICQST WHERE OICQST~QUOSRC = 'A1' AND SPRAS = 'E'");
    SingleOSqlQuery query = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_QUOTE_SOURCE_DESCRIPTION, AP);

    repository.getQuotationSourceDescription(QUOTATION_SOURCE, AP);

    verify(oDataClient).executeOSQL(query, QuotationSourceSAP.class);
  }

  @Test
  void shouldReturnAllSourceDescriptionsInEnglish() {
    String sql = "SELECT QUOSRC, SRCDESC FROM OICQST WHERE SPRAS = 'E'";
    final SingleOSqlQuery queryEU = mockOSqlQuery(sql,
        MARKET_QUOTE_DOMAIN_ALL_QUOTE_SOURCE_DESCRIPTIONS, EU);
    final SingleOSqlQuery queryNA = mockOSqlQuery(sql,
        MARKET_QUOTE_DOMAIN_ALL_QUOTE_SOURCE_DESCRIPTIONS, NA);
    final SingleOSqlQuery queryAP = mockOSqlQuery(sql,
        MARKET_QUOTE_DOMAIN_ALL_QUOTE_SOURCE_DESCRIPTIONS, AP);

    repository.findAll();

    verify(oDataClient).executeOSQL(queryEU, QuotationSourceSAP.class);
    verify(oDataClient).executeOSQL(queryNA, QuotationSourceSAP.class);
    verify(oDataClient).executeOSQL(queryAP, QuotationSourceSAP.class);
  }

  @Test
  void getQuotationSourceDescriptionOnSAPInEnglish() {
    String expectedQuotationSourceDescription = "ARGUS CRUDE";
    QuotationSourceSAP quotationSourceSAP = QuotationSourceSAP.builder()
        .sourceDescription(expectedQuotationSourceDescription).build();
    Stream<QuotationSourceSAP> responseStream = Stream
        .of(quotationSourceSAP);
    when(oDataClient.executeOSQL(any(SingleOSqlQuery.class), eq(QuotationSourceSAP.class)))
        .thenReturn(responseStream);

    Optional<QuotationSourceSAP> result = repository
        .getQuotationSourceDescription(QUOTATION_SOURCE, EU);

    assertEquals(quotationSourceSAP, result.get());
  }

  @Test
  void handleReturnWhenQuotationSourceDoesNotExist() {
    Stream<QuotationSourceSAP> responseStream = Stream.empty();
    when(oDataClient.executeOSQL(any(SingleOSqlQuery.class), eq(QuotationSourceSAP.class)))
        .thenReturn(responseStream);

    Optional<QuotationSourceSAP> result = repository
        .getQuotationSourceDescription("UNEXISTING SOURCE", EU);

    assertEquals(Optional.empty(), result);
  }

  private SingleOSqlQuery mockOSqlQuery(String sql, String uid, Stripe stripe) {
    return SingleOSqlQuery.builder()
        .uid(uid)
        .query(sql)
        .stripe(stripe)
        .build();
  }
}

