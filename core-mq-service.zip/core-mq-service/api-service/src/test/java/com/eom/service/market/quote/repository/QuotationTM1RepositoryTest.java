package com.eom.service.market.quote.repository;

import com.eom.service.market.quote.domain.fromtm1.QuotationTM1;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.time.LocalDate;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class QuotationTM1RepositoryTest {

  @Mock
  private RestTemplate restTemplate;

  @InjectMocks
  private QuotationTM1Repository quotationTM1Repository;

  @Captor
  private ArgumentCaptor<URI> uri;

  @BeforeEach
  void setUp() {
    ReflectionTestUtils.setField(quotationTM1Repository, "tm1Uri", "http://localhost:8080");
  }

  @Test
  void shouldReturnQuotationTM1WhenGivenQuoteSourceAndStartDateAndEndDate() {
    LocalDate startDate = LocalDate.of(2020, 2, 14);
    LocalDate endDate = LocalDate.of(2020, 2, 15);
    QuotationTM1[] expected = {QuotationTM1.builder().build()};
    when(restTemplate.getForEntity(ArgumentMatchers.any(URI.class), eq(QuotationTM1[].class)))
        .thenReturn(ResponseEntity.ok(expected));

    Stream<QuotationTM1> actual = quotationTM1Repository
        .getQuotationsTM1ByQuoteSourceAndStartDateAndEndDate("PN", startDate, endDate);

    verify(restTemplate).getForEntity(uri.capture(), eq(QuotationTM1[].class));
    assertArrayEquals(expected, actual.toArray(QuotationTM1[]::new));
    assertEquals(
        "http://localhost:8080/api/sap?quotesource=PN&date=20200214,20200215",
        uri.getValue().toString());
  }

  @Test
  void shouldCallQuotationsByDateRangeThrowException() {
    LocalDate startDate = LocalDate.of(2020, 2, 14);
    LocalDate endDate = LocalDate.of(2020, 2, 15);
    when(restTemplate.getForEntity(ArgumentMatchers.any(URI.class), eq(QuotationTM1[].class)))
        .thenThrow(new RuntimeException());

    Stream<QuotationTM1> actual = quotationTM1Repository
        .getQuotationsTM1ByQuoteSourceAndStartDateAndEndDate("PN", startDate, endDate);

    verify(restTemplate).getForEntity(uri.capture(), eq(QuotationTM1[].class));
    assertEquals(0, actual.count());
    assertEquals(
        "http://localhost:8080/api/sap?quotesource=PN&date=20200214,20200215",
        uri.getValue().toString());
  }

}
