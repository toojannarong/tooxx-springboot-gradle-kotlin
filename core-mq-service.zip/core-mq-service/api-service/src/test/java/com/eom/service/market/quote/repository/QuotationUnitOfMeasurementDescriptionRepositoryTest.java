package com.eom.service.market.quote.repository;

import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_ALL_UOM_DESCRIPTIONS;
import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_UOM_DESCRIPTION;
import static com.xom.odataclient.domain.Stripe.AP;
import static com.xom.odataclient.domain.Stripe.EU;
import static com.xom.odataclient.domain.Stripe.NA;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.eom.service.market.quote.domain.fromsap.UnitOfMeasurementSAP;
import com.xom.odataclient.core.ODataClient;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class QuotationUnitOfMeasurementDescriptionRepositoryTest {

  private static final String UNIT_OF_MEASURE = "BB6";

  @Mock
  private ODataClient oDataClient;

  @InjectMocks
  private QuotationUnitOfMeasurementDescriptionRepository quotationUnitOfMeasurementDescriptionRepository;

  @Test
  void shouldQuerySAPForUnitOfMeasurementDescriptionFromEUByCode() {
    String sql = "SELECT MSEHI, MSEHL FROM T006A WHERE T006A~MSEHI = 'BB6' AND SPRAS = 'E'";
    SingleOSqlQuery query = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_UOM_DESCRIPTION, EU);

    quotationUnitOfMeasurementDescriptionRepository
        .getQuotationUnitOfMeasurementDescription(UNIT_OF_MEASURE, EU);

    verify(oDataClient).executeOSQL(query, UnitOfMeasurementSAP.class);
  }

  @Test
  void shouldQuerySAPForUnitOfMeasurementDescriptionFromAPByCode() {
    String sql = "SELECT MSEHI, MSEHL FROM T006A WHERE T006A~MSEHI = 'BB6' AND SPRAS = 'E'";
    SingleOSqlQuery query = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_UOM_DESCRIPTION, AP);

    quotationUnitOfMeasurementDescriptionRepository
        .getQuotationUnitOfMeasurementDescription(UNIT_OF_MEASURE, AP);

    verify(oDataClient).executeOSQL(query, UnitOfMeasurementSAP.class);
  }

  @Test
  void shouldQuerySAPForUnitOfMeasurementDescriptionFromNAByCode() {
    String sql = "SELECT MSEHI, MSEHL FROM T006A WHERE T006A~MSEHI = 'BB6' AND SPRAS = 'E'";
    SingleOSqlQuery query = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_UOM_DESCRIPTION, NA);

    quotationUnitOfMeasurementDescriptionRepository
        .getQuotationUnitOfMeasurementDescription(UNIT_OF_MEASURE, NA);

    verify(oDataClient).executeOSQL(query, UnitOfMeasurementSAP.class);
  }


  @Test
  void shouldReturnAllUnitsOfMeasurementInEnglish() {
    String sql = "SELECT MSEHI, MSEHL FROM T006A WHERE SPRAS = 'E'";
    final SingleOSqlQuery queryEU = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_ALL_UOM_DESCRIPTIONS,
        EU);
    final SingleOSqlQuery queryAP = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_ALL_UOM_DESCRIPTIONS,
        AP);
    final SingleOSqlQuery queryNA = mockOSqlQuery(sql, MARKET_QUOTE_DOMAIN_ALL_UOM_DESCRIPTIONS,
        NA);

    quotationUnitOfMeasurementDescriptionRepository.findAll();

    verify(oDataClient).executeOSQL(queryEU, UnitOfMeasurementSAP.class);
    verify(oDataClient).executeOSQL(queryAP, UnitOfMeasurementSAP.class);
    verify(oDataClient).executeOSQL(queryNA, UnitOfMeasurementSAP.class);
  }

  @Test
  void shouldReturnUnitOfMeasurementDescriptionWhenItExists() {
    String expectedUnitOfMeasurementDescription = "barrel at 60 degrees";
    UnitOfMeasurementSAP unitOfMeasurementSAP = UnitOfMeasurementSAP.builder()
        .longDescription(expectedUnitOfMeasurementDescription).build();
    Stream<UnitOfMeasurementSAP> responseStream = Stream
        .of(unitOfMeasurementSAP);
    when(oDataClient.executeOSQL(any(SingleOSqlQuery.class), eq(UnitOfMeasurementSAP.class)))
        .thenReturn(responseStream);

    Optional<UnitOfMeasurementSAP> result = quotationUnitOfMeasurementDescriptionRepository
        .getQuotationUnitOfMeasurementDescription(UNIT_OF_MEASURE, EU);

    assertEquals(result.get(), unitOfMeasurementSAP);
  }

  @Test
  void shouldReturnEmptyUnitOfMeasurementDescriptionWhenItDoesNotExists() {
    Stream<UnitOfMeasurementSAP> responseStream = Stream.empty();
    when(oDataClient.executeOSQL(any(SingleOSqlQuery.class), eq(UnitOfMeasurementSAP.class)))
        .thenReturn(responseStream);

    Optional<UnitOfMeasurementSAP> result = quotationUnitOfMeasurementDescriptionRepository
        .getQuotationUnitOfMeasurementDescription("UNEXISTING SOURCE", EU);

    assertEquals(result, Optional.empty());
  }

  private SingleOSqlQuery mockOSqlQuery(String sql, String uid, Stripe stripe) {
    return SingleOSqlQuery.builder()
        .uid(uid)
        .query(sql)
        .stripe(stripe)
        .build();
  }
}
