package com.eom.service.market.quote.repository;

import static com.eom.service.market.quote.repository.constants.QueryUidConstants.MARKET_QUOTE_DOMAIN_UNCONVERTED_CONVERTED_ISO_UOM;
import static org.mockito.Mockito.verify;

import com.eom.service.market.quote.domain.fromsap.UomSAP;
import com.xom.odataclient.core.ODataClient;
import com.xom.odataclient.domain.SingleOSqlQuery;
import com.xom.odataclient.domain.Stripe;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class UomRepositoryTest {

  @InjectMocks
  private UomRepository uomRepository;

  @Mock
  private ODataClient oDataClient;

  @Test
  void shouldReturnAllUomWhenGetUom() {
    uomRepository.getAllUom(Stripe.NA);

    SingleOSqlQuery singleOSqlQuery =
        SingleOSqlQuery.builder()
            .uid(MARKET_QUOTE_DOMAIN_UNCONVERTED_CONVERTED_ISO_UOM)
            .query(
                "SELECT T006A~MSEHI, MSEH3, ISOCODE FROM T006A LEFT JOIN T006 ON T006A~MSEHI EQ T006~MSEHI WHERE SPRAS = 'E'")
            .stripe(Stripe.NA)
            .build();

    verify(oDataClient).executeOSQL(singleOSqlQuery, UomSAP.class);
  }
}
