package com.eom.service.market.quote.repository.cache;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.eom.service.market.quote.repository.QuotationPriceTypeDescriptionRepository;
import com.xom.odataclient.domain.Stripe;
import java.lang.reflect.Method;
import org.junit.jupiter.api.Test;

class DashDelimitedParametersKeyGeneratorTest {

  @Test
  void shouldGenerateCacheKeyFromTwoInputParams() {
    String actual = new DashDelimitedParametersKeyGenerator()
        .generate("test", Stripe.NA);

    assertEquals("test::NA", actual);
  }

  @Test
  void shouldGenerateCacheKeyFromThreeInputParams() throws NoSuchMethodException {
    Method method = QuotationPriceTypeDescriptionRepository.class.getMethod(
        "getQuotationPriceTypeDescription", String.class, Stripe.class);

    Object typeDescription = new DashDelimitedParametersKeyGenerator()
        .generate(new QuotationPriceTypeDescriptionRepository(), method, "M");

    assertEquals("M", typeDescription);
  }

}
