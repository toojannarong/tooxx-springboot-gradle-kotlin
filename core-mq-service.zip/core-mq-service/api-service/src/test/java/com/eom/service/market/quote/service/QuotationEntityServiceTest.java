package com.eom.service.market.quote.service;

import com.eom.service.market.quote.domain.Quotation;
import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.domain.entity.QuotationEntityId;
import com.eom.service.market.quote.repository.QuotationEntityRepository;
import com.eom.service.market.quote.support.QuotationFactory;
import com.eom.service.market.quote.transformers.QuotationEntityTransformer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class QuotationEntityServiceTest {

  private static final LocalDateTime LOCAL_DATE_TIME = LocalDateTime.of(1997, 7, 30, 13, 5, 0, 0);

  @Mock
  private QuotationEntityRepository quotationEntityRepository;

  @Mock
  private QuotationEntityTransformer quotationEntityTransformer;

  @InjectMocks
  private QuotationEntityService quotationEntityService;


  @Test
  void filterNewQuotationSAPs() {
    doReturn(Optional.empty()).when(quotationEntityRepository).findById(any());

    QuotationEntity quotationEntity = QuotationEntity.builder().quotationEntityId(QuotationEntityId.builder().type("H").build()).price("300.000000").build();

    Stream<QuotationEntity> quotationEntityStream =
        quotationEntityService.filterNewAndUpdatedQuotationSAPs(Stream.of(quotationEntity));

    assertEquals(1, quotationEntityStream.count());
  }

  @Test
  void filterUpdatedQuotationSAPs() {
    QuotationEntity quotationEntity = createQuotationEntity("MOGASUNLRFOB", "H", "300.000000");
    doReturn(Optional.of(quotationEntity)).when(quotationEntityRepository).findById(any());

    QuotationEntity quotationEntityParam = QuotationEntity.builder().quotationEntityId(QuotationEntityId.builder().type("H").build()).price("302.000000").build();

    Stream<QuotationEntity> quotationEntityStream =
        quotationEntityService.filterNewAndUpdatedQuotationSAPs(Stream.of(quotationEntityParam));

    assertEquals(1, quotationEntityStream.count());
  }

  @Test
  void filterNoQuotationSAPs() {
    QuotationEntity quotationEntity = createQuotationEntity("MOGASUNLRFOB", "H", "300.000000");
    doReturn(Optional.of(quotationEntity)).when(quotationEntityRepository).findById(any());

    QuotationEntity quotationEntityParam = createQuotationEntity("MOGASUNLRFOB", "H", "300.000000");
    quotationEntityParam.setCreatedAt(null);

    Stream<QuotationEntity> quotationEntityStream =
        quotationEntityService.filterNewAndUpdatedQuotationSAPs(Stream.of(quotationEntityParam));

    assertEquals(0, quotationEntityStream.count());
  }

  @Test
  void saveAsQuotationEntity() {
    Quotation quotation = createQuotation("MOGASUNLRFOB");

    List<QuotationEntity> quotationEntityList = mockFirstQuotationEntityList();

    when(quotationEntityTransformer.transformToEntityFromQuotation(quotation)).thenReturn(quotationEntityList);

    quotationEntityService.saveAsQuotationEntity(quotation);

    verify(quotationEntityRepository).save(quotationEntityList.get(0));
    verify(quotationEntityRepository).save(quotationEntityList.get(1));
    verify(quotationEntityRepository).save(quotationEntityList.get(2));
  }

  private List<QuotationEntity> mockFirstQuotationEntityList() {
    return Arrays.asList(
        createQuotationEntity("MOGASUNLRFOB", "H", "300.000000"),
        createQuotationEntity("MOGASUNLRFOB", "M", "250.000000"),
        createQuotationEntity("MOGASUNLRFOB", "L", "200.000000"));
  }

  private Quotation createQuotation(String quotationId) {
    return QuotationFactory.createQuotation(
        quotationId, "A2", "300.000000", "250.000000", "200.000000");
  }

  private QuotationEntity createQuotationEntity(String id, String type, String price) {
    return QuotationFactory.createQuotationEntity(id, "A2", type, price, LOCAL_DATE_TIME, null);
  }
}
