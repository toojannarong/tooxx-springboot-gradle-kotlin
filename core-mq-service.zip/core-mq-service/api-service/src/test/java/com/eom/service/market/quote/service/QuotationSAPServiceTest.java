package com.eom.service.market.quote.service;

import com.eom.service.market.quote.domain.QueryPeriod;
import com.eom.service.market.quote.domain.QuotationSourceAndStripe;
import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.repository.QuotationSAPRepository;
import com.eom.service.market.quote.transformers.QuotationEntityTransformer;
import com.xom.odataclient.domain.Stripe;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.util.Lists.newArrayList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class QuotationSAPServiceTest {

  @Mock
  private QuotationSAPRepository quotationSAPRepository;

  @Mock
  private QuotationEntityTransformer quotationEntityTransformer;

  @InjectMocks
  private QuotationSAPService quotationSAPService;

  @Test
  void shouldCallQuotationsByDateRange() {
    QuotationEntity quotationEntity = QuotationEntity.builder().build();
    doReturn(Stream.of(quotationEntity))
        .when(quotationEntityTransformer)
        .transformToEntityFromSap(any());

    LocalDate today = LocalDate.now();
    Stream<QuotationEntity> actual =
        quotationSAPService.getQuotationsSAPForPeriodTime(
            QueryPeriod.builder()
                .fromDate(today)
                .toDate(today)
                .quotationSourceAndStripe(
                    QuotationSourceAndStripe.builder()
                        .quotationSource("A1")
                        .stripe(Stripe.NA)
                        .build())
                .build());

    verify(quotationSAPRepository)
        .getQuotationsSAPBySourceStripeAndDateRange("A1", Stripe.NA, today, today);
    assertIterableEquals(actual.collect(Collectors.toList()), newArrayList(quotationEntity));
  }

  @Test
  void shouldCallQuotationsByDateRangeThrowException() {
    doThrow(new IllegalArgumentException())
        .when(quotationSAPRepository).getQuotationsSAPBySourceStripeAndDateRange(any(), any(), any(), any());

    LocalDate today = LocalDate.now();
    Stream<QuotationEntity> actual =
        quotationSAPService.getQuotationsSAPForPeriodTime(
            QueryPeriod.builder()
                .fromDate(today)
                .toDate(today)
                .quotationSourceAndStripe(
                    QuotationSourceAndStripe.builder()
                        .quotationSource("A1")
                        .stripe(Stripe.NA)
                        .build())
                .build());

    verify(quotationSAPRepository)
        .getQuotationsSAPBySourceStripeAndDateRange("A1", Stripe.NA, today, today);
    assertEquals(actual.count(), 0);
  }
}
