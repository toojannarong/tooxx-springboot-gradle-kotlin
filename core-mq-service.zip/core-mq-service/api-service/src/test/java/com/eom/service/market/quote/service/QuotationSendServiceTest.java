package com.eom.service.market.quote.service;

import com.eom.service.market.quote.domain.Quotation;
import com.eom.service.market.quote.domain.QuotationSourceAndStripe;
import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.domain.entity.QuotationEntityId;
import com.eom.service.market.quote.repository.EventHubRepository;
import com.eom.service.market.quote.repository.QuotationSourcesAndStripesRepository;
import com.eom.service.market.quote.transformers.QuotationEntityTransformer;
import com.xom.odataclient.domain.Stripe;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;

import static com.google.common.collect.Lists.newArrayList;
import static java.time.LocalDate.now;
import static java.time.format.DateTimeFormatter.ofPattern;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class QuotationSendServiceTest {

  @Mock
  private EventHubRepository eventHubRepository;

  @Mock
  private QuotationEntityService quotationEntityService;

  @Mock
  private QuotationEntityTransformer quotationEntityTransformer;

  @Mock
  private QuotationSAPService quotationSAPService;

  @Mock
  private QuotationTM1Service quotationTM1Service;

  @Mock
  private QuotationSourcesAndStripesRepository quotationSourcesAndStripesRepository;

  @InjectMocks
  private QuotationSendService quotationSendService;


  @Test
  void shouldSendHubTwiceGivenTwoQuotationsForSap() {
    Quotation quotation1 = mock(Quotation.class);
    Quotation quotation2 = mock(Quotation.class);
    when(eventHubRepository.sendToEventHub(any(Quotation.class)))
        .thenReturn(CompletableFuture.completedFuture(null));

    doReturn(Stream.of(new QuotationSourceAndStripe("A1", Stripe.NA, 1))).when(quotationSourcesAndStripesRepository).getQuotationsSourcesAndStripes();
    doReturn(Stream.of(buildQuotationEntity())).when(quotationSAPService).getQuotationsSAPForPeriodTime(any());
    doReturn(Stream.of(buildQuotationEntity())).when(quotationEntityService).filterNewAndUpdatedQuotationSAPs(any());
    doReturn(newArrayList(quotation1, quotation2)).when(quotationEntityTransformer).transformToQuotationForSap(any(), any());

    int actual = quotationSendService.sendAndSaveQuotationsForSap();

    verify(eventHubRepository, times(2)).sendToEventHub(any(Quotation.class));
    verify(quotationEntityService, times(2)).saveAsQuotationEntity(any(Quotation.class));
    assertEquals(2, actual);
  }

  @Test
  void shouldSendHubTwiceGivenTwoQuotationsForTM1() {
    Quotation quotation1 = mock(Quotation.class);
    Quotation quotation2 = mock(Quotation.class);
    when(eventHubRepository.sendToEventHub(any(Quotation.class)))
        .thenReturn(CompletableFuture.completedFuture(null));

    doReturn(Stream.of(buildQuotationEntity())).when(quotationTM1Service).getQuotationsTM1ForPeriodTime();
    doReturn(Stream.of(buildQuotationEntity())).when(quotationEntityService).filterNewAndUpdatedQuotationSAPs(any());
    doReturn(newArrayList(quotation1, quotation2)).when(quotationEntityTransformer).transformToQuotationForTm1(any());

    int actual = quotationSendService.sendAndSaveQuotationsForTM1();

    verify(eventHubRepository, times(2)).sendToEventHub(any(Quotation.class));
    verify(quotationEntityService, times(2)).saveAsQuotationEntity(any(Quotation.class));
    assertEquals(2, actual);
  }

  private QuotationEntity buildQuotationEntity() {
    return QuotationEntity.builder()
        .quotationEntityId(QuotationEntityId.builder()
            .id("ADNOCFORMC")
            .sourceCode("A1")
            .date(now().format(ofPattern("yyyy-MM-dd")))
            .type("H")
            .build())
        .price("300.000000")
        .currency("USD")
        .unitOfMeasure("BB6")
        .calendarCode("ZH")
        .calendarDescription("Only Tuesday workday")
        .createdAt(LocalDateTime.now())
        .updatedAt(LocalDateTime.now())
        .build();
  }
}
