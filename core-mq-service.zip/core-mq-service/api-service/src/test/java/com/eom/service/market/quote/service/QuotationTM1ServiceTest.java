package com.eom.service.market.quote.service;

import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.domain.fromtm1.QuotationTM1;
import com.eom.service.market.quote.repository.QuotationTM1Repository;
import com.eom.service.market.quote.transformers.QuotationEntityTransformer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Collections.singletonList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class QuotationTM1ServiceTest {

  @InjectMocks
  private QuotationTM1Service quotationTM1Service;

  @Mock
  private QuotationTM1Repository quotationTM1Repository;

  @Mock
  private QuotationEntityTransformer quotationEntityTransformer;

  @Test
  void shouldReturnQuotationsFromTM1Source() {
    QuotationEntity quotationEntity = QuotationEntity.builder().build();
    List<QuotationEntity> expected = singletonList(quotationEntity);
    when(quotationTM1Repository
        .getQuotationsTM1ByQuoteSourceAndStartDateAndEndDate(anyString(), any(LocalDate.class),
            any(LocalDate.class)))
        .thenReturn(createQuotationTM1("ALGNQNCITYGTAB", "PN", "2.33"));
    when(quotationEntityTransformer.transformToEntityFromTM1(any())).thenReturn(Stream.of(quotationEntity));
    Stream<QuotationEntity> actual = quotationTM1Service.getQuotationsTM1ForPeriodTime();

    assertEquals(expected, actual.collect(Collectors.toList()));
  }

  private Stream<QuotationTM1> createQuotationTM1(String quoteName, String quoteSource,
                                                  String value) {
    return Stream.of(QuotationTM1.builder()
        .quoteName(quoteName)
        .quoteSource(quoteSource)
        .value(value)
        .date("20190601")
        .quoteType("V")
        .build());
  }
}
