package com.eom.service.market.quote.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class SchedulerServiceTest {
  @Mock
  private QuotationSendService quotationSendService;

  @InjectMocks
  private SchedulerService schedulerService;

  @Test
  void shouldSendDataForSap() {
    schedulerService.scheduledTaskSAP();
    verify(quotationSendService).sendAndSaveQuotationsForSap();
  }

  @Test
  void shouldSendDataForTM1() {
    schedulerService.scheduledTaskTM1();
    verify(quotationSendService).sendAndSaveQuotationsForTM1();
  }
}
