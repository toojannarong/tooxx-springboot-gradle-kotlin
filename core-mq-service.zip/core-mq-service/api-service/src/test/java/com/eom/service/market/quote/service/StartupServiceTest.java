package com.eom.service.market.quote.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.timeout;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class StartupServiceTest {
  @Mock
  private SchedulerService schedulerService;

  @InjectMocks
  private StartupService startupService;

  @Test
  void shouldStartup() {
    startupService.run(null);
    verify(schedulerService, timeout(5000)).startTM1();
    verify(schedulerService, timeout(5000)).startSAP();
  }
}
