package com.eom.service.market.quote.support;

import static java.util.Collections.singletonList;

import com.eom.service.market.quote.domain.Price;
import com.eom.service.market.quote.domain.Quotation;
import com.eom.service.market.quote.domain.QuotationPrice;
import com.eom.service.market.quote.domain.QuotationSource;
import com.eom.service.market.quote.domain.QuotationType;
import com.eom.service.market.quote.domain.StripesReference;
import com.eom.service.market.quote.domain.StripesReferenceHeader;
import com.eom.service.market.quote.domain.UnitOfMeasure;
import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.domain.entity.QuotationEntityId;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

public class QuotationFactory {

  private static final String DATE = "2019-01-01";
  private static final String USD = "USD";

  public static Quotation createQuotation(String quotationId, String source, String priceH,
      String priceM, String priceL) {
    return Quotation.builder()
        .stripesReference(StripesReferenceHeader.builder()
            .id(quotationId)
            .source(QuotationSource.builder()
                .code(source).build())
            .build())
        .prices(createPrices(priceH, priceM, priceL))
        .build();
  }

  public static QuotationEntity createQuotationEntity(String id, String sourcecode, String type,
      String price, LocalDateTime createdAt, LocalDateTime updatedAt) {
    return QuotationEntity.builder()
        .quotationEntityId(new QuotationEntityId(id, sourcecode, DATE, type))
        .price(price)
        .unitOfMeasure("TO")
        .currency(USD)
        .createdAt(createdAt)
        .updatedAt(updatedAt)
        .build();
  }

  private static List<QuotationPrice> createPrices(String highPrice, String mediumPrice,
      String lowPrice) {
    QuotationPrice highQuotationPrice = createQuotationPrice(highPrice, "H", "HIGH");
    QuotationPrice mediumQuotationPrice = createQuotationPrice(mediumPrice, "M", "MEDIUM");
    QuotationPrice lowQuotationPrice = createQuotationPrice(lowPrice, "L", "LOW");
    return Arrays.asList(highQuotationPrice, mediumQuotationPrice, lowQuotationPrice);
  }

  private static QuotationPrice createQuotationPrice(String priceAmount, String type,
      String typeDescription) {
    return QuotationPrice.builder()
        .date(DATE)
        .stripesReference(StripesReference.builder()
            .uom(UnitOfMeasure.builder()
                .code("TO")
                .description("")
                .build()
            )
            .type(QuotationType.builder()
                .code(type)
                .description(typeDescription)
                .build())
            .build())
        .price(Price.builder()
            .amount(priceAmount)
            .currency(null)
            .build())
        .uom(null)
        .build();
  }

  public static Quotation createQuotationWithPriceV(String quotationId, String source,
      String priceV) {
    return Quotation.builder()
        .stripesReference(StripesReferenceHeader.builder()
            .id(quotationId)
            .source(QuotationSource.builder()
                .code(source).build())
            .build())
        .prices(singletonList(createQuotationPrice(priceV, "V", "VOLUME")))
        .build();
  }
}
