package com.eom.service.market.quote.transformers;

import com.eom.service.market.quote.domain.FactoryCalendar;
import com.eom.service.market.quote.domain.Price;
import com.eom.service.market.quote.domain.Quotation;
import com.eom.service.market.quote.domain.QuotationPrice;
import com.eom.service.market.quote.domain.QuotationSource;
import com.eom.service.market.quote.domain.QuotationSourceAndStripe;
import com.eom.service.market.quote.domain.QuotationType;
import com.eom.service.market.quote.domain.StripesReference;
import com.eom.service.market.quote.domain.StripesReferenceHeader;
import com.eom.service.market.quote.domain.UnitOfMeasure;
import com.eom.service.market.quote.domain.entity.QuotationEntity;
import com.eom.service.market.quote.domain.entity.QuotationEntityId;
import com.eom.service.market.quote.domain.entity.TM1CurrencyEntity;
import com.eom.service.market.quote.domain.fromsap.QuotationSAP;
import com.eom.service.market.quote.domain.fromtm1.QuotationTM1;
import com.eom.service.market.quote.repository.GrdbUomEntityRepository;
import com.eom.service.market.quote.repository.QuotationIdDescriptionRepository;
import com.eom.service.market.quote.repository.QuotationPriceTypeDescriptionRepository;
import com.eom.service.market.quote.repository.QuotationSourceDescriptionRepository;
import com.eom.service.market.quote.repository.QuotationUnitOfMeasurementDescriptionRepository;
import com.eom.service.market.quote.repository.TM1CurrencyEntityRepository;
import com.eom.service.market.quote.repository.TM1QuoteDescriptionRepository;
import com.eom.service.market.quote.repository.TM1UomEntityRepository;
import com.eom.service.market.quote.repository.UomRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static com.xom.odataclient.domain.Stripe.EU;
import static java.util.stream.Collectors.toList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

@ExtendWith(MockitoExtension.class)
class QuotationEntityTransformerTest {

  @Mock
  private QuotationSourceDescriptionRepository quotationSourceDescriptionRepository;

  @Mock
  private QuotationIdDescriptionRepository quotationIdDescriptionRepository;

  @Mock
  private QuotationPriceTypeDescriptionRepository quotationPriceTypeDescriptionRepository;

  @Mock
  private QuotationUnitOfMeasurementDescriptionRepository
      quotationUnitOfMeasurementDescriptionRepository;

  @Mock
  private UomRepository uomRepository;

  @Mock
  private GrdbUomEntityRepository grdbUomEntityRepository;

  @Mock
  private TM1UomEntityRepository tm1UomEntityRepository;

  @Mock
  private TM1QuoteDescriptionRepository tm1QuoteDescriptionRepository;

  @Mock
  private TM1CurrencyEntityRepository tm1CurrencyEntityRepository;


  @InjectMocks
  private QuotationEntityTransformer quotationEntityTransformer;

  @Test
  void shouldTransformToEntityFromQuotation() {
    Quotation quotation = generateExampleQuotation();

    List<QuotationEntity> quotationEntityList = quotationEntityTransformer.transformToEntityFromQuotation(quotation);

    final QuotationEntity expectedTypeHQuotationEntity =
        generateExampleQuotationEntityForSap("200.000000", "TO", "H");
    final QuotationEntity expectedTypeMQuotationEntity =
        generateExampleQuotationEntityForSap("150.000000", "TO", "M");
    final QuotationEntity expectedTypeLQuotationEntity =
        generateExampleQuotationEntityForSap("100.000000", "TO", "L");
    final QuotationEntity expectedTypeCQuotationEntity =
        generateExampleQuotationEntityForSap("50.000000", "TO", "C");

    assertEquals(4, quotationEntityList.size());
    assertTrue(quotationEntityList.contains(expectedTypeHQuotationEntity));
    assertTrue(quotationEntityList.contains(expectedTypeMQuotationEntity));
    assertTrue(quotationEntityList.contains(expectedTypeLQuotationEntity));
    assertTrue(quotationEntityList.contains(expectedTypeCQuotationEntity));
  }

  @Test
  void shouldTransformToEntityFromSap() {
    QuotationSAP quotationSAP =
        QuotationSAP.builder()
            .sourceCode("A1")
            .quotationNumber("DIESEL10CAR")
            .date("2019-10-10")
            .quoteType("H")
            .quotePrice(100.00)
            .quantityForUom(100)
            .unitOfMeasureCode("BB6")
            .currency("USD")
            .factoryCalendarCode("PS")
            .factoryCalendarDescription("Platts Singapore")
            .build();

    Stream<QuotationEntity> quotationEntityStream =
        quotationEntityTransformer.transformToEntityFromSap(Stream.of(quotationSAP));

    List<QuotationEntity> quotationEntities = quotationEntityStream.collect(toList());

    assertEquals(1, quotationEntities.size());
    assertTrue(
        quotationEntities
            .contains(generateExampleQuotationEntityForSap("1.000000", "BB6", "H")));
  }

  @Test
  void shouldTransformToEntityFromTM1() {
    QuotationTM1 quotationTM1 =
        QuotationTM1.builder()
            .quoteSource("PN")
            .quoteName("DIESEL10CAR")
            .date("20191010")
            .quoteType("H")
            .value("1.00")
            .uom("")
            .currency("")
            .build();

    doReturn(Optional.of(TM1CurrencyEntity.builder().currency("USD").build()))
        .when(tm1CurrencyEntityRepository).findByQuoteNumberAndAndQuoteSource(any(), any());

    Stream<QuotationEntity> quotationEntityStream =
        quotationEntityTransformer.transformToEntityFromTM1(Stream.of(quotationTM1));

    List<QuotationEntity> quotationEntities = quotationEntityStream.collect(toList());

    assertEquals(1, quotationEntities.size());
    assertTrue(
        quotationEntities
            .contains(generateExampleQuotationEntityForTM1("1.000000", "", "H")));
  }

  @Test
  void shouldTransformToQuotationForSap() {
    final QuotationEntity expectedTypeHQuotationEntity =
        generateExampleQuotationEntityForSap("200.000000", "TO", "H");
    final QuotationEntity expectedTypeMQuotationEntity =
        generateExampleQuotationEntityForSap("150.000000", "TO", "M");
    final QuotationEntity expectedTypeLQuotationEntity =
        generateExampleQuotationEntityForSap("100.000000", "TO", "L");
    final QuotationEntity expectedTypeCQuotationEntity =
        generateExampleQuotationEntityForSap("50.000000", "TO", "C");


    Stream<QuotationEntity> entityStream =
        Stream.of(expectedTypeHQuotationEntity, expectedTypeMQuotationEntity, expectedTypeLQuotationEntity, expectedTypeCQuotationEntity);
    List<Quotation> quotationList = quotationEntityTransformer.transformToQuotationForSap(entityStream,
        new QuotationSourceAndStripe("A1", EU, 1));

    assertEquals(1, quotationList.size());
  }

  @Test
  void shouldTransformToQuotationForTM1() {
    final QuotationEntity expectedTypeHQuotationEntity =
        generateExampleQuotationEntityForTM1("200.000000", "TO", "H");
    final QuotationEntity expectedTypeMQuotationEntity =
        generateExampleQuotationEntityForTM1("150.000000", "TO", "M");
    final QuotationEntity expectedTypeLQuotationEntity =
        generateExampleQuotationEntityForTM1("100.000000", "TO", "L");
    final QuotationEntity expectedTypeCQuotationEntity =
        generateExampleQuotationEntityForTM1("50.000000", "TO", "C");


    Stream<QuotationEntity> entityStream =
        Stream.of(expectedTypeHQuotationEntity, expectedTypeMQuotationEntity, expectedTypeLQuotationEntity, expectedTypeCQuotationEntity);
    List<Quotation> quotationList = quotationEntityTransformer.transformToQuotationForTm1(entityStream);

    assertEquals(1, quotationList.size());
  }

  private Quotation generateExampleQuotation() {
    QuotationPrice priceH = generateExampleQuotationPrice("H", "200.000000");
    QuotationPrice priceM = generateExampleQuotationPrice("M", "150.000000");
    QuotationPrice priceL = generateExampleQuotationPrice("L", "100.000000");
    QuotationPrice priceC = generateExampleQuotationPrice("C", "50.000000");

    return Quotation.builder()
        .stripesReference(
            StripesReferenceHeader.builder()
                .id("DIESEL10CAR")
                .calendar(
                    FactoryCalendar.builder().code("PS").description("Platts Singapore").build())
                .source(new QuotationSource("A1", ""))
                .build())
        .prices(Arrays.asList(priceH, priceL, priceM, priceC))
        .build();
  }

  private QuotationPrice generateExampleQuotationPrice(String typeCode, String priceAmount) {
    return QuotationPrice.builder()
        .date("2019-10-10")
        .stripesReference(
            StripesReference.builder()
                .type(QuotationType.builder().code(typeCode).build())
                .uom(new UnitOfMeasure("TO", ""))
                .build())
        .price(Price.builder().amount(priceAmount).currency("USD").build())
        .uom(null)
        .build();
  }

  private QuotationEntity generateExampleQuotationEntityForSap(
      String price, String unitOfMeasure, String type) {
    return QuotationEntity.builder()
        .quotationEntityId(
            QuotationEntityId.builder()
                .id("DIESEL10CAR")
                .sourceCode("A1")
                .date("2019-10-10")
                .type(type)
                .build())
        .calendarCode("PS")
        .calendarDescription("Platts Singapore")
        .currency("USD")
        .price(price)
        .unitOfMeasure(unitOfMeasure)
        .build();
  }

  private QuotationEntity generateExampleQuotationEntityForTM1(
      String price, String unitOfMeasure, String type) {
    return QuotationEntity.builder()
        .quotationEntityId(
            QuotationEntityId.builder()
                .id("DIESEL10CAR")
                .sourceCode("PN")
                .date("2019-10-10")
                .type(type)
                .build())
        .currency("USD")
        .price(price)
        .unitOfMeasure(unitOfMeasure)
        .build();
  }
}
