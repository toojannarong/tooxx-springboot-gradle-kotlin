package com.eom.service.market.quote.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class TransformerUtilTest {

  @Test
  void shouldReturnStringWithSixDigitsGivenStringWithLessThanSixDigits() {
    String actual = TransformerUtil.scaleStringToSixDigits("999.9");

    assertEquals("999.900000", actual);
  }

  @Test
  void shouldReturnStringWithSixDigitsGivenStringWithSixDigits() {
    String actual = TransformerUtil.scaleStringToSixDigits("999.999999");

    assertEquals("999.999999", actual);
  }

  @Test
  void shouldReturnStringWithSixDigitsGivenStringWithMoreThanSixDigits() {
    String actual = TransformerUtil.scaleStringToSixDigits("999.9999999999");

    assertEquals("1000.000000", actual);
  }

}