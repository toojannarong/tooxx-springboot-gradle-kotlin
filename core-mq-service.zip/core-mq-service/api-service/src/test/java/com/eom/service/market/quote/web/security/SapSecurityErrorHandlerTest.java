package com.eom.service.market.quote.web.security;

import com.eom.errors.errorhandling.domain.ErrorsContext;
import com.xom.auth.azuread.security.SecurityErrorResponseTranslator;
import com.xom.odataclient.security.ODataAuthenticationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import static org.apache.http.HttpStatus.SC_FORBIDDEN;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.http.HttpStatus.FORBIDDEN;

public class SapSecurityErrorHandlerTest {
  private SapSecurityErrorHandler errorHandler;

  @BeforeEach
  void setUp() {
    errorHandler = new SapSecurityErrorHandler(new SecurityErrorResponseTranslator());
  }

  @Test
  void shouldRespondUnauthorizedGivenODataAuthenticationExceptionException() {
    ResponseEntity<ErrorsContext> responseEntity = errorHandler
        .handleODataAuthenticationException(new ODataAuthenticationException("Failed To Get SAML Token"));
    assertThat(responseEntity.getStatusCode()).isEqualTo(FORBIDDEN);
    assertThat(responseEntity.getStatusCodeValue()).isEqualTo(SC_FORBIDDEN);
  }
}
