package constant;

public class Constant {

  public static final long DAYS_FOR_QUOTATIONS = 30L;

}
