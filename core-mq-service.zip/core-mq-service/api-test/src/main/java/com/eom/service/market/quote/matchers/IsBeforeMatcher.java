package com.eom.service.market.quote.matchers;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.TimeZone;
import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;

import static java.time.LocalDateTime.parse;
import static java.time.format.DateTimeFormatter.ofPattern;

public class IsBeforeMatcher {

  private static final DateTimeFormatter DATE_TIME_FORMATTER = ofPattern(
      "EEE, dd MMM yyyy HH:mm:ss z")
      .withZone(TimeZone.getDefault().toZoneId());

  private IsBeforeMatcher() {}

  public static BaseMatcher<String> isBefore(LocalDateTime expectedTime) {
    return new BaseMatcher<String>() {
      @Override
      public boolean matches(Object item) {
        String actualTime = (String) item;
        return parse(actualTime, DATE_TIME_FORMATTER).isBefore(expectedTime);
      }

      @Override
      public void describeTo(Description description) {
        description.appendText(expectedTime.format(DATE_TIME_FORMATTER));
      }
    };
  }

}
