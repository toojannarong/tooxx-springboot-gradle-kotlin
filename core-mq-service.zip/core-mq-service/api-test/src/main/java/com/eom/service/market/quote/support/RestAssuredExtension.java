package com.eom.service.market.quote.support;

import io.restassured.RestAssured;
import java.util.Optional;
import junit.framework.AssertionFailedError;
import org.junit.jupiter.api.extension.AfterAllCallback;
import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.ExtensionContext;

public class RestAssuredExtension implements BeforeAllCallback, AfterAllCallback {


  private static synchronized void setupRestAssured(String baseUri) {
    RestAssured.baseURI = baseUri;
    RestAssured.useRelaxedHTTPSValidation();
  }

  @Override
  public  void beforeAll(ExtensionContext context) {
    Optional<String> coreCustomerServiceUrl = Optional
        .ofNullable(System.getProperty("core.mq.service.url"));

    String baseUri = coreCustomerServiceUrl.orElseThrow(() ->
        new AssertionFailedError("Cannot find system property 'core.mq.service.url'"));

    RestAssuredExtension.setupRestAssured(baseUri);

  }

  @Override
  public void afterAll(ExtensionContext context) {
    RestAssured.reset();
  }
}
