# custom-metric

### 1. Add prometheus annotation config to the deploymentConfig
```yaml
apiVersion: v1
  kind: DeploymentConfig
  metadata:
    ...
  spec:
    ...
    template:
      metadata:
        annotations:
          ...
          prometheus.io/scrape: "true"
          prometheus.io/port: "8080"
          prometheus.io/path: /actuator/prometheus 
```
- `prometheus.io/scrape` - is set to "true" so that Prometheus will discover it
- `prometheus.io/port` - scrape the port(is the container port)
- `prometheus.io/path` - Prometheus metric data endpoint in the application


### 2. Config the application

First of all, add dependency `io.micrometer:micrometer-registry-prometheus` to your application

By default, you don't need to add any other configuration, micrometer will create these two metrics:

- `http.server.requests` - default metric name of endpoint
- `http.client.requests` - default metric name of client request

If you want customize the metric name and data, you can add some configurations to overwrite the default configurations.
E.g. to overwrite the metric name on spring boot, you can add the following two properties:

```properties
management.metrics.web.server.requests-metric-name=alternative.http.server.requests # default is http.server.requests
management.metrics.web.client.requests-metric-name=alternative.https.client.requests # default is http.client.requests
```
For more information refer to [this](https://docs.spring.io/spring-boot/docs/current/reference/html/production-ready-metrics.html)
link.

### 3. Metric data in the Prometheus

To see our Prometheus service, check this URL: 
[https://prometheus-istio-system.apphn.ocp.na.xom.com/graph](https://prometheus-istio-system.apphn.ocp.na.xom.com/graph).

There are three default metrics in Prometheus for every metric name:

- `http_server_requests_seconds_count`
- `http_server_requests_seconds_sum`
- `http_server_requests_seconds_max`

> NOTE: The dot will be replaced by underscore in the Prometheus

You can use these metric names to get data about the metrics.

The [Prometheus query document](https://prometheus.io/docs/prometheus/latest/querying/basics/) will give you more 
information about how to create your own metrics and query them.


### 4. Metric Data View On Grafana

You can see our Grafana metric data view here: [https://grafana-istio-system.apphn.ocp.na.xom.com/](https://grafana-istio-system.apphn.ocp.na.xom.com/)

For more information on Grafana, use its [documentation](http://docs.grafana.org/).





