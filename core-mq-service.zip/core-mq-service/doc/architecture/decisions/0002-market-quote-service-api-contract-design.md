# 2. Market Quote Service API contract design

Date: 2019-11-14

## Status

Accepted

## Context

Market Quote Domain is part of the Domain Strategy that establishes business boundaries.

As part of this strategy, we are going to provide an interface that represents the Market Quote Domain, in an easy to use API.

## Decision

Based on meetings with our first consumer (PSES), and feedback provided by them, we ended up with the following contract model:

```json
{
  "data": {
    "id": "DIESELFRFOB",
    "description": "DIESEL 350 PPM FOB NWE",
    "source": {
      "code": "A2",
      "description": "ARGUS NWE"
    },
    "uom": {
      "code": "TO",
      "description": "Tonne"
    },
    "prices": [
      {
        "date": "2019-04-03",
        "type": {
          "code": "H",
          "description": "HIGH"
        },
        "price": {
          "amount": "609.75000",
          "currency": "USD"
        }
      },
      {
        "date": "2019-04-03",
        "type": {
          "code": "M",
          "description": "AVG OF HIGH & LOW"
        },
        "price": {
          "amount": "609.25000",
          "currency": "USD"
        }
      },
      {
        "date": "2019-04-03",
        "type": {
          "code": "L",
          "description": "LOW"
        },
        "price": {
          "amount": "608.75000",
          "currency": "USD"
        }
      }
    ]
  }
}
```

## Consequences

With our contract defined, we now have a clear shared vision between consumer and providers about the data we
are providing. Also, we are now able to proceed developing our Domain solution.