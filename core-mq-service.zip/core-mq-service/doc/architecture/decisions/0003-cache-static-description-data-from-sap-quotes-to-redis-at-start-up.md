# 3. Cache Static description data from SAP quotes to REDIS at start up

Date: 2019-12-18

## Status

Accepted

## Context

Market quote domain requires information about descriptions of fields gathered from SAP.

## Decision

As the descriptions information are almost unlikely to change we will cache these values on REDIS.

First fields of descriptions we will cache:
1. Unit Of Measurement
2. Price type
3. Quote Id
4. Quote Source

Regarding the caching of those values:

* Data will be cached when application start
* Cache will be cleaned only before new deployment
* When not hit the cache, we call SAP directly and cache the data on fly

## Consequences

By caching these values we are reducing calls to SAP endpoint, therefore, speeding up our processing and making sure we
only make the necessary calls to SAP.

It is possible to get dirty information because the cache is only revalidated before a new publish. It's a must to change this in the future.
