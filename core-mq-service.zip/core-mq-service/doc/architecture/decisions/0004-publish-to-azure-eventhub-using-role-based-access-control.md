# 4. Publish to Azure EventHub using Role-Based Access Control

Date: 2019-12-18

## Status

Accepted

## Context

The amqp protocol is not available because the firewall blocks the port.
So, we have decided a different approach to authorize access and publish events into EventHub.

## Decision

Azure provides several methods to access EventHub, among them, RBAC (Role-Based Access Control), which we decided to
use on our solution.

We will associate a role to the api registration from the consumers, granting them permission to receive the published
events in each environment.

Market quote domain have api registrations for each environment with the role sender to be able to publish events
successfully.

## Consequences

We are finally able to successfully publish to EventHub