# 5. Retrieve SAP quotes with specific scheduled frequency

Date: 2019-12-18

## Status

Accepted

## Context

We need to publish on EventHub new and update quotations prices, for today and last 10 days, and for specific quotation sources at least once a day.

The important quotation fields that is subjected to change and we need to compare:
- Price
- Unit Of Measure
- Currency

## Decision

Since we don't need real time data, and SAP doesn't provide IDoc for this table, we created a scheduled job that query SAP every two hours.
The query will return the quotations for specific quotation sources for today and last some days for we verify if it's new, updated or not updated.

The two hours interval was defined because we don't know for sure what hour the new data and corrected ones are updated on SAP.

We will also keep a local copy of the most recent quotation data on Postgres that we will use to compare:
- If the quotation searched on SAP is not present on our DB we will send it to EventHub and save a copy on our DB.
- If the quotation searched on SAP is present on our DB but has different data for currency, price or unit of measure we will send it to EventHub and update our local DB copy.

## Consequences

With this approach we make sure that we have a good update rate to have recent values for the quotations we are publishing to our clients.

We don't have error recovering for our service. The two hours interval is to help mitigate that.
